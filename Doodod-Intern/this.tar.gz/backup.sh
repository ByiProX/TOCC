tar zcvf this.tar.gz ./

git add .
git commit -m 'backup files'
git push

echo `backup finish!`
