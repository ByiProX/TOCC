import os
import sys
import platform

from config import uwsgi_config, nginx_config, __MODULE__

here = os.path.abspath(os.path.dirname(__file__))

uwsgi_config_path = os.path.join(here, '_config', 'uwsgi.ini')
nginx_config_path = os.path.join(here, '_config', 'nginx.conf')
restart_sh_path = os.path.join(here, 'restart.sh')

"""Test config."""
argv_list = sys.argv[1:]
__TEST__ = False
if 'test' in argv_list:
    __TEST__ = True

"""Convert config."""
uwsgi_config_bytes = [b'[uwsgi]\n']
for k, v in uwsgi_config.items():
    uwsgi_config_bytes.append(k.encode() + b' = ' + v.encode() + b'\n')

_nginx_config = ['access_log /home/log/nginx_access.log;\n',
                 'error_log /home/log/nginx_error.log;\n',
                 'server {\n',
                 '      listen  %s;\n' % nginx_config['listen'],
                 '      server_name %s;\n' % nginx_config['server_name'],
                 '\n',
                 '      location / {\n',
                 '        include      %s;\n' % nginx_config['include'],
                 '        uwsgi_pass   %s;\n' % nginx_config['uwsgi_pass'],
                 '      }\n'
                 '    }']
if __TEST__:
    _nginx_config = ['access_log /home/log/nginx_access.log;\n',
                     'error_log /home/log/nginx_error.log;\n',
                     'server {\n',
                     '      listen  %s;\n' % nginx_config['listen'],
                     '      server_name %s;\n' % 'ardsvr.ixuanren.com',
                     '\n',
                     '      location / {\n',
                     '        include      %s;\n' % nginx_config['include'],
                     '        uwsgi_pass   %s;\n' % nginx_config['uwsgi_pass'],
                     '      }\n'
                     '    }']
nginx_config_bytes = tuple(map(lambda x: x.encode(), _nginx_config))

"""Save config."""
with open(uwsgi_config_path, 'wb') as f:
    f.writelines(uwsgi_config_bytes)

with open(nginx_config_path, 'wb') as f:
    f.writelines(nginx_config_bytes)

"""Create restart.sh"""
restart_sh = [
    'killall -9 uwsgi\n',
    'killall -9 nginx\n',
    'uwsgi /home/%s/_config/uwsgi.ini\n' % __MODULE__,
    'nginx',
]
restart_sh_bytes = tuple(map(lambda x: x.encode(), restart_sh))

with open(restart_sh_path, 'wb') as f:
    f.writelines(restart_sh_bytes)

"""Move nginx config."""
if platform.system() == 'Linux':
    os.system('pip3 install -r /home/%s/requirements.txt' % __MODULE__)
    os.system('\cp /home/%s/_config/nginx.conf /etc/nginx/conf.d/' % __MODULE__)
    os.system('chmod +x /home/%s/restart.sh' % __MODULE__)
    os.system('/home/%s/restart.sh' % __MODULE__)
