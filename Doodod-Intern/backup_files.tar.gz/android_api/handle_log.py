import os
import re
import sys
import platform

import zmail

if platform.system() == 'Linux':
    argv_list = sys.argv[1:]
    send_to = 'zidoubot@doodod.com'
    for i in argv_list:
        if re.match(r'[0-9a-z]+@[0-9a-z]+\.com', i):
            send_to = i
    if 'send' in argv_list:
        server = zmail.server("zidoubot@doodod.com", "Robot123", smtp_host="smtp.exmail.qq.com",
                              pop_host="pop.exmail.qq.com")
        attachments = [
            '/home/android_api/log/android_debug.log',
            '/home/android_api/log/android_info.log',
            '/home/log/nginx_access.log',
            '/home/log/nginx_error.log',
            '/home/log/uwsgi.log',
        ]

        mail = {
            'subject': 'android_api_log',
            'content': 'None',
            'attachments': attachments
        }

        server.send_mail(send_to, mail)
    if 'delete' in argv_list:
        os.system('rm -rf /home/log/*')
        os.system('rm -rf /home/android_api/log/*')
    if 'restart' in argv_list:
        os.system('python3 /home/android_api/deploy.py')
