"""
config.py
~~~~~~~~~
WARNING: DO NOT IMPORT ANY MODULE HERE.
"""
# Import for config and log.
import os
import sys

# Base flask import.
from flask import Flask

# Set app and its config.

app = Flask('ZYunH')

# Base info.
here = os.path.abspath(os.path.dirname(__file__))

# Running config.
argv_list = sys.argv[1:]

__GEVENT__ = True
__PUBLISH__ = True

"""-------------uwsgi+nginx--------------------"""
# [uWSGI] config.
__MODULE__ = os.path.dirname(__file__).split('/')[-1]
uwsgi_config = {
    'socket': '127.0.0.1:5500',
    'master': 'true',
    'pythonpath': '/home/%s' % __MODULE__,
    'module': 'main',
    'wsgi-file': '/home/%s/main.py' % __MODULE__,
    'callable': 'app',
    # 'processes': '2',
    # 'threads': '5',
    'chdir': '/home/%s' % __MODULE__,
    'daemonize': '/home/log/uwsgi.log',

}
if __GEVENT__:
    uwsgi_config.update({'gevent': '100'})

# [nginx] config.
nginx_config = {
    'listen': '80',
    'server_name': 'ardsvr.xuanren360.com  ardsvr.walibee.com',
    'include': 'uwsgi_params',
    'uwsgi_pass': uwsgi_config['socket'],
}
"""------------------------------------------"""

winner_bot_URL = 'api.walibee'
database_URL = 'dal.com'
