import os
import logging


def init_logger(here, app_name, logger_name, mode='a', stream_level=logging.DEBUG):
    """Custom logger."""
    logfile_debug = os.path.join(here, 'log', '{}_debug.log'.format(app_name))
    logfile_info = os.path.join(here, 'log', '{}_info.log'.format(app_name))
    logfile_warning = os.path.join(here, 'log', '{}_warning.log'.format(app_name))
    try:
        os.mkdir(os.path.join(here, 'log'))
    except FileExistsError:
        pass

    logger = logging.getLogger('{}'.format(logger_name))

    stream_handler = logging.StreamHandler()
    file_handler_debug = logging.FileHandler(logfile_debug, mode)
    file_handler_info = logging.FileHandler(logfile_info, mode)
    file_handler_warning = logging.FileHandler(logfile_warning, mode)

    format_handler = logging.Formatter('%(asctime)s %(levelname)-8s %(module)-5s [%(funcName)s] %(message)s')
    format_handler.datefmt = '%Y-%m-%d %H:%M:%S'

    stream_handler.setFormatter(format_handler)
    file_handler_debug.setFormatter(format_handler)
    file_handler_info.setFormatter(format_handler)
    file_handler_warning.setFormatter(format_handler)

    stream_handler.setLevel(stream_level)
    file_handler_debug.setLevel(logging.DEBUG)
    file_handler_info.setLevel(logging.INFO)
    file_handler_warning.setLevel(logging.WARNING)

    logger.addHandler(stream_handler)
    logger.addHandler(file_handler_debug)
    logger.addHandler(file_handler_info)
    logger.addHandler(file_handler_warning)
    logger.setLevel(logging.DEBUG)
