import sys
import time
import requests

"""Test config."""
argv_list = sys.argv[1:]
__TEST__ = False
if 'test' in argv_list:
    __TEST__ = True

while True:
    print('__TEST__:', __TEST__)
    db_url = 'http://dal.ixuanren.com' if __TEST__ else 'http://dal.com:8090'
    resp = requests.get(
        '%s/a_chatrooms?select=["id","chatroomname","memberlist"]&pageSize=100&page=1&where={"nickname_default":"default"}' % db_url)
    all_chatroom_info = resp.json()['data']
    for i in all_chatroom_info:
        this_id = i['id']
        this_chatroomname = i['chatroomname']
        try:
            this_memberlist = i['memberlist']
        except KeyError:
            continue
        # Get default nickname.
        nickname_list = []
        member_list = this_memberlist.split(';')[0:3]
        for username in member_list:
            try:
                this_user_nickname = requests.get(
                    '%s/a_contacts?select=["nickname"]&where={"username":"%s"}' % (db_url, username)).json()[
                    'data'][0]['nickname']
            except Exception as e:
                this_user_nickname = ''
            nickname_list.append(this_user_nickname)
        nickname_default = '、'.join(nickname_list)[0:50]
        print(nickname_default)
        # Update.
        resp_put = requests.put('%s/a_chatroom/%s' % (db_url, this_id),
                                data={'nickname_default': f'{nickname_default}',
                                      'chatroomname': f'{this_chatroomname}'})
        print('Update chatroom:%s nickname_default:%s' % (this_chatroomname, nickname_default))
    time.sleep(300)
