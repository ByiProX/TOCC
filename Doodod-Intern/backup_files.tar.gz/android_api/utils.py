import json

import os
from flask import jsonify, request
from functools import wraps
import logging
import logging.config

# logger.
from config import rds

logger = logging.getLogger('android')

def parameters_check(need_list, *args):
    """Check each parameter (For POST)
    if could not get this parameter return 'Lack of (parameter)'
    """
    logger.info(u"")
    logger.info(u"FromIP : " + request.remote_addr)
    logger.info(u"BaseUrl: " + request.base_url)
    logger.info(u"JsonArg: " + json.dumps(request.json))
    if request.json is None:
        return response({'err_code': -1, 'content': 'Lack of json.'})

    if isinstance(need_list, str):
        need = args + (need_list,)
    else:
        need = need_list + args

    for i in need:
        if request.json.get(i) is None:
            return response({'err_code': -1, 'content': 'Lack of %s.' % i})
    return True


def response(body_as_dict):
    """Jsonify response, make its content-type:Json"""
    response_body = jsonify(body_as_dict)
    return response_body


def para_check(need_list, *parameters):
    def _wrapper(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            _para_check = parameters_check(need_list, *parameters)
            if _para_check is not True:
                return _para_check
            return func(*args, **kwargs)

        return wrapper

    return _wrapper


def check_json(func):
    def check(*args, **kwargs):
        if request.json is None:
            return response({'err_code': -1})
        return func(*args, **kwargs)

    return check


def rds_lpush(data, queue_name):
    ret = rds.lpush(queue_name, data)
    # logger.info(u"redis result lpush: %s. " % ret)


def rds_rpop(queue_name):
    ret = rds.rpop(queue_name)
    # logger.info(u"redis result rpop: %s. " % ret)
    return ret


def rds_lrange(queue_name):
    ret_list = rds.lrange(queue_name, 0, -1)
    # logger.info(u"redis result dump: %s. " % ret_list)
    return ret_list


def rds_lrem(queue_name, value):
    ret = rds.lrem(queue_name, 0, value)
    # logger.info(u"redis result dump: %s. " % ret_list)
    return ret


def verify_logs_folder_exist():
    logger.debug(u"检查logs目录是否存在")
    if os.path.exists('./logs') is False:
        logger.warning(u"没有找到logs目录,将新建目录")
        os.mkdir('./logs')
    else:
        pass
    logging.config.fileConfig('./logging.conf')
    logger.debug(u'logs目录检查完毕 - OK')
