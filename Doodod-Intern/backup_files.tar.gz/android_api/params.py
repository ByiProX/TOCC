# other params define  by scofield  2018-5-7
_dev_ = False
try:
    from __DEV__  import __DEV__
    _dev_ = __DEV__
except Exception  as ex:
    print (ex)

params = {
    'check_chatroom_pool_key': '7bc2535502d796c030f6f85febe4e804',
    'dal_uri': 'http://dal.ixuanren.com/' if _dev_ else 'http://dal.com:8090/',
    'rds_uri': '127.0.0.1' if _dev_ else '172.17.81.238',
    'rds_pwd': '' if _dev_ else '"redisRedis_789"',
    'bots':['wxid_3mxn5zyskbpt22','wxid_lkruzsl7w2r822','wxid_nnaxbph34r7f12','wxid_tltwiwb3j29k12','wxid_6mf4yqgs528e22','gedxbosf62','wxid_77txprhfmu5n22','wxid_jxqmadytiexe22','wxid_q05k9d2atjie22'],
    '_dev_':_dev_,
}