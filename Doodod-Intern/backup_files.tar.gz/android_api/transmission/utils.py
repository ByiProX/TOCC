import json
import time
import random
import signal
import logging
import requests
import base64

from urllib import parse
from functools import wraps
from collections import deque
from params import params

logger = logging.getLogger('android')


def fetch_all(table_name, where, count=0, page=1, pageSize=100):
    where = json.dumps(where)
    data_list = {'where': where, 'page': page, 'pageSize': pageSize}
    if count == 1:
        data_list.update({'count': 1})

    url = params['dal_uri'] + '%s' % table_name
    # Send check request.
    s = requests.Session()
    req = requests.Request('GET', url)
    prepped = req.prepare()
    prepped.url = prepped.url + '?' + _fix(parse.urlencode(data_list))
    resp = s.send(prepped)
    result = resp.json()

    if count == 1:
        code, data = result['code'], result['count']
    else:
        code, data = result['code'], result['data']
    if not data:
        return False, None, None

    if 'pages' in result:
        # _data = {"data":data, "pages":result['pages'] }
        return True, data, result['pages']

    return True, data, None


def exist(table_name, values_as_dict, limit=1, ret_data=0):
    """Check if values already exist in the database.
    True -> item already exist.
    False -> can not find this item in database.

    :param table_name: str
    :param url: str
    :param values_as_dict: dict
    :param limit: int
    :return: bool
    """

    where = json.dumps(values_as_dict)
    select = json.dumps(list(values_as_dict.keys()))

    data_list = {
        'where': where,
        # 'select': select,
        'limit': limit
    }
    # Make url.
    url = params['dal_uri'] + table_name
    # Send check request.
    s = requests.Session()
    req = requests.Request('GET', url)
    prepped = req.prepare()
    prepped.url = prepped.url + '?' + _fix(parse.urlencode(data_list))
    resp = s.send(prepped)
    result = resp.json()

    code, data = result['code'], result['data']

    if not data:
        return False, None

    # data is a list of dict, each items include all its info.
    for i in data:
        for k in list(values_as_dict.keys()):
            if values_as_dict[k] != i[k]:
                return False, None
    if ret_data == 1:
        return True, data[0]
    else:
        return True, data[0]['id']


def android_message_handle(bot_username,values_as_dict):
    """
    Read android message and create new field.
    is_to_friend INT
    real_talker STRING
    real_content STRING

    :return: Dict
    """
    content = values_as_dict.get('content')
    is_send = values_as_dict.get('is_send')
    talker = values_as_dict.get('talker')
    msg_type = values_as_dict.get('type')

    # is_to_friend.
    if talker.find('@chatroom') > -1:
        is_to_friend = 0
    else:
        is_to_friend = 1
    
    #scofield add 2018/6/8 make new unique id
    

    if is_send:
        real_talker = values_as_dict.get('bot_username')
        real_content = content
        
    elif is_to_friend: 
        real_talker = talker
        real_content = content
    elif msg_type == 10000:
        real_talker = '' 
        real_content = content
    elif msg_type != 1:
        # 除了 TXT 和 SYS 的处理
        real_content = content
        if content.find(':') == -1:
            # 收到的群消息没有 ':\n', "语言聊天已结束" 等
            real_talker = talker
        else:
            content_part = content.split(':')
            real_talker = content_part[0]
    else:
        if content.find(':\n') == -1:
            # Mark: 收到的群消息没有 ':\n'，需要查错
            pass
        content_part = content.split(':\n')
        real_talker = content_part[0]
        real_content = content_part[1]

    values_as_dict.update({'is_to_friend': is_to_friend, 'real_talker': real_talker, 'real_content': real_content})

    #scofield add 2018/6/8 make new unique id
    client_id = 0
    #scofield add 2018/6/8 
    client_qun_r = 'client_qun_r'
    if not is_to_friend :
        n = 0
        while True:
            n += 1
            if n >=3 :
               break 
            cqr_exist, cqr = exist(client_qun_r+'s', {"bot_username":bot_username,"chatroomname":talker}, limit=1, ret_data=1) 
            if cqr_exist:
                client_id = cqr['client_id']
                break
            else:
                time.sleep(1)
    #mid = str(client_id) + '$$' + str(values_as_dict.get('msg_local_id')) + '$$' + str(values_as_dict.get('create_time'))
    #mid = base64.b64encode(mid.encode()).decode()
    values_as_dict.update({"client_id":client_id})

    return values_as_dict


def create_chatroom(*args):
    result = {'task': 'create_chatroom',
              'members': args
              }
    return json.dumps(result)


def send_message(**kwargs):
    result = {'task': 'send_message'}
    result.update(kwargs)
    return json.dumps(result)


def _fix(obj):
    """Fix urlencoded error."""
    obj = obj.replace('%7B', '{')
    obj = obj.replace('%7D', '}')
    obj = obj.replace('%3A+', ':')
    obj = obj.replace('%2C+', ',')
    obj = obj.replace('%5B', '[')
    obj = obj.replace('%5D', ']')
    return obj


def limit_time(num, callback):
    """Not used now."""

    def wrap(func):
        @wraps(func)
        def handle(_signal_, _error):
            raise RuntimeError

        @wraps(func)
        def run_task(*args, **kwargs):
            try:
                signal.signal(signal.SIGALRM, handle)
                signal.alarm(num)
                r = func(*args, **kwargs)
                signal.alarm(0)
                return r
            except RuntimeError:
                callback()
                return False

        return run_task

    return wrap


def handle_members(value_as_dict) -> dict:
    def check(table_name, values_as_dict, limit=1, select_as_dict=None):
        """Check if values already exist in the database.
        True -> item already exist.
        False -> can not find this item in database.

        :param table_name: str
        :param url: str
        :param values_as_dict: dict
        :param limit: int
        :return: bool
        """

        where = json.dumps(values_as_dict)
        select = json.dumps(list(select_as_dict.keys()))

        data_list = {
            'where': where,
            'select': select,
            'limit': limit
        }
        # Make url.
        url = params['dal_uri'] + table_name
        # Send check request.
        s = requests.Session()
        req = requests.Request('GET', url)
        prepped = req.prepare()
        prepped.url = prepped.url + '?' + _fix(parse.urlencode(data_list))
        resp = s.send(prepped)
        result = resp.json()

        code, data = result['code'], result['data']

        if not data:
            return False, None

        # data is a list of dict, each items include all its info.
        return data[0]

    basic_as_dict = {}
    for i in ('chatroomname',):
        basic_as_dict[i] = value_as_dict[i]
    # Base previous data.
    previous_data = check('a_members', basic_as_dict, select_as_dict=value_as_dict)
    previous_data_members_list = previous_data['members']
    now_data_members_list = value_as_dict['members']

    previous_members_username_list = []
    now_members_username_list = []

    for i in previous_data_members_list:
        previous_members_username_list.append(i['username'])

    for i in now_data_members_list:
        now_members_username_list.append(i['username'])

    deleted_username_list = []
    created_username_list = []

    for i in previous_members_username_list:
        if i not in now_members_username_list and i not in deleted_username_list:
            deleted_username_list.append(i)

    for i in now_members_username_list:
        if i not in previous_members_username_list:
            created_username_list.append(i)

    # Add is_deleted.
    for i in previous_data['members']:
        if i['username'] in deleted_username_list and i['is_deleted'] != 1:
            i.update({'is_deleted': 1, 'update_time': int(time.time())})

    # Add new_member.
    for i in now_data_members_list:
        if i['username'] not in previous_members_username_list:
            temp = i
            temp.update({'create_time': int(time.time()), 'update_time': int(time.time())})
            previous_data['members'].append(temp)

    # A member exit then entry.
    common_username_list = []
    for username in previous_members_username_list:
        if username in now_members_username_list and username not in common_username_list:
            common_username_list.append(username)

    for i in previous_data['members']:
        if i['username'] in common_username_list and i['is_deleted'] == 1:
            i.update({'is_deleted': 0, 'update_time': int(time.time()), 'create_time': int(time.time())})

    previous_data['update_time'] = int(time.time())

    return previous_data


class FIFODeque(deque):
    """FIFO deque used for websocket."""

    def __init__(self, default='None'):
        self.default = default
        super().__init__()

    def pop_value(self):
        try:
            return self.pop()
        except IndexError:
            return self.default

    def insert_value(self, value):
        self.appendleft(value)

    def insert_value_first(self, value):
        self.append(value)


def sleep_time(_len):
    """Used for sleep send task."""
    if _len < 5:
        return random.uniform(3.5, 8.0)
    else:
        return random.uniform(2.5, 5.0)


class SendToAndroid:
    def __init__(self, socket, to_android_message):
        self.socket = socket
        self.to_android_message = to_android_message

    def run(self):
        self.socket.send(self.to_android_message)
