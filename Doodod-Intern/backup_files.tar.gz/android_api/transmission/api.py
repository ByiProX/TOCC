import queue
import time
import json
import base64
import random
import logging
import threading
import traceback
import sys

import oss2
import requests
from flask import Blueprint, request
from params import params

from config import app
from .utils import exist, FIFODeque, android_message_handle, handle_members, fetch_all, sleep_time, SendToAndroid
from utils import para_check, response, rds_lpush, rds_rpop, rds_lrange, rds_lrem

transmission = Blueprint('transmission', __name__, url_prefix='/transmission')
android = Blueprint('android', __name__, url_prefix='/android')

from flask_uwsgi_websocket import GeventWebSocket

ws = GeventWebSocket(app)

# A deque to run the task.
inner_queue = queue.Queue(maxsize=0)

# A dict to confirm each bot is alive or not.
alive_bot_dict = {}
alive_bot_dict_post = {}

# logger.
logger = logging.getLogger('android')

# The number of thread to run the transmit task.
__MAX_THREAD__ = 100

winner_bot = 'api.walibee'
if params['_dev_']:
    winner_bot = 'api.ixuanren'


class SendThread(threading.Thread):
    """Multiple thread function, will exist throughout application."""

    def run(self):
        while True:
            logger.debug('[inner_queue] Task length:{}'.format(inner_queue.qsize()))
            try:
                send_request(inner_queue.get())
            except Exception as e:
                logger.warning('[SendThread] Exception:{}'.format(e))


class Task:
    def __init__(self, action, data_as_dict, table_name, update_id=None, url=None, _from=''):
        """
        action:
        'save' -> Add an extra data.
        'update' -> Update a data already exist.
        'transmit' -> transmit raw data to another api.
        """
        self.action = action
        self.data = data_as_dict
        self.__table__ = table_name
        self.update_id = update_id
        self.url = ''
        self._from = _from
        if self.action == 'save':
            self.url = '%s%s' % (params['dal_uri'], table_name)
        elif self.action == 'update':
            self.url = '%s%s/%s' % (params['dal_uri'], table_name[0:-1], self.update_id)
        elif self.action == 'transmit':
            self.url = url
        elif self.action == 'test':
            self.url = url

    def run(self):
        _response = 'default'
        if self._from == 'android_member':
            self.data['members'] = json.dumps(self.data['members'])
        if self.action == 'save':
            _response = requests.post(self.url, data=self.data)
        elif self.action == 'update':
            _response = requests.put(self.url, data=self.data)
        elif self.action == 'transmit':
            _response = requests.post(self.url, json=self.data)
        elif self.action == 'test':
            _response = requests.get(self.url)
        res_as_dict = _response.json()
        if res_as_dict.get('code') not in (None, 0) or res_as_dict.get('err_code') not in (None, 0):
            logger.error('[{}]{} response:{}'.format(self._from, self.action, str(_response.text).replace('\n', '')))
        logger.debug('[{}]{} response:{}'.format(self._from, self.action, str(_response.text).replace('\n', '')))


"""--------------------------------------------------------------------"""


@ws.route('/ws/<string:bot_username>')
def web_socket(socket, bot_username):
    """
    Maintain a global alive_alive_bot dict for confirm each bot status.
    if a bot is logout, its status will be false, and the message not confirm
    will reinsert to its message deque(the position it was).

    alive_alive_bot dict format -> 'bot_username' : (FIFODeque , status)
    FIFODeque : first in first out deque, if empty pop its default value.
    status : if True represent the bot is alive, else is dead.

    """
    login_time = int(time.time())
    # A bot login.
    logger.warning('A bot login:{}'.format(bot_username))
    if bot_username not in globals()['alive_bot_dict'].keys():
        globals()['alive_bot_dict'][bot_username] = [FIFODeque(default='ping'), True, login_time]
    else:
        globals()['alive_bot_dict'][bot_username][1] = True
        globals()['alive_bot_dict'][bot_username][2] = login_time
    # message_queue = globals()['alive_bot_dict'][bot_username][0]

    # Check if error have been log.
    while True:
        if login_time < globals()['alive_bot_dict'][bot_username][2]:
            logger.info('login_time break')
            break
        time.sleep(random.uniform(1.0, 2.0))
        # if login_time < globals()['alive_bot_dict'][bot_username][2]:
        #     break

        # to_android_message = message_queue.pop_value()
        to_android_message = rds_rpop(bot_username)
        globals()['alive_bot_dict'][bot_username][1] = True

        if to_android_message and to_android_message != 'ping':
            socket.send(to_android_message)
            logger.info('Try send {} To {}'.format(to_android_message, bot_username))

        from_android_message = socket.receive()

        if from_android_message:
            logger.info('Send Success {} '.format(from_android_message))
            # if to_android_message == 'ping':
            #     logger.debug('Ping Success {} .'.format(to_android_message))
            # else:
            #     logger.info('Send Success {} '.format(to_android_message))

        if not socket.connected:
            logger.info('socket.connected break')
            break

    # A bot logout.
    logger.warning('A bot leave:{}'.format(bot_username))
    globals()['alive_bot_dict'][bot_username][1] = False
    return ' '


@ws.route('/ws_v2/<string:bot_username>')
def web_socket_v2(socket, bot_username):
    """
    Maintain a global alive_alive_bot dict for confirm each bot status.
    if a bot is logout, its status will be false, and the message not confirm
    will reinsert to its message deque(the position it was).

    alive_alive_bot dict format -> 'bot_username' : (FIFODeque , status)
    FIFODeque : first in first out deque, if empty pop its default value.
    status : if True represent the bot is alive, else is dead.

    """

    # A bot login.
    logger.warning('A bot login:{}'.format(bot_username))
    if bot_username not in globals()['alive_bot_dict'].keys():
        globals()['alive_bot_dict'][bot_username] = [FIFODeque(default='ping'), True]
    else:
        globals()['alive_bot_dict'][bot_username][1] = True
    # message_queue = globals()['alive_bot_dict'][bot_username][0]

    # Check if error have been log.
    while True:
        # to_android_message = message_queue.pop_value()
        to_android_message = rds_rpop(bot_username)

        if to_android_message != 'ping':
            logger.info('to_android_message {}'.format(to_android_message))
            logger.info('Try send {} To {}'.format(to_android_message, bot_username))
            # Sleep task.
            # _sleep = sleep_time(len(message_queue))
            # time.sleep(_sleep)
            # Send message for ping or send message.
            inner_queue.put(SendToAndroid(socket, to_android_message))

        from_android_message = socket.receive()

        if from_android_message:
            logger.info('from_android_message {}'.format(from_android_message))
            # message_queue.insert_value(from_android_message)
            # 通过 websocket 入库
            open_box(from_android_message)
            pass

        if not socket.connected:
            break

    # A bot logout.
    logger.warning('A bot leave:{}'.format(bot_username))
    globals()['alive_bot_dict'][bot_username][1] = False
    return ' '


def open_box(from_android_message):
    try:
        msg_dict = json.loads(from_android_message)
        if not isinstance(msg_dict, dict):
            return
        sigil = msg_dict.get("sigil")
        if not sigil:
            logger.info('unknown sigil')
            return
        if sigil == "a_contact":
            command = msg_dict.get("command")
    except Exception as e:
        pass
        # logger.warning('[open_box] Exception:{}'.format(e))


def save_a_contact(value_as_dict):
    __table__ = 'a_contact' + 's'

    # Get basic values dict.
    basic_as_dict = {}
    for i in ('username',):
        basic_as_dict[i] = value_as_dict[i]

    # Create task.
    _exist, unique_id = exist(__table__, basic_as_dict)
    if not _exist:
        value_as_dict.update({'create_time': int(time.time()), 'update_time': int(time.time())})
        inner_queue.put(Task('save', value_as_dict, __table__, _from=android_contact.__name__))
    else:
        value_as_dict.update({'update_time': int(time.time())})
        inner_queue.put(Task('update', value_as_dict, __table__, unique_id, _from=android_contact.__name__))
    return ' '


@android.route('/send_mass_message', methods=['POST'])
@para_check('bot_username', 'message_list', 'to_list')
def flask_send_mass_message():
    """
        "bot_username":"qqqqqqqqqq"
        "message_list":[{"type":0,"content":"x"},{"type":1,"content":"y"}]
        "to_list":[xxxx,yyyyy]
    """
    bot_username = request.json.get('bot_username')
    if not globals()['alive_bot_dict'].get(bot_username) or not globals()['alive_bot_dict'].get(bot_username)[1]:
        return response({'err_code': -1})

    to_list = request.json.get('to_list')
    message_list = request.json.get('message_list')

    for i in to_list:
        for j in message_list:
            if globals()['alive_bot_dict'].get(bot_username) and globals()['alive_bot_dict'].get(bot_username)[1]:
                # message_queue = globals()['alive_bot_dict'][bot_username][0]
                try:
                    rds_lpush(json.dumps({"task": "send_message", "to": i, **j}), queue_name = bot_username)
                    # message_queue.insert_value(json.dumps({"task": "send_message", "to": i, **j}))
                except KeyError:
                    logger.warning('[{}] insert illegal value: {}'.format(flask_send_message.__name__, message_list))
                    return response({'err_code': -2, 'err_info': 'Receive illegal value.'})
                logger.debug('[{}] insert value: {}'.format(flask_send_message.__name__, message_list))
            else:
                logger.debug('bot dead when send message.')
                return response({'err_code': -1})

    return response({'err_code': 0})


@android.route('/rds_lpush', methods = ['POST'])
@para_check('queue_name', 'data')
def flask_rds_lpush():
    data = request.json.get("data")
    queue_name = request.json.get("queue_name")
    rds_lpush(data, queue_name = queue_name)
    return " "


@android.route('/rds_rpop', methods = ['POST'])
@para_check('queue_name')
def flask_rds_rpop():
    queue_name = request.json.get("queue_name")
    ret = rds_rpop(queue_name)
    return ret


@android.route('/rds_lrange', methods = ['POST'])
@para_check('queue_name')
def flask_rds_lrange():
    queue_name = request.json.get("queue_name")
    ret_list = rds_lrange(queue_name)
    ret_json_list = []
    for ret in ret_list:
        ret_json_list.append(ret.decode())
    return json.dumps(ret_json_list)


@android.route('/rds_lrem', methods = ['POST'])
@para_check('queue_name', 'value')
def flask_rds_lrem():
    queue_name = request.json.get("queue_name")
    value = request.json.get("value")
    ret = rds_lrem(queue_name, value)
    return str(ret)


@android.route('/send_message', methods=['POST'])
@para_check('bot_username', 'data')
def flask_send_message():
    bot_username = request.json.get('bot_username')
    data = request.json.get('data')
    if globals()['alive_bot_dict'].get(bot_username) and globals()['alive_bot_dict'].get(bot_username)[1]:
        # message_queue = globals()['alive_bot_dict'][bot_username][0]
        task = data.get("task")
        contacts = data.get("contacts")
        if task and task == "update_chatroom":
            logger.info('BUG update_chatroom')
            return response({'err_code': 0})
        if task and task == "add_contact_to_chatroom" and contacts == "":
            logger.info('BUG add_contact_to_chatroom')
            return response({'err_code': 0})
        # message_queue.insert_value(json.dumps(data))
        rds_lpush(data, queue_name = bot_username)
        logger.debug('{} insert value: {}'.format(flask_send_message.__name__, json.dumps(data)))
        return response({'err_code': 0})
    else:
        return response({'err_code': -1})


@android.route('/bot_status', methods=['GET'])
def flask_bot_status():
    result = {}
    for k, v in globals()['alive_bot_dict'].items():
        result[k] = v[1]

    return response(result)


@android.route('/bot_status_detail', methods=['GET'])
def flask_bot_status_detail():
    result = {}
    for k, v in globals()['alive_bot_dict'].items():
        queue_list = list()
        for i in v[0]:
            queue_list.append(i)
        result[k] = {"status": v[1], "login_time": v[2], "queue_list": queue_list}

    return response(result)


"""--------------------------------------------------------------------"""


@transmission.route('/a_message', methods=['POST'])
@para_check('bot_username', 'msg_id')
def android_message():
    def send_or(bot_username, client_id, chatroomname):
        global alive_bot_dict_post
        _cqr_exist, _cqrs, _pages = fetch_all('client_qun_rs', {'client_id': client_id, "chatroomname": chatroomname})
        logger.debug('scofield _cqrs: {}'.format(_cqrs))
        all_bots = alive_bot_dict_post
        logger.debug('scofield all_bots: {}'.format(all_bots))
        if _cqrs:
            cqrs_json_list = [r for r in _cqrs]
            cqrs_json_list.sort(key=lambda e: e.get("weight"), reverse=True)
            live_first = ''
            for cqr in cqrs_json_list:
                if all_bots[cqr.get('bot_username')]:
                    live_first = cqr.get('bot_username')
                    break
            # master
            if live_first == bot_username:
                return True
        return False

    __table__ = 'a_message' + 's'
    try:
        # Get values.
        value_as_dict = dict(request.json)

        # Handle values and add 3 fields.
        value_as_dict = android_message_handle(value_as_dict.get('bot_username'), value_as_dict)

        if not value_as_dict.get('is_to_friend') and value_as_dict.get('client_id'):
            logger.warning('scofield start check send or not :{}'.format(value_as_dict))
            _send_or = send_or(value_as_dict.get('bot_username'), value_as_dict.get('client_id'),
                               value_as_dict.get('talker'))
            if not _send_or:
                logger.warning('scofield find slave bot or not find bot:{}'.format(value_as_dict))
                return ''

                # make check values dict.
        basic_as_dict = {"msg_id": value_as_dict.get('msg_id')}
        # Create task.
        _exist, unique_id = exist(__table__, basic_as_dict)

        # logger.warning('dal_uri:{}   '.format(params['dal_uri']))
        _response = None
        if not _exist:
            url = params['dal_uri'] + '%s' % __table__
            _response = requests.post(url, data=value_as_dict)
            logger.debug('[{}]{} response:{}'.format('android_message', 'save', str(_response.text).replace('\n', '')))
        else:
            url = params['dal_uri'] + '%s/%s' % (__table__[0:-1], unique_id)
            _response = requests.put(url, data=value_as_dict)
            logger.debug(
                '[{}]{} response:{}'.format('android_message', 'update', str(_response.text).replace('\n', '')))
        try:
            # logger.warning('a_message:{}   '.format(_response.json()))
            a_message_id = dict(_response.json())['data']['id']
        except Exception as e:
            # logger.warning('a_message_id Wrong!,e:{},resp:{}'.format(e, _response.json()))
            a_message_id = 'None'
        value_as_dict['a_message_id'] = a_message_id
        # Fix '' replace an exist field.
        for k, v in value_as_dict.copy().items():
            if v == '':
                value_as_dict.pop(k)

        inner_queue.put(
            Task('transmit', value_as_dict, __table__, url='http://%s.com/yaca_api_v2/android/new_message' % winner_bot,
                 _from=android_message.__name__))

        # save chatroom pool by scofield 2018-5-7
        cpool = create_chatroom_pool(value_as_dict)
        # logger.warning('cpool %s' % cpool)
    except Exception as es:
        logger.warning('a_message err:: %s' % es)
        pass

    return ' '


# scofield 2018-5-7
# create chatroom pool
def create_chatroom_pool(msg):
    # logger.warning('create_chatroom_pool by msg:{}   '.format(msg))
    # step 1: check_chatroom_pool_key was right
    if len(msg) > 0 and msg['real_content'].find(params['check_chatroom_pool_key']) != -1 and int(
            msg['is_to_friend']) == 0:
        __table__ = 'chatroom_pool' + 's'
        pool_data = {}
        pool_data['chatroomname'] = msg.get('talker')
        pool_data['bot_username'] = msg.get('bot_username')
        try:
            # step2: get chatroom info
            url = params['dal_uri'] + 'a_chatrooms'
            _exist, _chatroom_data = exist('a_chatrooms', {"chatroomname": pool_data['chatroomname']}, 1, 1)
            # logger.warning('check chatroomname _exist:{},_chatroom_data:{}'.format(_exist, _chatroom_data))
            # chat room info not exist
            if not _exist:
                return False

            # get all bots
            bots = []
            _bot_has, _bots, _pages = fetch_all('bot_infos', {"is_alive": 1})
            for _bt in _bots:
                # logger.warning(' bt:{},_bots:{} '.format(_bt, _bots))
                bots.append(_bt['username'])
            # roomowner not was a bot 
            # if not _chatroom_data.get('roomowner') in bots:
            # logger.warning('roomowner was not  in bots. roomowner:{} bots:{} '.format(_chatroom_data.get('roomowner'),params['bots']))
            #    return False

            # status : 1 = active, 0 = bind
            pool_data['create_user'] = msg.get('real_talker')
            pool_data['roomowner'] = _chatroom_data.get('roomowner')
            pool_data['nickname'] = _chatroom_data.get('nickname')
            pool_data['create_time'] = int(time.time())
            pool_data['update_time'] = int(time.time())
            pool_data['status'] = 1

            # check pool exist or not
            _pool_exist, pool_id = exist(__table__, {"chatroomname": pool_data['chatroomname']})
            _pool_id = pool_id
            if not _pool_exist:
                url = params['dal_uri'] + '%s' % __table__
                _response = requests.post(url, data=pool_data)
                # logger.warning(' _response  _response:{} '.format(_response.json()))
                logger.debug(
                    '[{}]{} response:{}'.format('chat_room_pool', 'save', str(_response.text).replace('\n', '')))
                rsp = dict(_response.json())
                _pool_id = rsp['data']

            if _pool_id:
                _del_ret = _del('client_qun_r', {"chatroomname": pool_data['chatroomname']})
                '''
                _client_m, _client_info = exist('client_members', {"username": pool_data['create_user']}, 1, 1)
                if _client_m:
                    _client_id = _client_info['client_id']
                    _del_ret = _del('client_qun_r',{"client_id": _client_id, "chatroomname": pool_data['chatroomname']})
                    logger.warning('_del_ret:{}'.format(_del_ret))
                else:
                    logger.warning('get create_user client id err:{}'.format(pool_data['create_user']))
                '''

            return _pool_id
        except Exception as e:
            pass
            # logger.warning('chat_room_pool create Wrong!,e:{},resp:{}'.format(e, _response.json()))
    else:
        # logger.warning('not match  key for pool')
        pass
        return ' not match '


# scofield 2018-5-7
# get active qun in the pool
@android.route('/chatroom_pool', methods=['POST'])
def chatroom_pool():
    result = {"msg": "", "code": 0}
    try:
        page = request.json.get('page', 1)
        count = request.json.get('count', 0)
        client_id = request.json.get('client_id')
        pageSize = request.json.get('pageSize', 100)
        bot_username = request.json.get('bot_username', [])
        where = {"status": 1}
        # logger.warning(' chatroom_pool  where:{} '.format(where))
        if client_id and int(client_id) > 0:
            _bot_exist, _bots, pages = fetch_all('client_bot_rs', {"client_id": client_id})
            # logger.warning(' _bots:{} '.format(_bots))
            if not _bot_exist:
                raise Exception('client had no bots.')
            for bt in _bots:
                # logger.warning(' bt:{},_bots:{} '.format(bt, _bots))
                bot_username.append(bt['bot_username'])

        if len(bot_username) > 0:
            where = ['and', ['in', 'bot_username', bot_username], ['=', 'status', 1]]
            # logger.warning(' where:{} '.format(where))

        _exist, _pool, pages = fetch_all('chatroom_pools', where, count, page, pageSize)
        # logger.warning(' _pool:{} '.format(_pool))
        if not _exist:
            raise Exception('not had qun.')
        result.update({'data': _pool})
    except Exception  as ex:
        traceback.print_exc(limit=5, file=sys.stdout)
        result['msg'] = ex.args[0]
        result['code'] = -1
    return response(result)


# scofield 2018-5-7
# bind relation with qun and client
@android.route('/chatroom_allot', methods=['POST'])
@para_check('client_id', 'num')
def chatroom_allot():
    result = {"msg": "", "code": 0}
    try:
        num = int(request.json.get('num'))
        client_id = int(request.json.get('client_id'))
        if client_id <= 0:
            raise Exception('client_id err.')
        _client_exist, _client_id = exist('clients', {"client_id": client_id}, 1, 1)
        if not _client_exist:
            raise Exception('client not exist.')

        if num <= 0 or num > 100:
            raise Exception('num should between 0 - 100.')

        #  "client_bot_r": [[["client_id", "bot_username"], "required"], [["client_id"], "integer"], [["chatbot_default_nickname", "bot_username"], "string", {"max": 50}], [["is_work", "create_time"], "integer"]],
        _bot_exist, _bots, pages = fetch_all('client_bot_rs', {"client_id": client_id})
        if not _bot_exist:
            raise Exception('client had no bots.')
        # logger.warning(' _bots:{} '.format(_bots))

        bot_username = []
        for bt in _bots:
            bot_username.append(bt['bot_username'])
        # logger.warning(' bot_username:{} '.format(bot_username))

        where = ['and', ['in', 'bot_username', bot_username], ['=', 'status', 1]]
        _exist, _pool, pages = fetch_all('chatroom_pools', where)
        logger.warning(' chatroom_pools fetch:{} '.format(_pool))
        if _exist:
            chatrooms = _pool
            if len(chatrooms) < num:
                raise Exception('not enough qun.')

            # start save client_qun_r
            #  "client_qun_r": [[["client_id", "chatroomname", "group_id"], "required"], [["client_id", "create_time", "status"], "integer"], [["chatroomname", "group_id"], "string", {"max": 32}]],

            ret = []
            client_qun_r_table = 'client_qun_r'
            while num > 0:
                qun = chatrooms[num - 1]
                num = num - 1
                logger.warning(' check client_qun_r where:{} '.format(
                    {"client_id": client_id, "chatroomname": qun['chatroomname']}))

                _qun_exist, _qun_info = exist(client_qun_r_table + 's',
                                              {"client_id": client_id, "chatroomname": qun['chatroomname']}, 1, 1)

                logger.warning(' check client_qun_r where:{} '.format(_qun_info))

                if _qun_exist:
                    ret.append(qun['chatroomname'])
                    _update_chatroom_pool = _update('chatroom_pool', {'chatroomname': qun['chatroomname']},
                                                    {'chatroomname': qun['chatroomname'], 'status': 0,
                                                     'update_time': int(time.time())})
                    continue

                r_data = {"status": 1, "group_id": str(client_id) + '_0', "create_time": int(time.time()),
                          "chatroomname": qun['chatroomname'], "bot_username": qun['bot_username'],
                          "client_id": client_id}
                url = params['dal_uri'] + client_qun_r_table + 's'
                _response = requests.post(url, data=r_data)

                logger.debug(
                    '[{}]{} response:{}'.format('chatroom_allot', 'save', str(_response.text).replace('\n', '')))

                rsp = dict(_response.json())
                # logger.warning(' chatroom_allot rsp:{} '.format(rsp))
                if rsp['code'] == 0:
                    ret.append(qun['chatroomname'])
                    # update chatroom set status = 0,update = time()
                    _update_chatroom_pool = _update('chatroom_pool', {'chatroomname': qun['chatroomname']},
                                                    {'chatroomname': qun['chatroomname'], 'status': 0,
                                                     'update_time': int(time.time())})
                    # logger.warning('  _update_chatroom_pool ret:{} '.format(_update_chatroom_pool))
            result.update({"data": ret})
        else:
            raise Exception('no chatroom could be allot')

    except Exception as ex:
        # logger.warning('  chatroom_allot ex:{} '.format(ex))
        # traceback.print_exc()
        traceback.print_exc(limit=5, file=sys.stdout)
        result['msg'] = ex.args[0]
        result['code'] = -1

    return response(result)


def _del(table_name, where):
    if not table_name or not where:
        return False
    _exist, _id = exist(table_name + 's', where)
    # logger.warning(' _del where:{},ret:{} '.format(_id, where))
    if not _exist:
        logger.warning('del not find chatroomname:{}')
        return False
    url = params['dal_uri'] + table_name + '/' + _id
    _response = requests.delete(url)
    rsp = dict(_response.json())
    # logger.warning(' _del ret:{} '.format(rsp))
    if rsp['code'] == 0:
        return True
    return False


def _update(table_name, where, _data):
    if not _data or not table_name or not where:
        return False
    _exist, _id = exist(table_name + 's', where)
    if not _exist:
        raise Exception('not find chatroomname')
    url = params['dal_uri'] + table_name + '/' + _id
    _response = requests.put(url, data=_data)
    rsp = dict(_response.json())
    # logger.warning(' _update ret:{} '.format(rsp))
    if rsp['code'] == 0:
        return True, rsp['data']['id']
    return False


@transmission.route('/a_contact', methods=['POST'])
@para_check('username', )
def android_contact():
    __table__ = 'a_contact' + 's'

    # Get values.
    value_as_dict = dict(request.json)

    # Get basic values dict.
    basic_as_dict = {}
    for i in ('username',):
        basic_as_dict[i] = value_as_dict[i]

    # Create task.
    # _exist, unique_id = exist(__table__, basic_as_dict)
    _exist, data_exist = exist(__table__, basic_as_dict, 1, 1)
    if not _exist:
        value_as_dict.update({'create_time': int(time.time()), 'update_time': int(time.time())})
        inner_queue.put(Task('save', value_as_dict, __table__, _from=android_contact.__name__))
    else:
        for key in ("nickname", "quan_pin", "py_initial", "avatar_url"):
            if key in value_as_dict.keys() and key in data_exist.keys() and value_as_dict[key] == "" and data_exist[key] != "":
                value_as_dict[key] = data_exist[key]

        value_as_dict.update({'update_time': int(time.time())})
        inner_queue.put(Task('update', value_as_dict, __table__, data_exist['id'], _from=android_contact.__name__))
    return ' '


@transmission.route('/a_contact_list', methods=['POST'])
def android_contact_list():
    __table__ = 'a_contact' + 's'

    # Get values.
    value_as_dict = dict(request.json)

    # Get basic values dict.
    basic_as_dict = {}
    for i in ('username',):
        basic_as_dict[i] = value_as_dict[i]

    # Create task.
    _exist, unique_id = exist(__table__, basic_as_dict)
    if not _exist:
        value_as_dict.update({'create_time': int(time.time()), 'update_time': int(time.time())})
        inner_queue.put(Task('save', value_as_dict, __table__, _from=android_contact.__name__))
    else:
        value_as_dict.update({'update_time': int(time.time())})
        inner_queue.put(Task('update', value_as_dict, __table__, unique_id, _from=android_contact.__name__))
    return ' '


@transmission.route('/a_chatroom', methods=['POST'])
@para_check('chatroomname', )
def android_chatroom():
    __table__ = 'a_chatroom' + 's'

    # Get values.
    value_as_dict = dict(request.json)

    if value_as_dict.get('qrcode'):
        img_url = put_img_to_oss(value_as_dict['chatroomname'], value_as_dict['qrcode'])
        value_as_dict['qrcode'] = img_url

    # Get basic values dict.
    basic_as_dict = {}
    for i in ('chatroomname',):
        basic_as_dict[i] = value_as_dict[i]

    # Create task.
    # _exist, unique_id = exist(__table__, basic_as_dict)
    _exist, data_exist = exist(__table__, basic_as_dict, 1, 1)
    if not _exist:
        value_as_dict.update(
            {'create_time': int(time.time()), 'update_time': int(time.time()), 'nickname_default': 'default'})
        inner_queue.put(Task('save', value_as_dict, __table__, _from=android_chatroom.__name__))
    else:
        value_as_dict.update({'update_time': int(time.time())})
        for key in ("nickname", "quan_pin", "py_initial", "avatar_url"):
            if key in value_as_dict.keys() and key in data_exist.keys() and value_as_dict[key] == "" and data_exist[key] != "":
                value_as_dict[key] = data_exist[key]

        def pop_blank_nickname_real(_value_as_dict: dict):
            if 'nickname_real' in _value_as_dict:
                if _value_as_dict.copy()['nickname_real'] == '':
                    _value_as_dict.pop('nickname_real')
                if _value_as_dict.copy()['nickname'] == '':
                    _value_as_dict.pop('nickname')
            return _value_as_dict

        value_as_dict = pop_blank_nickname_real(value_as_dict)
        inner_queue.put(Task('update', value_as_dict, __table__, data_exist["id"], _from=android_chatroom.__name__))
    return ' '


@transmission.route('/a_chatroom_r', methods=['POST'])
@para_check('chatroomname', 'bot_username')
def android_chatroom_relationship():
    __table__ = 'a_chatroom_r' + 's'

    # Get values.
    value_as_dict = dict(request.json)

    # Get basic values dict.
    basic_as_dict = {}
    for i in ('chatroomname', 'bot_username'):
        basic_as_dict[i] = value_as_dict[i]

    # Create task.
    _exist, unique_id = exist(__table__, basic_as_dict)
    if not _exist:
        value_as_dict.update({'create_time': int(time.time()), 'update_time': int(time.time())})
        inner_queue.put(Task('save', value_as_dict, __table__, _from=android_chatroom_relationship.__name__))
    else:
        value_as_dict.update({'update_time': int(time.time())})
        inner_queue.put(
            Task('update', value_as_dict, __table__, unique_id, _from=android_chatroom_relationship.__name__))
    return ' '


@transmission.route('/a_friend', methods=['POST'])
@para_check('friends', )
def android_friend():
    __table__ = 'a_friend' + 's'

    # Get values.
    value_as_dict = dict(request.json)

    # Get basic values dict.
    basic_as_dict = {}
    for i in ('friends',):
        basic_as_dict[i] = value_as_dict[i]

    # Create task.
    _exist, unique_id = exist(__table__, basic_as_dict)
    if not _exist:
        value_as_dict.update({'create_time': int(time.time()), 'update_time': int(time.time())})
        inner_queue.put(Task('save', value_as_dict, __table__, _from=android_friend.__name__))
    else:
        value_as_dict.update({'update_time': int(time.time())})
        inner_queue.put(Task('update', value_as_dict, __table__, unique_id, _from=android_friend.__name__))
    return ' '


@transmission.route('/a_member', methods=['POST'])
@para_check('chatroomname', )
def android_member():
    __table__ = 'a_member' + 's'

    # Get values.
    value_as_dict = dict(request.json)

    # Get basic values dict.
    basic_as_dict = {}
    for i in ('chatroomname',):
        basic_as_dict[i] = value_as_dict[i]

    # Create task.
    _exist, unique_id = exist(__table__, basic_as_dict)

    if not _exist:
        value_as_dict.update({'create_time': int(time.time()), 'update_time': int(time.time())})
        # Handle members.
        for i in value_as_dict['members']:
            i.update({'create_time': int(time.time()), 'update_time': int(time.time())})
        inner_queue.put(Task('save', value_as_dict, __table__, _from=android_member.__name__))
    else:
        value_as_dict.update({'update_time': int(time.time())})
        # Handle members.
        try:
            value_as_dict = handle_members(value_as_dict)
        except Exception as e:
            logger.warning('Handle members error:{},values_as_dict:{}'.format(e, value_as_dict))
        inner_queue.put(Task('update', value_as_dict, __table__, unique_id, _from=android_member.__name__))
    return ' '


@transmission.route('/static/material_lib', methods=['POST'])
def material_lib():
    inner_queue.put(
        Task('transmit', request.json, 'None', url='http://%s.com/yaca_api_v2/android/add_material' % winner_bot,
             _from=material_lib.__name__))
    return ' '


@transmission.route('/static/add_friend', methods=['POST'])
def transmit_add_friend():
    inner_queue.put(
        Task('transmit', request.json, 'None', url='http://%s.com/yaca_api_v2/android/add_friend' % winner_bot,
             _from=transmit_add_friend.__name__))

    return ' '


@transmission.route('/static/add_qun', methods=['POST'])
def transmit_add_qun():
    inner_queue.put(
        Task('transmit', request.json, 'None', url='http://%s.com/yaca_api_v2/android/add_qun' % winner_bot,
             _from=transmit_add_qun.__name__))

    return ' '


@transmission.route('/static/add_friend_by_force', methods=['POST'])
def transmit_add_friend_by_force():
    inner_queue.put(
        Task('transmit', request.json, 'None', url='http://%s.com/yaca_api_v2/android/add_friend_by_force' % winner_bot,
             _from=transmit_add_friend_by_force.__name__))

    return ' '


@transmission.route('/test', methods=['POST'])
def transmit_test():
    """Just for test."""
    values_as_dict = dict(request.json)

    inner_queue.put(
        Task('test', values_as_dict, 'None', url='http://47.75.83.5/',
             _from=transmit_test.__name__))

    return ''


"""--------------------------------------------------------------------"""


# Extra api for android.
@transmission.route('/to_oss', methods=['POST'])
@para_check('content', 'title')
def put_android_file_to_oss():
    """For put android file to OSS."""
    _name = str(request.json.get('title'))

    endpoint = 'oss-cn-beijing.aliyuncs.com'
    auth = oss2.Auth('LTAIfwRTXLl6vMbX', 'kvSS9E4Ty7nvHHlGukaknJUtfICuen')
    bucket = oss2.Bucket(auth, endpoint, 'msgfile')
    try:
        bucket.put_object(_name, base64.b64decode(request.json.get('content')))
    except Exception as e:
        logger.warning('[put_android_file_to_oss] %s' % e)
        return response({'err_code': -1, 'err_info': e})

    return response({'err_code': 0, 'content': 'http://msgfile.oss-cn-beijing.aliyuncs.com/' + _name})


@android.route('/check_nickname_and_avatar', methods=['POST'])
@para_check('username_list')
def check_nickname_and_avatar():
    """For android pi to update user_info."""
    try:
        username_list = request.json.get('username_list').split(';')
    except Exception as e:
        logger.warning('[check_nickname_and_avatar] %s' % e)
        return response({'err_code': -1, 'err_info': e})

    all_user_lack_avatar_url = []
    all_user_lack_nickname = []

    user_lack_avatar_url = []
    user_lack_nickname = []

    all_user = []
    """Split 100."""
    temp_index = []
    for i in range(0, len(username_list), 100):
        temp_index.append(i)

    temp_index.append(len(username_list))

    for index, value in enumerate(temp_index):
        if index != len(temp_index) - 1:
            username_list_part = username_list[value: temp_index[index + 1]]
            all_user_part = requests.get(
                '%sa_contacts?select=["avatar_url","nickname","username"]&pageSize=100&page=1&where=["in","username",%s]' % (
                    params['dal_uri'], json.dumps(username_list_part),)).json()['data']
            all_user += all_user_part
    full_info_man = []
    for user_info in all_user:
        if user_info.get('avatar_url') == '':
            all_user_lack_avatar_url.append(user_info['username'])
        if user_info.get('nickname') == '':
            all_user_lack_nickname.append(user_info['username'])
        if user_info['username'] not in all_user_lack_nickname and user_info[
            'username'] not in all_user_lack_avatar_url:
            full_info_man.append(user_info['username'])
    for username in username_list:
        if username in all_user_lack_avatar_url:
            user_lack_avatar_url.append(username)
        if username in all_user_lack_nickname:
            user_lack_nickname.append(username)
        # Add for patch.
        if username not in all_user_lack_avatar_url and username not in all_user_lack_nickname and username != '' and username not in full_info_man:
            user_lack_nickname.append(username)
            user_lack_avatar_url.append(username)

    return response({'nickname_list': user_lack_nickname, 'avatar_url_list': user_lack_avatar_url})


@android.route('/bot_login', methods=["POST"])
@para_check('bot_username')
def bot_login():
    """
    alive_bot_dict_post -> {"bot_username": time}
    :return:
    """
    global alive_bot_dict_post
    global alive_bot_dict
    bot_username = request.json.get('bot_username')
    alive_bot_dict_post[bot_username] = int(time.time())

    status = "0"
    if bot_username in alive_bot_dict and alive_bot_dict[bot_username][1]:
        status = "1"
    return status


@android.route('/bot_status_post', methods=["GET"])
def bot_status_post():
    global alive_bot_dict_post
    res = dict()
    for k, v in alive_bot_dict_post.items():
        res[k] = True if int(time.time()) - v < 30 else False

    return response(res)


@android.route('/get_coin_info', methods=['POST'])
def get_coin_info():
    symbol = request.json.get("symbol", None)
    url = params['dal_uri'] + 'coins?where={"symbol": "' + symbol + '"}'
    coin_info_dict = requests.get(url).json()
    if coin_info_dict.get("code") != 0:
        return ""
    coin_info = coin_info_dict.get("data")[0]
    coin_name, coin_name_cn, price, rank, marketcap, change1d, change7d, volume_ex = \
        coin_info.get("coin_name"), coin_info.get("coin_name_cn"), coin_info.get("price"), coin_info.get("rank"), \
        coin_info.get("marketcap"), coin_info.get("change1d"), coin_info.get("change7d"), coin_info.get("volume_ex")
    msg_send = generate_coin_msg(symbol, coin_name, coin_name_cn, price, rank, marketcap, change1d, change7d, volume_ex)

    return msg_send


"""--------------------------------------------------------------------"""


def put_img_to_oss(file_name, data_as_string):
    """For YouWenBiDa QRcode img."""
    img_name = str(file_name) + '.png'

    endpoint = 'oss-cn-beijing.aliyuncs.com'
    auth = oss2.Auth('LTAIfwRTXLl6vMbX', 'kvSS9E4Ty7nvHHlGukaknJUtfICuen')
    bucket = oss2.Bucket(auth, endpoint, 'ywbdqrimg')
    bucket.put_object(img_name, base64.b64decode(data_as_string))

    return 'http://ywbdqrimg.oss-cn-beijing.aliyuncs.com/' + img_name


def send_request(task):
    """A wrapper to run the task."""
    # logger.debug('threading.active_count : {}'.format(threading.active_count()))
    task.run()


def to_bytes(obj):
    if isinstance(obj, bytes):
        return obj
    elif isinstance(obj, str):
        return obj.encode()
    else:
        raise TypeError('Only support (bytes, str). Type:%s' % type(obj))


def pop_blank_values(value_as_dict):
    """Delete all blank values in value_as_dict."""
    for k, v in value_as_dict.copy().items():
        if v == '':
            value_as_dict.pop(k)

    return value_as_dict


def generate_coin_msg(symbol, coin_name, coin_name_cn, price, rank, marketcap, change1d, change7d, volume_ex):
    """
        名称：ETH（以太坊）
        价格：￥44279.6094
        今日：+4.62%
        七日：+4.62%
        排名：2
        市值：￥7584.48亿
        24h交易：3086.86万
        数据来源：coinmarketcap
        技术支持：友问币答
    """
    res_text = "名称：" + symbol
    if coin_name_cn:
        res_text += '（' + coin_name_cn + '）'

    res_text += '\n'

    # 价格
    price = trim_str(price)
    if "." in price:
        p_split = price.split(".")
        if len(p_split[1]) > 4:
            price = p_split[0] + u"." + p_split[1][:4]
    res_text += u"价格：￥" + price + u"\n"

    # 24小时涨幅计算
    # hour24changed = decimal_to_str(ds_info.change1d)
    hour24changed = trim_str(change1d)
    if hour24changed[0] != "-":
        hour24changed = "+" + hour24changed
    res_text += u"今日：" + hour24changed + u"%\n"

    # 7 日涨幅计算
    # hour24changed = decimal_to_str(ds_info.change1d)
    day7changed = trim_str(change7d)
    if day7changed[0] != "-":
        day7changed = "+" + day7changed
    res_text += u"七日：" + day7changed + u"%\n"

    # 市场排名
    res_text += u"排名：" + str(rank) + u"\n"

    # 市值计算
    marketcap = trim_str(marketcap)
    if "." in marketcap:
        m_s = marketcap.split(".")
        if int(m_s[0]) > 1000000000:
            marketcap = m_s[0][:-8] + u"." + m_s[0][-8:-6] + u"亿"
        elif int(m_s[0]) > 100000:
            marketcap = m_s[0][:-4] + u"." + m_s[0][-4:-2] + u"万"
    res_text += u"市值：￥" + marketcap + u"\n"

    # 24h交易：
    volume = trim_str(volume_ex)
    if "." in volume:
        m_s = volume.split(".")
        if int(m_s[0]) > 1000000000:
            volume = m_s[0][:-8] + u"." + m_s[0][-8:-6] + u"亿"
        elif int(m_s[0]) > 100000:
            volume = m_s[0][:-4] + u"." + m_s[0][-4:-2] + u"万"
    res_text += u"24h交易：￥" + volume + u"\n"

    res_text += u"数据来源：coinmarketcap\n"
    res_text += u"技术支持：友问币答"
    return res_text


def trim_str(a_str):
    if "." in a_str:
        a_split = a_str.split(".")
        while True:
            if len(a_split[1]) == 0:
                return a_split[0] + ".00"
            if a_split[1][-1] == "0":
                a_split[1] = a_split[1][:-1]
            else:
                return a_split[0] + "." + a_split[1]
    else:
        return a_str


"""Open __MAX_THREAD__ thread to handle transmit task."""
while threading.active_count() < __MAX_THREAD__ + 2:
    SendThread().start()
