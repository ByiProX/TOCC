# Import blueprint.
from .api import transmission,android
