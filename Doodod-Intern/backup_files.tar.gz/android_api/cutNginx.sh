#!/bin/bash
# Auto cut nginx log script.
# scofield  2018-7-21

# nginx日志路径 
LOGS_PATH=/home/log/
TODAY=$(date -d 'today' +%Y-%m-%d)
#echo $TODAY

# 移动日志并改名
mv ${LOGS_PATH}/nginx_access.log  ${LOGS_PATH}/access_${TODAY}.log
mv ${LOGS_PATH}/nginx_error.log  ${LOGS_PATH}/error_${TODAY}.log

# 向nginx主进程发送重新打开日志文件的信号
kill -USR1 $(cat /var/run/nginx.pid)
