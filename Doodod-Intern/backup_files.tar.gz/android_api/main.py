"""
main.py
~~~~~~~
EntryPoint for flask.
"""
# Init logger
import os
import logging
from log_conf import init_logger
from utils import verify_logs_folder_exist

here = os.path.abspath(os.path.dirname(__file__))
# init_logger(here, 'android', 'android', mode='a', stream_level=logging.INFO)
verify_logs_folder_exist()

from config import app, __GEVENT__, __PUBLISH__
from gevent import monkey, pywsgi

# Gevent config.
if __GEVENT__:
    monkey.patch_all()

# Register app,Using it's blueprint and database.
from transmission import transmission, android

app.register_blueprint(transmission)
app.register_blueprint(android)

# Get logger.
logger = logging.getLogger('android')


@app.route('/')
def index():
    return 'Index Page.'


if __name__ == '__main__':
    if __GEVENT__:
        logger.info('Server running.')
        server = pywsgi.WSGIServer(('0.0.0.0', 5000), app, debug=not __PUBLISH__)
        server.serve_forever()
    else:
        app.run()
