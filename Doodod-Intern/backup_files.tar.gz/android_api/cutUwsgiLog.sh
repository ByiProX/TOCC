#!/bin/bash
# Auto cut uwsgi log script.
# scofield  2018-7-21

# nginx日志路径 /home/log
LOGS_PATH=/home/log
UWSGI_LOG=${LOGS_PATH}/uwsgi.log
TOUCH_FILE=${LOGS_PATH}/uwsig_touchforlogrotat
TODAY=$(date -d 'today' +%Y-%m-%d)
#echo $TODAY

# 移动日志并改名
mv ${LOGS_PATH}/uwsgi.log  ${LOGS_PATH}/uwsgi_${TODAY}.log

# 向nginx主进程发送重新打开日志文件的信号
touch $TOUCH_FILE
