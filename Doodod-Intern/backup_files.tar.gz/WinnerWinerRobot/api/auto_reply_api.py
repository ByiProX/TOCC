# -*- coding: utf-8 -*-

import logging
from flask import request

from configs.config import SUCCESS, ERR_INVALID_PARAMS, main_api
from core.auto_reply_core import create_a_auto_reply_setting, switch_func_auto_reply, delete_a_auto_reply_setting, \
    get_auto_reply_setting, update_a_tuto_reply_setting
from core.user_core import UserLogin
from utils.u_response import make_response

logger = logging.getLogger('main')


@main_api.route('/create_a_auto_reply_setting', methods=['POST'])
def app_create_a_auto_reply_setting():
    """
    创建一个任务
    :return:
    """
    status, user_info = UserLogin.verify_token(request.json.get('token'))
    if status != SUCCESS:
        return make_response(status)

    chatroom_list = request.json.get('chatroom_list')
    if not chatroom_list:
        return make_response(ERR_INVALID_PARAMS)
    message_list = request.json.get('message_list')
    if not message_list:
        return make_response(ERR_INVALID_PARAMS)
    keyword_list = request.json.get('keyword_list')
    if not keyword_list:
        return make_response(ERR_INVALID_PARAMS)

    # 注：此处，如果有setting时，则意味着此处为修改，如果没有，则意味着此处为新建
    # 文法和磊的临时约定 BY FRank5433 20180210
    setting_id = request.json.get('setting_id')
    if setting_id:
        status = update_a_tuto_reply_setting(user_info, chatroom_list, message_list, keyword_list, setting_id)
    else:
        status = create_a_auto_reply_setting(user_info, chatroom_list, message_list, keyword_list)
    if status == SUCCESS:
        return make_response(SUCCESS)
    else:
        return make_response(status)


@main_api.route('/switch_func_auto_reply', methods=['POST'])
def app_switch_func_auto_reply():
    status, user_info = UserLogin.verify_token(request.json.get('token'))
    if status != SUCCESS:
        return make_response(status)

    switch = request.json.get('switch')
    if not (switch is True or switch is False):
        return make_response(ERR_INVALID_PARAMS)

    status = switch_func_auto_reply(user_info, switch)
    if status == SUCCESS:
        return make_response(SUCCESS)
    else:
        return make_response(status)


@main_api.route('/get_auto_reply_setting', methods=['POST'])
def app_get_auto_reply_setting():
    status, user_info = UserLogin.verify_token(request.json.get('token'))
    if status != SUCCESS:
        return make_response(status)

    status, res = get_auto_reply_setting(user_info)

    if status == SUCCESS:
        return make_response(SUCCESS, setting_info=res, func_auto_reply=user_info.func_auto_reply)
    else:
        return make_response(status)


@main_api.route('/delete_a_auto_reply_setting', methods=['POST'])
def app_delete_a_auto_reply_setting():
    status, user_info = UserLogin.verify_token(request.json.get('token'))
    if status != SUCCESS:
        return make_response(status)

    setting_id = request.json.get('setting_id')
    if not setting_id:
        return make_response(ERR_INVALID_PARAMS)

    status = delete_a_auto_reply_setting(user_info, setting_id)
    if status == SUCCESS:
        return make_response(SUCCESS)
    else:
        return make_response(status)
