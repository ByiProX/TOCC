# -*- coding: utf-8 -*-
import copy
import datetime
import json
import logging
import threading
import time
import traceback
from xml.etree import ElementTree

import requests

from configs.config import *
from core_v2.ad_check_core import check_msg_is_an_ad
from core_v2.coin_wallet_core import check_whether_message_is_a_coin_wallet
from core_v2.matching_rule_core import get_gm_default_rule_dict, match_message_by_rule, get_gm_rule_dict
from core_v2.qun_manage_core import check_whether_message_is_add_qun, check_is_removed
from core_v2.qun_pulled_core import pull_people_to_chatroom
from core_v2.real_time_quotes_core import match_message_by_coin_keyword, match_general_message
from core_v2.redis_core import rds_lpush
from models_v2.base_model import BaseModel, CM
from utils.tag_handle import Tag
from utils.u_transformat import str_to_unicode, unicode_to_str

logger = logging.getLogger('main')


def start_listen_new_msg():
    logger.info("start_listen_new_msg")
    new_msg_thread = threading.Thread(target=route_and_count_msg)
    new_msg_thread.setDaemon(True)
    new_msg_thread.start()


def route_and_count_msg():
    gm_rule_dict = get_gm_rule_dict()
    gm_default_rule_dict = get_gm_default_rule_dict()
    while True:
        try:
            print 000
            a_message = NEW_MSG_Q.get()
            logger.info(u"NEW_MSG_Q get ret : %s. " % a_message.to_json())
            print 111
            if GLOBAL_RULES_UPDATE_FLAG[GLOBAL_USER_MATCHING_RULES_UPDATE_FLAG]:
                gm_rule_dict = get_gm_rule_dict()
                GLOBAL_RULES_UPDATE_FLAG[GLOBAL_USER_MATCHING_RULES_UPDATE_FLAG] = False
            if GLOBAL_RULES_UPDATE_FLAG[GLOBAL_MATCHING_DEFAULT_RULES_UPDATE_FLAG]:
                gm_default_rule_dict = get_gm_default_rule_dict()
                GLOBAL_RULES_UPDATE_FLAG[GLOBAL_MATCHING_DEFAULT_RULES_UPDATE_FLAG] = False
            if GLOBAL_RULES_UPDATE_FLAG[GLOBAL_SENSITIVE_WORD_RULES_UPDATE_FLAG]:
                update_sensitive_word_list()
                GLOBAL_RULES_UPDATE_FLAG[GLOBAL_SENSITIVE_WORD_RULES_UPDATE_FLAG] = False
            if GLOBAL_RULES_UPDATE_FLAG[GLOBAL_EMPLOYEE_PEOPLE_FLAG]:
                update_employee_people_list()
                GLOBAL_RULES_UPDATE_FLAG[GLOBAL_EMPLOYEE_PEOPLE_FLAG] = False

            print 222
            route_msg(a_message, gm_rule_dict, gm_default_rule_dict)
            print 333
            count_msg(a_message)
        except:
            logger.error(u"route_and_count_msg error")


def get_all_bots():
    try:
        req = requests.get(ANDROID_SERVER_URL_BOT_STATUS)
        return json.loads(req.content)
    except:
        return {}


def route_msg(a_message, gm_rule_dict, gm_default_rule_dict):
    logger.info("route msg")

    # 这个机器人说的话
    # TODO 当有两个机器人的时候，这里不仅要判断是否是自己说的，还是要判断是否是其他机器人说的
    if a_message.is_send == 1 or a_message.real_talker in get_all_bots().keys():
        return

    # Check this chatroom's client.
    try:
        status_dict = chatroom_client_info(a_message)
        print(status_dict)
    except Exception as e:
        print(e)
        status_dict = Tag(0).get_name_dict()

    # by quentin
    # 发广告者，被提醒并被踢
    # print ">>>>>>>>>>>>>>>>>>>>>>>广告要来啦"
    # TODO-Arthas: 1. 添加开关，默认 False  2. 已有 client 状态初始化关

    is_ad = check_msg_is_an_ad(a_message, switch = status_dict.get('ad'))
    if is_ad:
        return

    # 判断这个机器人说的话是否是文字或系统消息
    if a_message.type == MSG_TYPE_TXT or a_message.type == MSG_TYPE_SYS or a_message.type == MSG_TYPE_ENTERCHATROOM:
        pass
    else:
        return
    

    # Check events add person.
    if a_message.type == MSG_TYPE_ENTERCHATROOM and a_message.content.find(u'修改群名') == -1:
        is_chatroom_add_people, _1, _2, _3 = _extract_enter_chatroom_msg(a_message.content)
        if is_chatroom_add_people == SUCCESS:
            check_events_send_word(a_message)

    # Check chatroom word.
    if not a_message.is_to_friend and a_message.type == MSG_TYPE_TXT:
        if status_dict.get('sensitive'):
            check_and_add_sensitive_word_log(a_message)
        check_if_is_reply(a_message)
        # Check if @ someone in rule list.
        if a_message.be_at_list:
            check_or_add_at_log(a_message)
        # Check if is RE text.
        check_if_is_re(a_message)

    # Check if pull people word.
    if a_message.is_to_friend and a_message.type == MSG_TYPE_TXT:
        check_to_pull_people(a_message)

    # by quentin
    # 群成员添加机器人为好友，并给机器人回复关键字后，机器人自动拉群成员进相应的群
    if a_message.is_to_friend and a_message.type == MSG_TYPE_TXT:
        print ">>>>>>>>>>>>>>>>>>>即将进入拉人进群函数"
        pull_people_to_chatroom(a_message, switch=True)

    # is_add_friend
    # is_add_friend = check_whether_message_is_add_friend(message_analysis)
    # if is_add_friend:
    #     continue

    # 检查信息是否为加了一个群
    ##########################
    # modified by quentin 绑定群功能提到了外层，即a_message入口处,现在拿回原处
    if a_message.type == MSG_TYPE_ENTERCHATROOM:
        is_add_qun = check_whether_message_is_add_qun(a_message)
        if is_add_qun:
            print('is_add_qun')
            return

    ################

    # is_removed
    if a_message.type == MSG_TYPE_SYS:
        is_removed = check_is_removed(a_message)
        if is_removed:
            print('is_removed')
            return

    # #scofield change a_message bot_username
    # bot_name = get_master_bot(a_message.talker,a_message.bot_username)
    # logger.info("scofield get_master_bot  %s"  % bot_name)
    # if not bot_name:
    #     return
    # else:
    #     a_message.bot_username = bot_name

    # is_a_coin_wallet
    if a_message.type == MSG_TYPE_TXT:
        if status_dict.get('wallet'):
            is_a_coin_wallet = check_whether_message_is_a_coin_wallet(a_message)
            if is_a_coin_wallet:
                return



    # 检测是否是别人的进群提示
    # is_friend_into_qun = check_whether_message_is_friend_into_qun(a_message)

    # 因网络原因，收到严重滞后的消息不予回复
    if a_message.type == MSG_TYPE_TXT:
        now_time = int(time.time())
        if a_message.create_time + DEFAULT_NETWORK_DELAY >= now_time:
            # 根据规则和内容进行匹配，并生成任务
            if status_dict.get('auto_reply'):
                rule_status = match_message_by_rule(gm_rule_dict, a_message)
                if rule_status is True:
                    return
                else:
                    pass

            # 对内容进行判断，是否为查询比价的情况
            if status_dict.get('coin'):
                coin_price_status = match_message_by_coin_keyword(gm_default_rule_dict, a_message)
                if coin_price_status is True:
                    return

            # add by quentin
            # 非以上特殊内容的自动回复,即对普通内容的自动回复，目前设置为FALSE不回复
            # TODO : 如要开启，将reply改为True
            status = match_general_message(a_message, reply=False)
            if status:
                return
            ###########
        else:
            logger.info(u'Detect delay message!')


def count_msg(msg):
    logger.info("count msg")
    if msg.is_to_friend:
        pass
    else:
        content = str_to_unicode(msg.content)
        chatroomname = msg.talker
        username = msg.real_talker
        msg_type = msg.type
        # logger.info(u"msg content is : %s. " % msg.to_json())
        # logger.info(u"msg id is : %s. " % msg.get_id())

        # be_at_list
        is_at = False
        if msg.be_at_list:
            logger.info(u'| be_at_list')
            is_at = True
            be_at_list = msg.be_at_list.split(u",")
            at_count = len(be_at_list)

            chat_logs_type = CHAT_LOGS_TYPE_3
            content = json.dumps(be_at_list)
            rds_lpush(chat_logs_type, msg.get_id(), msg.client_id, msg.talker, msg.real_talker, msg.create_time, content)
            return

        # if msg_type == CONTENT_TYPE_TXT and content.find(u'@') != -1:
        #     logger.info(u'| be_at_count')
        #     is_at, at_count = extract_msg_be_at(msg, chatroomname)
        #     if is_at:
        #         return

        if msg_type == MSG_TYPE_ENTERCHATROOM and content.find(u'修改群名') == -1:
            content = str_to_unicode(msg.real_content)
            status, invitor_username, invitor_nickname, invited_username_list = _extract_enter_chatroom_msg(content)
            if status == SUCCESS:
                if content.find(u'邀请你') != -1:
                    invited_username_list.append(msg.bot_username)
                chat_logs_type = CHAT_LOGS_TYPE_1
                content = json.dumps(invited_username_list)
                rds_lpush(chat_logs_type, msg.get_id(), msg.client_id, msg.talker, invitor_username, msg.create_time, content)
            else:
                rds_lpush(chat_logs_type=CHAT_LOGS_ERR_TYPE_0, msg_id=msg.get_id(), client_id = msg.client_id, err=True)

            return

        chat_logs_type = CHAT_LOGS_TYPE_2
        rds_lpush(chat_logs_type, msg.get_id(), msg.client_id, chatroomname, username, msg.create_time, content)

        # 被邀请入群
        # Content="frank5433"邀请你和"秦思语-Doodod、磊"加入了群聊
        # "Sw-fQ"邀请你加入了群聊，群聊参与人还有：qiezi、Hugh、蒋郁、123
        # if content.find(u'邀请你') != -1:
        #     logger.info(u'invite_bot')
        #     invite_bot(msg)
        # 其他人入群：邀请、扫码
        # "斗西"邀请"陈若曦"加入了群聊
        # " BILL"通过扫描"谢工@GitChat&图灵工作用"分享的二维码加入群聊
        # "風中落葉🍂"邀请"大冬天的、追忆那年的似水年华、往事随风去、搁浅、陈梁～HILTI"加入了群聊
        # elif content.find(u'加入了群聊') != -1 or content.find(u'加入群聊') != -1:
        #     logger.info(u'invite_other')
        #     invite_other(msg)


def extract_msg_be_at(msg, chatroomname):
    at_count = 0
    is_at = False
    member_be_at_list = list()
    content = str_to_unicode(msg.real_content)
    content_tmp = copy.deepcopy(content)

    if content_tmp.find(u'@') != -1:
        is_at = True
        content_index = 0
        while content_tmp[content_index:].find(u'@') != -1:
            offset = content_index + content_tmp[content_index:].find(u'@') + 1
            end_index = 0
            if content_tmp[content_index:].find(u'\u2005') == -1:
                content_tmp = content_tmp.replace(u' ', u'\u2005')
                # print content_tmp.__repr__()
            while content_tmp[offset + end_index:].find(u'\u2005') != -1:
                end_index += content_tmp[offset + end_index:].find(u'\u2005') + 1
                name_be_at = content_tmp[offset:offset + end_index - 1]
                if name_be_at == u'':
                    is_at = False
                    break
                if name_be_at.find(u'\u2005') != -1:
                    name_be_at = name_be_at.replace(u'\u2005', u' ')
                logger.debug(u'nick_name_be_at: ' + name_be_at)
                member_be_at = fetch_member_by_nickname(chatroomname=chatroomname,
                                                        nickname=name_be_at, update_flag=False)
                # 匹配到 member
                if member_be_at:
                    logger.info(u'member_be_at ' + unicode(member_be_at))
                    is_at = True
                    offset += end_index
                    member_be_at_list.append(member_be_at)
                    at_count += 1
                    break
                else:
                    logger.info(u'really not find ' + name_be_at)
                    rds_lpush(chat_logs_type=CHAT_LOGS_ERR_TYPE_0, msg_id=msg.get_id(), client_id = msg.client_id, err=True)
                    # Mark 一个异常，全部异常
                    return False, None
            content_index = offset

    if is_at and member_be_at_list:
        chat_logs_type = CHAT_LOGS_TYPE_3
        content = json.dumps(member_be_at_list)
    else:
        chat_logs_type = CHAT_LOGS_TYPE_2
        content = ""
    rds_lpush(chat_logs_type, msg.get_id(), msg.client_id, msg.talker, msg.real_talker, msg.create_time, content)
    return is_at, at_count


def _extract_enter_chatroom_msg(content):
    content = content.split(u":\n")[1].replace("\t", "").replace("\n", "")
    invitor_username = None
    invitor_nickname = None
    invited_username_list = list()
    content = unicode_to_str(content)
    try:
        etree_msg = ElementTree.fromstring(content)
        etree_link_list = etree_msg.iter(tag="link")
        for etree_link in etree_link_list:
            # print etree_link.get("name")
            link_name = etree_link.get("name")
            etree_member_list = etree_link.find("memberlist")
            if etree_member_list:
                for member in etree_member_list:
                    for attr in member:
                        if attr.tag == "username":
                            if link_name == "username":
                                invitor_username = attr.text
                            elif link_name == "names":
                                invited_username_list.append(attr.text)
                            elif link_name == "adder":
                                invited_username_list.append(attr.text)
                            elif link_name == "from":
                                invitor_username = attr.text

        return SUCCESS, invitor_username, invitor_nickname, invited_username_list
    except Exception as e:
        logger.warning("邀请进群解析失败")
        logger.warning(traceback.format_exc())
        return err.ERR_UNKNOWN_ERROR, None, None, None


# def invite_bot(msg):
#     content = str_to_unicode(msg.real_content)
#     status, invitor_username, invitor_nickname, invited_username_list = _extract_enter_chatroom_msg(content)
#     if status == SUCCESS:
#         chat_logs_type = CHAT_LOGS_TYPE_1
#         content = json.dumps(invited_username_list)
#         rds_lpush(chat_logs_type, msg.get_id(), msg.talker, invitor_username, msg.create_time, content)
#     else:
#         rds_lpush(chat_logs_type = CHAT_LOGS_ERR_TYPE_0, msg_id = msg.get_id(), err = True)

# content_tmp = copy.deepcopy(content)
# invitor_nick_name = content_tmp.split(u'邀请')[0][1:-1]
# logger.debug(u'invitor_nick_name: ' + invitor_nick_name)
#
# invited_username_list = list()
# invited_username_list.append(msg.bot_username)
#
# invited_nick_name_list = list()
# if content_tmp.find(u'邀请你和') != -1:
#     start_index = content_tmp.find(u'邀请你和')
#     end_index = content_tmp.rfind(u'"加入')
#     invited_nick_names = content_tmp[start_index + 5:end_index]
#     invited_nick_name_list = invited_nick_names.split(u'、')
#
# invitor = fetch_member_by_nickname(chatroomname = chatroomname,
#                                    nickname = invitor_nick_name)
# if invitor:
#     for invited_nick_name in invited_nick_name_list:
#         logger.debug(u'invited_nick_name: ' + invited_nick_name)
#         invited = fetch_member_by_nickname(chatroomname = chatroomname,
#                                            nickname = invited_nick_name)
#         if invited:
#             logger.info(u'invited ' + unicode(invited))
#             invited_username_list.append(invited)
#         else:
#             logger.info(u'really not find ' + invited_nick_name)
#             rds_lpush(chat_logs_type = CHAT_LOGS_ERR_TYPE_0, msg_id = msg.get_id(), err = True)
#             # Mark 一个异常，全部异常
#             return
#
#     chat_logs_type = CHAT_LOGS_TYPE_1
#     content = json.dumps(invited_username_list)
#     rds_lpush(chat_logs_type, msg.get_id(), msg.talker, invitor, msg.create_time, content)
#
#
# def invite_other(msg, chatroomname):
#     content = str_to_unicode(msg.real_content)
#     content_tmp = copy.deepcopy(content)
#     print u''
#     if content_tmp.find(u'邀请') != -1:
#         invitor_nick_name = content_tmp.split(u'邀请')[0][1:-1]
#         logger.debug(u'invitor_nick_name: ' + invitor_nick_name)
#         # "斗西"邀请"陈若曦"加入了群聊
#         # "風中落葉🍂"邀请"大冬天的、追忆那年的似水年华、往事随风去、搁浅、陈梁～HILTI"加入了群聊
#         start_index = content_tmp.find(u'邀请')
#         end_index = content_tmp.rfind(u'"加入')
#         invited_nick_names = content_tmp[start_index + 3:end_index]
#         invited_nick_name_list = invited_nick_names.split(u'、')
#
#     # " BILL"通过扫描"谢工@GitChat&图灵工作用"分享的二维码加入群聊
#     elif content_tmp.find(u'通过扫描') != -1:
#         nick_names = content_tmp.split(u'通过扫描')
#         invited_nick_name = nick_names[0][2:-1]
#         end_index = nick_names[1].rfind(u'"分享')
#         invitor_nick_name = nick_names[1][1:end_index]
#         logger.debug(u'invitor_nick_name: ' + invitor_nick_name)
#         invited_nick_name_list = [invited_nick_name]
#     else:
#         logger.info(u'unknown invite type: ')
#         logger.info(msg.content)
#         return
#
#     invited_username_list = list()
#     invitor = fetch_member_by_nickname(chatroomname = chatroomname,
#                                        nickname = invitor_nick_name)
#     if invitor:
#         for invited_nick_name in invited_nick_name_list:
#             logger.debug(u'invited_nick_name: ' + invited_nick_name)
#             invited = fetch_member_by_nickname(chatroomname = chatroomname,
#                                                nickname = invited_nick_name)
#             if invited:
#                 logger.info(u'invited ' + unicode(invited))
#                 invited_username_list.append(invited)
#             else:
#                 logger.info(u'really not find ' + invited_nick_name)
#                 rds_lpush(chat_logs_type = CHAT_LOGS_ERR_TYPE_0, msg_id = msg.get_id(), err = True)
#                 # Mark 一个异常，全部异常
#                 return
#
#         if invited_username_list:
#             chat_logs_type = CHAT_LOGS_TYPE_1
#             content = json.dumps(invited_username_list)
#             rds_lpush(chat_logs_type, msg.get_id(), msg.talker, invitor, msg.create_time, content)


def fetch_member_by_nickname(chatroomname, nickname, update_flag=True):
    # Mark 结果上并不需要 bot_username 限定好友范围
    member1 = None
    if nickname:
        # 匹配 AMember
        a_member = BaseModel.fetch_one(Member, "*", where_clause=BaseModel.where_dict({"chatroomname": chatroomname}))
        if not a_member:
            return member1
        members = a_member.members
        for member in members:
            # Mark 不处理匹配到多个的情况
            if member.get("displayname") == nickname:
                return member.get("username")
        member_usernames = [member.get("username") for member in members]
        a_contact_list = BaseModel.fetch_all(Contact, "*", where_clause=BaseModel.where_dict({"nickname": nickname}))
        for a_contact in a_contact_list:
            if a_contact.username in member_usernames:
                return a_contact.username
        # a_contact_list = BaseModel.fetch_all(Contact, ["username", "nickname"],
        #                                      where_clause=BaseModel.where("in", "username", member_usernames))
        # for a_contact in a_contact_list:
        #     # Mark 不处理匹配到多个的情况
        #     if a_contact.nickname == nickname:
        #         return a_contact.username

    if update_flag:
        update_members(chatroomname)
        return fetch_member_by_nickname(chatroomname, nickname, update_flag=False)
    return member1


def update_members(chatroomname, create_time=None, save_flag=False):
    # a_contact_chatroom = db.session.query(AContact).filter(AContact.username == chatroomname).first()
    # if not a_contact_chatroom:
    #     logger.error(u'Not found chatroomname in AContact: %s.' % chatroomname)
    #     return
    # old_members = db.session.query(MemberInfo.username).filter(MemberInfo.chatroomname == chatroomname).all()
    # # old_member_dict = {old_member.username: old_member for old_member in old_members}
    # old_member_username_set = {old_member.username for old_member in old_members}
    # a_member_list = db.session.query(AMember).filter(AMember.chatroomname == chatroomname).all()
    # for a_member in a_member_list:
    #     if a_member.username in old_member_username_set:
    #         pass
    #     else:
    #         old_member_username_set.add(a_member.username)
    #         new_member_info = MemberInfo(member_id = a_member.id, chatroomname = chatroomname,
    #                                      username = a_member.username, chatroom_id = a_contact_chatroom.id) \
    #             .generate_create_time(create_time)
    #
    #         MemberOverview.init_all_scope(member_id = a_member.id, chatroom_id = a_contact_chatroom.id,
    #                                       chatroomname = chatroomname, username = a_member.username)
    #         db.session.merge(new_member_info)
    #
    # update_chatroom_members_info(chatroomname)
    # if save_flag:
    #     db.session.commit()
    pass


def check_and_add_sensitive_word_log(a_message):
    # Check if in this chatroom.
    monitor_chatroom_list = SENSITIVE_WORD_RULE_DICT.keys()
    talk_chatroom = a_message.talker
    a_message_content = a_message.real_content

    if talk_chatroom not in monitor_chatroom_list:
        return 0
    all_rule = SENSITIVE_WORD_RULE_DICT[talk_chatroom]
    for rule in all_rule:
        sensitive_word_list = rule[0]
        owner_list = rule[1]
        for sensitive_word in sensitive_word_list:
            if sensitive_word in a_message_content:
                # Catch a sensitive word.
                for owner in owner_list:
                    if owner != a_message.client_id:
                        continue
                    new_thread = threading.Thread(target=add_and_send_sensitive_word_log,
                                                  args=(
                                                      sensitive_word, a_message, owner, rule[2]))
                    new_thread.setDaemon(True)
                    new_thread.start()

    return 0


def update_sensitive_word_list():
    """
    SENSITIVE_WORD_RULE_DICT:
    {
        "chatroomname":[[sensitive_word_list,owner_list,rule_id],[sensitive_word_list,owner_list,rule_id],]
    }
    More:
    owner -> client_id
    """
    rule_list = BaseModel.fetch_all('sensitive_message_rule', '*', BaseModel.where_dict({'is_work': 1}))
    global SENSITIVE_WORD_RULE_DICT
    SENSITIVE_WORD_RULE_DICT = {}

    for rule in rule_list:
        for chatroomname in rule.chatroom_name_list:
            if SENSITIVE_WORD_RULE_DICT.get(chatroomname) is None:
                # Create new rule.
                SENSITIVE_WORD_RULE_DICT[chatroomname] = [
                    [rule.sensitive_word_list, rule.owner_list, rule.sensitive_message_rule_id], ]
            else:
                # Update.
                new_rule = True
                for i in SENSITIVE_WORD_RULE_DICT[chatroomname]:
                    if rule.sensitive_message_rule_id == i[2]:
                        new_rule = False
                if new_rule:
                    SENSITIVE_WORD_RULE_DICT[chatroomname].append(
                        [rule.sensitive_word_list, rule.owner_list, rule.sensitive_message_rule_id])


def update_employee_people_list():
    """Update 1.be at func rule 2.regular expression rule.

    EMPLOYEE_PEOPLE_BE_AT_RULE_DICT ->
     {
     "@nickname" : [ ["username",by_client_id] , ["username",by_client_id]]
     }
    EMPLOYEE_PEOPLE_RE_RULE_DICT ->
    {
    "username" : [ ("text_line_1","text_line_2", ...), ("text_line_1","text_line_2", ...), ]
    }
    """
    print('update_employee_people_list running')
    people_list = BaseModel.fetch_all('employee_people', '*')
    global EMPLOYEE_PEOPLE_BE_AT_RULE_DICT
    global EMPLOYEE_PEOPLE_RE_RULE_DICT
    EMPLOYEE_PEOPLE_BE_AT_RULE_DICT = {}
    EMPLOYEE_PEOPLE_RE_RULE_DICT = {}
    for man in people_list:
        if man.tag_list == [0, ]:
            continue
        man_username = man.username
        # Update EMPLOYEE_PEOPLE_RE_RULE_DICT.
        if EMPLOYEE_PEOPLE_RE_RULE_DICT.get(man_username) is None:
            EMPLOYEE_PEOPLE_RE_RULE_DICT[man_username] = make_re_text(man.tag_list, man.by_client_id)
        else:
            previous_rule = EMPLOYEE_PEOPLE_RE_RULE_DICT[man_username]
            EMPLOYEE_PEOPLE_RE_RULE_DICT[man_username] = make_re_text(man.tag_list, man.by_client_id, previous_rule)

        EMPLOYEE_PEOPLE_BE_AT_RULE_DICT.setdefault(man_username, list())
        EMPLOYEE_PEOPLE_BE_AT_RULE_DICT[man_username].append(man.by_client_id)

        # # Update EMPLOYEE_PEOPLE_BE_AT_RULE_DICT.
        # man_info = BaseModel.fetch_one('a_contact', '*', BaseModel.or_(['=', 'alias', man_username],
        #                                                                ['=', 'username', man_username], ))
        # if man_info is None:
        #     print('-----update_employee_people_list ERROR:', man_username)
        #     continue
        # man_nickname = man_info.nickname
        #
        # if EMPLOYEE_PEOPLE_BE_AT_RULE_DICT.get(u'@' + man_nickname) is None:
        #     EMPLOYEE_PEOPLE_BE_AT_RULE_DICT[u'@' + man_nickname] = [[man_username, man.by_client_id], ]
        # else:
        #     EMPLOYEE_PEOPLE_BE_AT_RULE_DICT[u'@' + man_nickname].append([man_username, man.by_client_id])

    # print('1-----------', EMPLOYEE_PEOPLE_BE_AT_RULE_DICT)
    # print('2-----------', EMPLOYEE_PEOPLE_RE_RULE_DICT)


def update_employee_people_reply_rule():
    print('----- update_employee_people_reply_rule running')
    global REPLY_RULE_DICT
    REPLY_RULE_DICT = {}
    time_limit = int(time.time()) - 86400
    all_need_to_reply = BaseModel.fetch_all('employee_be_at_log', '*', BaseModel.and_(["=", "is_reply", 0],
                                                                                      [">", "create_time",
                                                                                       time_limit]), )
    for i in all_need_to_reply:
        username = i.username
        chatroomname = i.chatroomname
        create_time = i.create_time
        its_id = i.get_id()
        REPLY_RULE_DICT[chatroomname] = (username, create_time, its_id)
    print(REPLY_RULE_DICT)


def add_and_send_sensitive_word_log(sensitive_word, new_a_message, owner, rule_id):
    """
    Pass
    :param sensitive_word:
    :param new_a_message:
    :param owner: client_id
    :param rule_id:
    :return:
    """
    print("---add_and_send_sensitive_word_log---")

    def send_message(_bot_username, to, _type, content):
        result = {'bot_username': _bot_username,
                  'data': {
                      "task": "send_message",
                      "to": to,
                      "type": _type,
                      "content": content,
                  }}
        resp = requests.post(ANDROID_SERVER_URL_SEND_MESSAGE, json=result)
        if dict(resp.json())['err_code'] == -1:
            logger.warning('add_and_send_sensitive_word_log ERROR,because bot dead!')

    def get_owner_bot_username(_owner):
        # Get owner's bot_username
        bot_status_dict = requests.get(ANDROID_SERVER_URL_BOT_STATUS).json()
        _client_id = _owner
        client_bot_r = BaseModel.fetch_all('client_bot_r', '*', BaseModel.where_dict({'client_id': _client_id}))
        for i in client_bot_r:
            if bot_status_dict.get(i.bot_username):
                return i.bot_username
        print('get_owner_bot_username Error! because all bots dead!')
        return ''

    new_log = CM("sensitive_message_log")
    new_log.create_time = int(time.time())

    new_log.rule_id = rule_id
    new_log.a_message_id = new_a_message.a_message_id
    new_log.owner = owner
    new_log.sensitive_word = sensitive_word

    new_log.chatroomname = new_a_message.talker
    new_log.speaker_username = new_a_message.real_talker
    new_log.content = new_a_message.real_content

    new_log.save()

    # Send this log.
    owner_bot_username = get_owner_bot_username(owner)
    speaker = BaseModel.fetch_one('a_contact', '*', BaseModel.where_dict({'username': new_a_message.real_talker}))
    speaker_chatroom = BaseModel.fetch_one('a_chatroom', '*',
                                           BaseModel.where_dict({'chatroomname': new_a_message.talker}))

    speaker_nickname = speaker.nickname if speaker else u'None'
    chatroom_nickname = speaker_chatroom.nickname_real if speaker_chatroom else u'None'

    message_content = u'时间:%s\n' \
                      u'说话人:%s\n' \
                      u'所在群:%s\n' \
                      u'敏感词:%s\n' \
                      u'敏感内容:%s\n' % (
                          unicode(datetime.datetime.now())[:-7], str_to_unicode(speaker_nickname),
                          str_to_unicode(chatroom_nickname), str_to_unicode(sensitive_word),
                          str_to_unicode(new_a_message.real_content))
    user = BaseModel.fetch_one('client_member', '*', BaseModel.where_dict({'client_id': owner}))
    if user is None:
        logger.warning('can not find this client', owner)
        return -1
    username = user.username

    send_message(owner_bot_username, username, 1, message_content)


def check_or_add_at_log(a_message):
    """
    EMPLOYEE_PEOPLE_BE_AT_RULE_DICT ->
     {
     "@nickname" : [ ["username",by_client_id] , ["username",by_client_id]]
     }
    """
    be_at_list = a_message.be_at_list.split(u",")
    real_content = str_to_unicode(a_message.real_content)
    at_rule_list = EMPLOYEE_PEOPLE_BE_AT_RULE_DICT.keys()

    for be_at_username in be_at_list:
        if be_at_username in at_rule_list:
            for by_client_id in EMPLOYEE_PEOPLE_BE_AT_RULE_DICT[be_at_username]:
                if by_client_id != a_message.client_id:
                    continue
                new_thread = threading.Thread(target = add_employee_at_log,
                                              args = (
                                                  be_at_username, real_content,
                                                  a_message.a_message_id, a_message.talker, by_client_id))
                new_thread.setDaemon(True)
                new_thread.start()

    # for i in at_rule_list:
    #     # Delete u'' because real_content diff.
    #     if i + u'\u2005' in real_content or i + u' ' in real_content:
    #         for j in EMPLOYEE_PEOPLE_BE_AT_RULE_DICT[i]:
    #             # print('At log:', j, real_content)
    #             username = j[0]
    #             by_client_id = j[1]
    #             new_thread = threading.Thread(target=add_employee_at_log,
    #                                           args=(
    #                                               username, real_content,
    #                                               a_message.a_message_id, a_message.talker, by_client_id))
    #             new_thread.setDaemon(True)
    #             new_thread.start()
    return 0


def check_if_is_reply(a_message):
    print('------check_if_is_reply')
    chatroomname = a_message.talker
    username = a_message.real_talker
    if chatroomname in REPLY_RULE_DICT and username == REPLY_RULE_DICT[chatroomname][0] \
            and int(time.time()) < REPLY_RULE_DICT[chatroomname][1] + 86400:
        new_thread = threading.Thread(target=add_reply_employee_at_log, args=(username, chatroomname,))
        new_thread.setDaemon(True)
        new_thread.start()


def check_if_is_re(a_message):
    real_talker = a_message.real_talker
    real_content = a_message.real_content
    if real_talker in EMPLOYEE_PEOPLE_RE_RULE_DICT.keys() and len(EMPLOYEE_PEOPLE_RE_RULE_DICT[real_talker]):
        re_text_list = EMPLOYEE_PEOPLE_RE_RULE_DICT[real_talker]
        for i in range(len(re_text_list)):
            if isinstance(re_text_list[i][0], int):
                continue
            if real_content.find(re_text_list[i][0]) == 0:
                print('----- Catch', real_content)
                real_content_seq = real_content.split(u'\n')
                by_client_id = re_text_list[i][-1]
                for index, value in enumerate(re_text_list[i]):
                    if len(re_text_list[i]) == i + 1:
                        break
                    if len(re_text_list[i]) - 1  != len(real_content_seq):
                        print('----- Not right length')
                        new_thread = threading.Thread(target=add_wrong_re_log,
                                                      args=(
                                                          real_talker, real_content,
                                                          a_message.a_message_id, a_message.talker, by_client_id))
                        new_thread.setDaemon(True)
                        new_thread.start()
                        break
                    if index == len(re_text_list[i]) - 1:
                        break
                    try:
                        if value not in real_content_seq[index]:
                            print('----- Not right', value)
                            new_thread = threading.Thread(target=add_wrong_re_log,
                                                          args=(
                                                              real_talker, real_content,
                                                              a_message.a_message_id, a_message.talker, by_client_id))
                            new_thread.setDaemon(True)
                            new_thread.start()
                            break
                    except Exception as e:
                        print('----- Not right', e, value)
                        new_thread = threading.Thread(target=add_wrong_re_log,
                                                      args=(
                                                          real_talker, real_content,
                                                          a_message.a_message_id, a_message.talker, by_client_id))
                        new_thread.setDaemon(True)
                        new_thread.start()
                        break


def check_to_pull_people(a_message):
    if a_message.real_content.find('SL^lxz') == 0:
        print('----- check_to_pull_people Catch!')
        word_list = a_message.real_content.split(u'&')
        if len(word_list) != 2:
            return 0
        bot_username = a_message.bot_username
        real_talker = a_message.real_talker
        chatroomname = word_list[1][::-1] + u'@chatroom'
        chatroom_info = BaseModel.fetch_one('a_chatroom', '*', BaseModel.where_dict({'chatroomname': chatroomname}))
        if chatroom_info is None:
            return 0
        memberlist = chatroom_info.memberlist.split(';')
        if bot_username not in memberlist or real_talker in memberlist:
            return 0
        print('----- check_to_pull_people running!')
        new_thread = threading.Thread(target=add_pull_people_task, args=(bot_username, chatroomname, real_talker))
        new_thread.setDaemon(True)
        new_thread.start()


def check_events_send_word(a_message):
    logger.info(u"going check_events_send_word!")
    def get_owner_bot_username(_client_id, _member_list):
        bot_username_list = []
        cbr = BaseModel.fetch_all('client_bot_r', '*', BaseModel.where_dict({'client_id': _client_id}))
        for i in cbr:
            temp = i.to_json_full()
            if temp.get('bot_username'):
                bot_username_list.append(temp.get('bot_username'))
        x = set(_member_list)
        y = set(bot_username_list)

        res = tuple(x & y)
        if len(res) >= 1:
            return res[0]
        else:
            return False

    def send_message_list(_bot_username, chatroomname_list, message_list):
        real_message_list = []
        data = {'bot_username': _bot_username, 'to_list': chatroomname_list}
        for index, message in enumerate(message_list):
            message_dict = dict()
            message_dict["type"] = message.get("real_type")
            message_dict["content"] = message.get("text")
            message_dict["source_url"] = message.get("source_url")
            message_dict["thumb_url"] = message.get("thumb_url")
            message_dict["title"] = message.get("title")
            message_dict["desc"] = message.get("desc")
            message_dict["size"] = message.get("size")
            message_dict["duration"] = message.get("duration")
            message_dict["msg_id"] = message.get("msg_id")
            message_dict["msg_local_id"] = message.get("msg_local_id")
            message_dict["msg_svr_id"] = message.get("msg_svr_id")
            message_dict["talker"] = message.get("talker")
            message_dict["create_time"] = message.get("create_time")
            message_dict["seq"] = index
            real_message_list.append(message_dict)
        data['message_list'] = real_message_list
        # print(data)
        resp = requests.post(url=ANDROID_SERVER_URL_SEND_MASS_MESSAGE, json=data)
        print(resp.text)

    all_event_chatroom = BaseModel.fetch_all('events_chatroom_', '*')
    all_event_chatroomname_list = [i.chatroomname for i in all_event_chatroom]

    if a_message.talker in all_event_chatroomname_list:
        chatroomname = a_message.talker
        event_id = None
        for i in all_event_chatroom:
            if i.chatroomname == chatroomname:
                event_id = i.event_id
                break
        if event_id is None:
            return -1
        # Work.
        event = BaseModel.fetch_by_id('events_', event_id)
        client_id = event.client_id
        if client_id != a_message.client_id:
            return 1

        fission_word_list = BaseModel.fetch_all('events_send_word', '*',
                                                BaseModel.where_dict(
                                                    {'event_id': event_id, 'is_deleted': 0, 'is_work': 1,
                                                     'type': 'fission'}))
        condition_word_list = BaseModel.fetch_all('events_send_word', '*',
                                                  BaseModel.where_dict(
                                                      {'event_id': event_id, 'is_deleted': 0, 'is_work': 1,
                                                       'type': 'condition'}))

        chatroom = BaseModel.fetch_one('a_chatroom', '*', BaseModel.where_dict({'chatroomname': chatroomname}))
        if chatroom is None:
            return -1
        chatroom_as_dict = chatroom.to_json_full()
        member_list = chatroom_as_dict.get('memberlist').split(';') if chatroom_as_dict.get(
            'memberlist') is not None else []
        member_count = len(member_list)
        bot_username = get_owner_bot_username(client_id, member_list)
        if bot_username is None:
            return 0
        for i in fission_word_list:
            send_message_list(bot_username, [chatroomname, ], i.message_list)
        for j in condition_word_list:
            if j.condition_num == member_count:
                send_message_list(bot_username, [chatroomname, ], j.message_list)
        return 0


def make_re_text(tag_list, by_client_id, previous_rule=None):
    """Make re text by tag_list."""
    res = []
    if previous_rule is not None:
        res = previous_rule

    if 3 in tag_list:
        res.append([u'交底工作总结', u'交底日期', u'参加人员', u'未参加人员', u'交底记录', u'待整改项', u'需求事项', by_client_id])
        res.append([u'节点验收通知', u'验收日期', u'验收内容', u'需参加人员', u'备注', by_client_id])
        res.append([u'节点验收总结', u'验收日期', u'参加人员', u'未参加人员', u'验收结果', u'待整改项', u'需求事项', by_client_id])
        res.append([u'项目经理工作汇报', u'汇报日期', u'汇报内容', by_client_id])
    if 4 in tag_list:
        res.append([u'工长工作汇报', u'项目经理', u'拍摄时间', u'照片', u'工长工作安排', by_client_id])
    if 5 in tag_list:
        res.append([u'现场工作汇报', u'项目经理', u'工长', u'拍摄时间', u'照片', u'上周完成', u'本周计划', u'人员安排', u'设计需求',
                    u'产品需求', u'可复尺产品', u'该工地是否具备参观件', u'工期倒计时', u'是否能按时完工', u'障碍工期问题', by_client_id])
    return res


def add_reply_employee_at_log(username, chatroomname):
    print('------ add_reply_employee_at_log running ')
    all_log_in_thisroom = BaseModel.fetch_all('employee_be_at_log', '*', BaseModel.and_(["=", "is_reply", 0],
                                                                                        [">", "create_time",
                                                                                         int(time.time()) - 86400],
                                                                                        ["=", "username", username],
                                                                                        ["=", "chatroomname",
                                                                                         chatroomname], ), )
    for i in all_log_in_thisroom:
        i.is_reply = 1
        i.reply_time = int(time.time())
        i.save()
    return 0


def add_employee_at_log(username, content, a_message_id, chatroomname, by_client_id):
    print('add_employee_at_log running')
    # Check if this employee not in this chatroom.
    try:
        client_chatroomname_list = []
        client_chatroom_list = BaseModel.fetch_all('client_qun_r', '*',
                                                   BaseModel.where_dict({'client_id': by_client_id}))
        for i in client_chatroom_list:
            temp = i.to_json().get('chatroomname')
            client_chatroomname_list.append(temp)
        if chatroomname not in client_chatroomname_list:
            # print('At error: user not owner this chatroom.')
            return 0
        this_chatroom = BaseModel.fetch_one('a_chatroom', '*', BaseModel.where_dict({'chatroomname': chatroomname}))
        member_list = this_chatroom.memberlist.split(';')
        if username not in member_list:
            # print('At error: user not in this chatroom.')
            return 0
    except Exception as e:
        print(e)

    new_log = CM('employee_be_at_log')
    new_log.username = username
    new_log.create_time = int(time.time())
    new_log.content = content
    new_log.a_message_id = a_message_id
    new_log.chatroomname = chatroomname
    new_log.by_client_id = by_client_id
    new_log.is_reply = 0
    new_log.reply_time = 0
    new_log.save()
    update_employee_people_reply_rule()


def add_wrong_re_log(username, content, a_message_id, chatroomname, by_client_id):
    try:
        client_chatroomname_list = []
        client_chatroom_list = BaseModel.fetch_all('client_qun_r', '*',
                                                   BaseModel.where_dict({'client_id': by_client_id}))
        for i in client_chatroom_list:
            temp = i.to_json().get('chatroomname')
            client_chatroomname_list.append(temp)
        if chatroomname not in client_chatroomname_list:
            return 0
    except Exception as e:
        print('add_wrong_re_log,', e)

    _new_log = CM('employee_re_log')
    _new_log.username = username
    _new_log.create_time = int(time.time())
    _new_log.content = content
    _new_log.a_message_id = a_message_id
    _new_log.chatroomname = chatroomname
    _new_log.by_client_id = by_client_id
    _new_log.save()


def add_pull_people_task(bot_username, chatroomname, username):
    result = {'bot_username': bot_username,
              'data': {
                  "task": "add_contact_to_chatroom",
                  "chatroomname": chatroomname,
                  "contacts": username
              }}
    requests.post('%s/android/send_message' % ANDROID_SERVER_URL, json=result)


def chatroom_client_info(a_message):
    if a_message.is_to_friend:
        print('Message is to friend')
        return Tag(0).get_name_dict()

    client_id = None
    chatroomname = a_message.talker
    bot_username = a_message.bot_username
    client_list = BaseModel.fetch_all('client_qun_r', '*', BaseModel.where_dict({'chatroomname': chatroomname}))
    if client_list == []:
        print('client is none,client_qun_r')
        return Tag(0).get_name_dict()

    for _client in client_list:
        _client_id = _client.client_id
        _client_bot = BaseModel.fetch_all('client_bot_r','*',BaseModel.where_dict({'client_id':_client_id}))
        _client_bot_list = [i.bot_username for i in _client_bot ]
        if bot_username in _client_bot_list:
            client_id = _client_id
            break
    if client_id is None:
        print('Can not match this client,no bot relation.')
        return Tag(0).get_name_dict()
    print(client_id)
    client_info = BaseModel.fetch_one('client_member', '*', BaseModel.where_dict({'client_id': client_id}))
    # print(client_info.nick_name)
    if client_info is None:
        print('client is none,client_member')
        return Tag(0).get_name_dict()
    # print(Tag(client_info.func_switch).get_name_dict())
    return Tag(client_info.func_switch).get_name_dict()


def _extract_msg_be_at(msg):
    print('_extract_msg_be_at work----')
    at_count = 0
    chatroomname = msg.talker
    is_at = False
    member_be_at_list = list()
    content = str_to_unicode(msg.real_content)
    content_tmp = copy.deepcopy(content)

    if content_tmp.find(u'@') != -1:
        is_at = True
        content_index = 0
        while content_tmp[content_index:].find(u'@') != -1:
            offset = content_index + content_tmp[content_index:].find(u'@') + 1
            end_index = 0
            if content_tmp[content_index:].find(u'\u2005') == -1:
                content_tmp = content_tmp.replace(u' ', u'\u2005')
                # print content_tmp.__repr__()
            while content_tmp[offset + end_index:].find(u'\u2005') != -1:
                end_index += content_tmp[offset + end_index:].find(u'\u2005') + 1
                name_be_at = content_tmp[offset:offset + end_index - 1]
                if name_be_at == u'':
                    is_at = False
                    break
                if name_be_at.find(u'\u2005') != -1:
                    name_be_at = name_be_at.replace(u'\u2005', u' ')
                logger.debug(u'nick_name_be_at: ' + name_be_at)
                member_be_at = fetch_member_by_nickname(chatroomname=chatroomname,
                                                        nickname=name_be_at, update_flag=False)
                # 匹配到 member
                if member_be_at:
                    logger.info(u'member_be_at ' + unicode(member_be_at))
                    is_at = True
                    offset += end_index
                    member_be_at_list.append(member_be_at)
                    at_count += 1
                    break
                else:
                    logger.info(u'really not find ' + name_be_at)
                    # Mark 一个异常，全部异常
                    return False, None
            content_index = offset

    print(member_be_at_list)
    # return is_at, at_count
