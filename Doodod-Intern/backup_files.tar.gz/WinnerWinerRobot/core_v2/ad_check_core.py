# -*- coding: utf-8 -*-
__author__ = "Quentin"

# import threading
import logging
# # import time
from models_v2.base_model import BaseModel
from core_v2.send_msg import send_ws_to_android
from configs.config import SUCCESS, UserBotR

# #
# # from utils.wkx_test_log import MyLogging
# # from core_v2.send_msg import send_ws_to_android
logger = logging.getLogger('main')


def ad_detect(content):
    ad_kwset = {u"打折", u"优惠", u"价钱", u"有意者"}
    for s in ad_kwset:
        if content.find(s) >= 0:
            return 1
    return 0


def check_msg_is_an_ad(a_message, switch=True):
    if not switch:
        return

    if a_message.is_to_friend or not ad_detect(a_message.real_content):
        return

    bot_username = a_message.bot_username
    chatroomname = a_message.talker

    chatroom = BaseModel.fetch_one("a_chatroom", "*",
                                   where_clause=BaseModel.and_(
                                       ["=", "chatroomname", chatroomname]
                                   ))
    chatroom_nickname = chatroom.nickname_real if chatroom else u"您的一个群"

    ad_provider = a_message.real_talker
    ad_provider_contact = BaseModel.fetch_one("a_contact", "*",
                                              where_clause=BaseModel.and_(
                                                  ["=", "username", ad_provider]
                                              ))
    ad_provider_nickname = ad_provider_contact.nickname if ad_provider_contact else u"一个群成员"

    # client = BaseModel.fetch_one("client_member", "*",
    #                              where_clause=BaseModel.and_(
    #                                  ["=", "client_id", a_message.client_id]
    #                              ))

    info_data = {
        "task": "send_message",
        "to": ad_provider,
        "type": 1,
        "content": u"亲，%s在%s发广告啦" % (ad_provider_nickname, chatroom_nickname)
    }

    try:
        status = send_ws_to_android(bot_username, info_data)

        if status == SUCCESS:
            logger.info(u"任务发送成功, client_id: %s." % a_message.client_id)
        else:
            logger.info(u"任务发送失败, client_id: %s." % a_message.client_id)

    except Exception:
        pass

    return True
