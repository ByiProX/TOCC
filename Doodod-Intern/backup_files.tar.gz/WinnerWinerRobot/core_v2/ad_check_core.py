# -*- coding: utf-8 -*-
__author__ = "Quentin"

# import threading
import logging
import re
# # import time
from models_v2.base_model import BaseModel
from core_v2.send_msg import send_ws_to_android
from core_v2.send_msg import send_msg_to_android

from configs.config import SUCCESS, UserBotR

# #
# # from utils.wkx_test_log import MyLogging
logger = logging.getLogger('main')


#
# def ad_detect(content):
#     ad_kwset = {u"打折", u"优惠", u"价钱", u"有意者"}
#     for s in ad_kwset:
#         if content.find(s) >= 0:
#             return 1
#     return 0


def ad_detect(a_message):
    print ">>>>>>>>>>>>>>>>>>>>进入ad_detect。。。。。。。"
    white_list = get_white_list(a_message)
    if a_message.real_talker in white_list:
        return False

    ad_kwset = {49, 43, 3}
    if a_message.type in ad_kwset:
        return True

    if a_message.real_type in {2, 3, 4, 5, 6, 7}:
        return True

    pattern = re.compile(
        r"((http|ftp|https):\/\/)?[\w\-_]+(\.[\w\-_]+)+([\w\-\.@?^=%&amp;:/~\+#]*[\w\-\@?^=%&amp;/~\+#])?",
        re.IGNORECASE)
    if a_message.type == 1 and re.search(pattern, a_message.real_content, re.IGNORECASE):
        return True

    return False


def get_white_list(a_message):
    client_qun_r = BaseModel.fetch_one("client_qun_r", "*",
                                       where_clause=BaseModel.and_(
                                           ["=", "chatroomname", a_message.talker],
                                           ["=", "bot_username", a_message.bot_username]
                                       ))

    if not client_qun_r:
        return [1]

    print ">>>>>>>>>>>>>>>>>>>>>>client_qun_r"
    print client_qun_r
    print client_qun_r.to_json_full()

    client_id = client_qun_r.client_id

    clients = BaseModel.fetch_all("client_member", "*",
                                  where_clause=BaseModel.and_(
                                      ["=", "client_id", client_id]
                                  ))

    clients_username_list = [client.username for client in clients]
    clients_username_list.append(a_message.bot_username)

    print ">>>>>>>>>>>>>>>白名单"
    print clients_username_list

    # staffs_list = BaseModel.fetch_all("staff", "*",
    #                                   where_clause=BaseModel.and_(
    #                                       ["in", "manager_open_id", clients_open_id_list]
    #                                   ))
    return clients_username_list


def check_msg_is_an_ad(a_message, switch=True):
    if a_message.bot_username != u"wxid_u44s9oamh0tx22":
        return
    # print ">>>>>>>>>>>>>>>>>群广告检查"
    if not switch:
        # print "switch", switch
        return

    ad_flag = ad_detect(a_message)
    if a_message.is_to_friend or not ad_flag:
        print a_message.is_to_friend, ad_flag
        return

    # print ">>>>>>>>>>>>>>>>>检查到是广告"
    bot_username = a_message.bot_username
    chatroomname = a_message.talker

    chatroom = BaseModel.fetch_one("a_chatroom", "*",
                                   where_clause=BaseModel.and_(
                                       ["=", "chatroomname", chatroomname]
                                   ))
    chatroom_nickname = chatroom.nickname_real if chatroom else u"您的一个群"

    ad_provider = a_message.real_talker
    ad_provider_contact = BaseModel.fetch_one("a_contact", "*",
                                              where_clause=BaseModel.and_(
                                                  ["=", "username", ad_provider]
                                              ))
    ad_provider_nickname = ad_provider_contact.nickname if ad_provider_contact else u"一个群成员"

    if a_message.client_id:
        clients_id = BaseModel.fetch_all("client_member", "*",
                                         where_clause=BaseModel.and_(
                                             ["=", "client_id", a_message.client_id]
                                         ))
        if len(clients_id) == 1:
            info_data = {
                "task": "send_message",
                "to": clients_id[0].username,
                "type": 1,
                "content": u"亲，%s在%s发广告啦" % (ad_provider_nickname, chatroom_nickname)
            }

            try:
                status = send_ws_to_android(bot_username, info_data)

                if status == SUCCESS:
                    logger.info(u"任务发送成功, client_id: %s." % a_message.client_id)
                else:
                    logger.info(u"任务发送失败, client_id: %s." % a_message.client_id)

            except Exception:
                pass

        for client_id in clients_id:
            staff_manager = BaseModel.fetch_one("staff", "*",
                                                where_clause=BaseModel.and_(
                                                    ["=", "manager_open_id", client_id.open_id],
                                                    ["=", "is_deleted", 0],
                                                    ["=", "is_work", 1],
                                                    ["=", "is_confirmed", 1]
                                                ))

            if staff_manager:
                # print ">>>>>>>>>>>>>>>>>>>>>staff_manager"
                print staff_manager.to_json_full()
                client = BaseModel.fetch_one("client_member", "*",
                                             where_clause=BaseModel.and_(
                                                 ["=", "open_id", staff_manager.manager_open_id]
                                             ))
                if not client:
                    continue

                info_data = {
                    "task": "send_message",
                    "to": client.username,
                    "type": 1,
                    "content": u"亲，%s在%s发广告啦" % (ad_provider_nickname, chatroom_nickname)
                }

                try:
                    status = send_ws_to_android(bot_username, info_data)

                    if status == SUCCESS:
                        logger.info(u"任务发送成功, client_id: %s." % a_message.client_id)
                    else:
                        logger.info(u"任务发送失败, client_id: %s." % a_message.client_id)

                except Exception:
                    pass

                # print 'break!!!'
                break

    message_info = u"@%s \n本群禁止广告，发送广告者，直接移出群聊。\n良好群环境，需要大家共同维护，感谢大家支持！" % ad_provider_nickname
    msg_tmp = {
        "content": message_info,
        "seq": 0,
        "type": 1
    }

    try:
        status = send_msg_to_android(bot_username, [msg_tmp], [chatroomname])

        if status == SUCCESS:
            logger.info(u"任务发送成功, client_id: %s." % a_message.client_id)
        else:
            logger.info(u"任务发送失败, client_id: %s." % a_message.client_id)

    except Exception:
        pass

    return True


if __name__ == "__main__":

    pattern2 = re.compile(
        r"((http|ftp|https):\/\/)?[\w\-_]+(\.[\w\-_]+)+([\w\-\.@?^=%&amp;:/~\+#]*[\w\-\@?^=%&amp;/~\+#])?")
    a = re.search(pattern2, u"士大夫撒发 HTTP://s.com")

    pattern1 = re.compile(r"sdf", re.IGNORECASE)
    b = re.search(pattern1, 'sDf')

    if b:
        print ">>>>>>>>>>>>>>>>>>>>>"

