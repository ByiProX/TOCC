# -*- coding: utf-8 -*-
__author__ = "Quentin"

# import threading
import logging
# # import time
from models_v2.base_model import BaseModel
from core_v2.send_msg import send_ws_to_android
from core_v2.send_msg import send_msg_to_android

from configs.config import SUCCESS, UserBotR

# #
# # from utils.wkx_test_log import MyLogging
logger = logging.getLogger('main')

#
# def ad_detect(content):
#     ad_kwset = {u"打折", u"优惠", u"价钱", u"有意者"}
#     for s in ad_kwset:
#         if content.find(s) >= 0:
#             return 1
#     return 0


def ad_detect(a_message):
    white_list = get_white_list(a_message)
    if a_message.real_talker in white_list:
        return False

    ad_kwset = {49, 43}
    if a_message.type in ad_kwset:
        return True

    if a_message.real_type in [2, 3, 4, 5, 6, 7]:
        return True

    return False


def get_white_list(a_message):
    client_qun_r = BaseModel.fetch_one("client_qun_r", "*",
                                       where_clause=BaseModel.and_(
                                           ["=", "chatroomname", a_message.talker],
                                           ["=", "bot_username", a_message.bot_username]
                                       ))

    client_id = client_qun_r.client_id

    clients = BaseModel.fetch_all("client_member", "*",
                                  where_clause=BaseModel.and_(
                                      ["=", "client_id", client_id]
                                  ))

    clients_username_list = [client.username for client in clients]
    clients_username_list.append(a_message.bot_username)

    # staffs_list = BaseModel.fetch_all("staff", "*",
    #                                   where_clause=BaseModel.and_(
    #                                       ["in", "manager_open_id", clients_open_id_list]
    #                                   ))
    return clients_username_list


def check_msg_is_an_ad(a_message, switch=True):
    if not switch:
        return

    if a_message.is_to_friend or not ad_detect(a_message):
        return

    bot_username = a_message.bot_username
    chatroomname = a_message.talker

    chatroom = BaseModel.fetch_one("a_chatroom", "*",
                                   where_clause=BaseModel.and_(
                                       ["=", "chatroomname", chatroomname]
                                   ))
    chatroom_nickname = chatroom.nickname_real if chatroom else u"您的一个群"

    ad_provider = a_message.real_talker
    ad_provider_contact = BaseModel.fetch_one("a_contact", "*",
                                              where_clause=BaseModel.and_(
                                                  ["=", "username", ad_provider]
                                              ))
    ad_provider_nickname = ad_provider_contact.nickname if ad_provider_contact else u"一个群成员"

    # info_data = {
    #     "task": "send_message",
    #     "to": ad_provider,
    #     "type": 1,
    #     "content": u"亲，%s在%s发广告啦" % (ad_provider_nickname, chatroom_nickname)
    # }

    message_info = u"@%s \n本群禁止广告，发送广告者，直接移出群聊。\n良好群环境，需要大家共同维护，感谢大家支持！" % ad_provider_nickname

    try:
        status = send_msg_to_android(bot_username, [message_info], [chatroomname])
        # status = send_ws_to_android(bot_username, info_data)

        if status == SUCCESS:
            logger.info(u"任务发送成功, client_id: %s." % a_message.client_id)
        else:
            logger.info(u"任务发送失败, client_id: %s." % a_message.client_id)

    except Exception:
        pass

    return True


if __name__ == "__main__":
    manager = BaseModel.fetch_all("client_member", "*",
                                  where_clause=BaseModel.and_(
                                      ["=", "client_id", 5]
                                  ))
    print manager.__len__()