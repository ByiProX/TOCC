# -*- coding: utf-8 -*-
__author__ = "Quentin"

import logging

from configs.config import err
from models_v2.base_model import BaseModel

logger = logging.getLogger('main')
SENSITIVE_WORD_RULE_DICT = {}


def delete_a_material(client_id, msg_id):
    material = BaseModel.fetch_one("material_lib", "*",
                                   where_clause=BaseModel.where_dict({"client_id": client_id, "msg_id": msg_id}))

    if not material:
        return err.ERR_WRONG_ITEM

    material.delete()
