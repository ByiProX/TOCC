# -*- coding: utf-8 -*-
__author__ = "quentin"

import logging
import random
import time

from configs.config import SUCCESS
from core_v2.send_msg import send_ws_to_android, send_msg_to_android
from models_v2.base_model import BaseModel

# from configs.config import ANDROID_SERVER_URL_SEND_MESSAGE
# import requests
# import threading
# import json

logger = logging.getLogger('main')


def pull_people_to_chatroom(a_message, switch=True):
    """
    群成员添加机器人，给机器人发送关键词信息，将群成员拉入相应的群，，

    client_qun_keyword请求了所有数据，咱没办法修改，重构的时候注意一下数据库相关字段添加
    :param a_message:
    :param switch:
    :return:
    """
    if not switch:
        return

    if not a_message.is_to_friend:
        return

    print ">>>>>>>>>>>>>>>>>>>>>>>已经进入拉人进群函数"

    bot_username = a_message.bot_username
    username = a_message.real_talker
    message_keyword = a_message.real_content

    clients_qun_keyword_list = BaseModel.fetch_all("client_qun_keyword", "*")

    qun_keyword_list = list()
    for client_qun_keyword_list in clients_qun_keyword_list:
        if client_qun_keyword_list.qun_keyword_list:
            qun_keyword_list.extend(client_qun_keyword_list.qun_keyword_list)

    if not qun_keyword_list:
        return

    for qun_keyword in qun_keyword_list:
        if qun_keyword["keyword"] == message_keyword:
            chatroomname = get_a_valid_chatroom(qun_keyword["chatroom_list"])

            if not chatroomname:
                continue

            try:
                data = {
                    "task": "add_contact_to_chatroom",
                    "chatroomname": chatroomname,
                    "contacts": username
                }
                status1 = send_ws_to_android(bot_username, data)
                if status1 == SUCCESS:
                    logger.info(u"机器人%s拉人进群, 安卓发送任务成功" % username)
                else:
                    logger.info(u"机器人%s拉人进群, 安卓发送任务失败" % username)

                time.sleep(1)

                real_talker_nickname = get_nickname_from_message(a_message)
                message_info = u"欢迎%s入群" % real_talker_nickname
                msg_tmp = {
                    "content": message_info,
                    "seq": 0,
                    "type": 1
                }
                status2 = send_msg_to_android(bot_username, message_list=[msg_tmp], to_list=[chatroomname])
                if status2 == SUCCESS:
                    logger.info(u"群通知成功, chatroomname ：%s." % chatroomname)
                else:
                    logger.info(u"群通知失败, chatroomname ：%s." % chatroomname)

                break
            except Exception:
                logger.info(u"安卓任务失败")

    return


def get_a_valid_chatroom(chatroom_list):
    valid_chatrooms = list()
    for chatroom_info in chatroom_list:
        a_chatroom = BaseModel.fetch_one("a_chatroom", "*",
                                         where_clause=BaseModel.and_(
                                             ["=", "chatroomname", chatroom_info["chatroom_name"]]
                                         ))

        print ">>>>>>>>>>>>>>>.a_chatroooooooom"
        print a_chatroom
        if a_chatroom and a_chatroom.member_count < 500:
            valid_chatrooms.append(chatroom_info["chatroom_name"])

    if not valid_chatrooms:
        return None

    print ">>>>>>>>>>>>>>>>>>>>>>valid_chatrooms"
    print valid_chatrooms

    return random.choice(valid_chatrooms)


def get_nickname_from_message(a_message):
    who = a_message.real_talker
    who_info = BaseModel.fetch_one("a_contact", "*",
                                   where_clause=BaseModel.and_(
                                       ["=", "username", who]
                                   ))
    nickname = who_info.nickname if who_info else u"一个群成员"

    return nickname

# def pull_people_to_chatroom(a_message, switch=True):
#     """
#     群成员添加机器人，给机器人发送关键词信息，将群成员拉入相应的群
#     :param a_message:
#     :param switch:
#     :return:
#     """
#     if not switch:
#         return
#
#     if not a_message.is_to_friend:
#         return
#
#     if a_message.real_content.find('@') < 0 or len(a_message.real_content.strip().split('@')) != 2:
#         return
#
#     print ">>>>>>>>>>>>>>>>>>>>>>>已经进入拉人进群函数"
#
#     client_id, a_message_keyword = a_message.real_content.strip().split('@')
#     client_id = int(client_id)
#
#     bot_username = a_message.bot_username
#     username = a_message.real_talker
#
#     client_qun_keyword = BaseModel.fetch_one("client_qun_keyword", "*",
#                                              where_clause=BaseModel.and_(
#                                                  ["=", "client_id", client_id]
#                                              ))
#
#     if not client_qun_keyword:
#         return
#
#     qun_keyword_list = client_qun_keyword.qun_keyword_list
#     if not qun_keyword_list:
#         return
#
#     print ">>>>>>>>>>>>>>>>>>>>>>准备匹配qun keyword>>>>>>>>>>>>>>>"
#
#     for qun_keyword in qun_keyword_list:
#         print ">>>>>>>>>>>>>进入循环，开始匹配 qun keyword >>>>>>>>>>>"
#         # if qun_keyword["keyword"] == a_message_keyword:
#         if qun_keyword["keyword"].strip().split('@')[1] == a_message_keyword:
#             chatroomname = get_a_valid_chatroom(qun_keyword["chatroomname_list"])
#             data = {
#                 "task": "add_contact_to_chatroom",
#                 "chatroomname": chatroomname,
#                 "contacts": username
#             }
#
#             if send_ws_to_android(bot_username, data):
#                 logger.info(">>>>>>>>>>>>>>>>>>>>>:拉群任务完成")
#                 send_msg_to_android(bot_username, message_list=['欢迎入群'], to_list=[chatroomname])
#                 logger.info(">>>>>>>>>>>>>>>>>>>>>:发送欢迎语完成")
#                 break
#
#     return
#
#
# def get_a_valid_chatroom(chatroomname_list):
#     valid_chatrooms = list()
#     for chatroomname in chatroomname_list:
#         a_chatroom = BaseModel.fetch_one("a_chatroom", "*",
#                                          where_clause=BaseModel.and_(
#                                              ["=", "chatroomname", chatroomname]
#                                          ))
#         if a_chatroom and a_chatroom.member_count < 500:
#             valid_chatrooms.append(chatroomname)
#
#     return random.choice(valid_chatrooms)
