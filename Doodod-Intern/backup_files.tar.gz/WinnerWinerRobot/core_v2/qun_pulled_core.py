# -*- coding: utf-8 -*-
__author__ = "quentin"

import logging
import random
from models_v2.base_model import BaseModel, CM
from core_v2.send_msg import send_ws_to_android, send_msg_to_android

# from configs.config import ANDROID_SERVER_URL_SEND_MESSAGE
# import requests
# import threading
# import json

logger = logging.getLogger('main')


# by quentin
# def pull_people_to_chatroom_task(bot_username, chatroomname, username):
#     url = ANDROID_SERVER_URL_SEND_MESSAGE
#     result = {'bot_username': bot_username,
#               'data': {
#                   "task": "add_contact_to_chatroom",
#                   "chatroomname": chatroomname,
#                   "contacts": username
#               }}
#
#     logger.info(u"机器人拉人进群. data: %s." % json.dumps(result))
#     requests.post(url, json=result)
#     logger.info(u"机器人拉人进群, 安卓发送任务. url: %s." % url)


def pull_people_to_chatroom(a_message, switch=True):
    """
    群成员添加机器人，给机器人发送关键词信息，将群成员拉入相应的群
    :param a_message:
    :param switch:
    :return:
    """
    if not switch:
        return

    if not a_message.is_to_friend:
        return

    print ">>>>>>>>>>>>>>>>>>>>>>>已经进入拉人进群函数"

    client_id, a_message_keyword = a_message.real_content.strip().split('@')
    client_id = int(client_id)

    bot_username = a_message.bot_username
    username = a_message.real_talker

    client_qun_keyword = BaseModel.fetch_one("client_qun_keyword", "*",
                                             where_clause=BaseModel.and_(
                                                 ["=", "client_id", client_id]
                                             ))

    if not client_qun_keyword:
        return

    qun_keyword_list = client_qun_keyword.qun_keyword_list
    if not qun_keyword_list:
        return

    print ">>>>>>>>>>>>>>>>>>>>>>准备匹配qun keyword>>>>>>>>>>>>>>>"

    for qun_keyword in qun_keyword_list:
        print ">>>>>>>>>>>>>进入循环，开始匹配 qun keyword >>>>>>>>>>>"
        if qun_keyword["keyword"] == a_message_keyword:
            chatroomname = get_a_valid_chatroom(qun_keyword["chatroomname_list"])
            data = {
                "task": "add_contact_to_chatroom",
                "chatroomname": chatroomname,
                "contacts": username
            }

            if send_ws_to_android(bot_username, data):
                logger.info(">>>>>>>>>>>>>>>>>>>>>:拉群任务完成")
                send_msg_to_android(bot_username, message_list=['欢迎入群'], to_list=[chatroomname])
                logger.info(">>>>>>>>>>>>>>>>>>>>>:发送欢迎语完成")
                break

    return


def get_a_valid_chatroom(chatroomname_list):
    valid_chatrooms = list()
    for chatroomname in chatroomname_list:
        a_chatroom = BaseModel.fetch_one("a_chatroom", "*",
                                         where_clause=BaseModel.and_(
                                             ["=", "chatroomname", chatroomname]
                                         ))
        if a_chatroom and a_chatroom.member_count < 500:
            valid_chatrooms.append(chatroomname)

    return random.choice(valid_chatrooms)
