# -*- coding: utf-8 -*-
import logging
import time
from datetime import datetime

from configs.config import err, SUCCESS, BatchSendTask, \
    Chatroom, BATCH_SEND_TASK_STATUS_1, BATCH_SEND_TASK_STATUS_3, BATCH_SEND_TASK_STATUS_4, UserBotR, UserQunR
from core_v2.send_msg import new_send_msg
from models_v2.base_model import BaseModel, CM
from utils.u_time import datetime_to_timestamp_utc_8

logger = logging.getLogger('main')
 

def get_batch_sending_task(user_info, task_per_page, page_number, task_status):
    """
    根据一个人，把所有的这个人可见的群发任务都出来
    :param user_info:
    :return:
    """
    result = []
    if task_status:
        where = BaseModel.where_dict({"client_id": user_info.client_id,
                                      "status": task_status,
                                      "is_deleted": 0})
    else:
        where = BaseModel.where_dict({"client_id": user_info.client_id,
                                      "is_deleted": 0})
    batch_send_task_count = BaseModel.count(BatchSendTask, where)
    batch_send_task_list = BaseModel.fetch_all(BatchSendTask, "*", where_clause=where,
                                               order_by=BaseModel.order_by({"create_time": "desc"}), page=page_number,
                                               pagesize=task_per_page)
    for batch_send_task in batch_send_task_list:
        res = dict()
        chatroom_list = batch_send_task.chatroom_list
        chatroom_json_list = list()
        chatroom_count = len(chatroom_list)
        member_count = 0
        for chatroomname in chatroom_list:
            chatroom = BaseModel.fetch_one(Chatroom, "*",
                                           where_clause=BaseModel.where_dict({"chatroomname": chatroomname}))
            if chatroom is None or chatroom.member_count is None:
                continue
            member_count += chatroom.member_count
            chatroom_dict = dict()
            chatroom_dict['chatroom_id'] = chatroom.get_id()
            chatroom_dict['chatroom_nickname'] = chatroom.nickname
            if chatroom.nickname == "":
                chatroom_dict['chatroom_nickname'] = chatroom.nickname_default
            chatroom_dict['chatroomname'] = chatroomname
            chatroom_dict['chatroom_member_count'] = chatroom.member_count
            chatroom_dict['avatar_url'] = chatroom.avatar_url
            chatroom_dict['chatroom_status'] = 0
            chatroom_json_list.append(chatroom_dict)

        message_list = list()
        content_list = batch_send_task.content_list
        for content in content_list:
            message_json = dict()
            message_json["real_type"] = content.get("type")
            message_json["text"] = content.get("content")
            message_json["seq"] = content.get("seq")
            message_json["source_url"] = content.get("source_url")
            message_json["thumb_url"] = content.get("thumb_url")
            message_json["title"] = content.get("title")
            message_json["desc"] = content.get("desc")
            message_json["size"] = content.get("size")
            message_json["duration"] = content.get("duration")
            message_json["msg_id"] = content.get("msg_id")
            message_json["msg_local_id"] = content.get("msg_local_id")
            message_json["msg_svr_id"] = content.get("msg_svr_id")
            message_json["talker"] = content.get("talker")
            message_json["create_time"] = content.get("create_time")
            message_list.append(message_json)

        res["batch_send_task_id"] = batch_send_task.get_id()
        res["status"] = batch_send_task.status
        res["message_list"] = message_list
        res["chatroom_list"] = chatroom_json_list
        res["task_covering_chatroom_count"] = chatroom_count
        res["task_covering_people_count"] = member_count
        res["task_create_time"] = batch_send_task.create_time
        res["task_sended_count"] = chatroom_count
        res["task_sended_failed_count"] = 0

        res["send_time"] = batch_send_task.send_time
        # res["send_time"] = batch_send_task.send_time if batch_send_task.send_time else batch_send_task.create_time
        # res["send_time"] = batch_send_task.create_time
        res["send_time_real"] = batch_send_task.send_time_real
        result.append(res)

    return SUCCESS, result, batch_send_task_count


def get_chatroom_dict(chatroomname):
    chatroom = BaseModel.fetch_one(Chatroom, "*",
                                   where_clause=BaseModel.where_dict({"chatroomname": chatroomname}))
    chatroom_dict = dict()
    chatroom_dict['chatroom_id'] = chatroom.get_id()
    chatroom_dict['chatroom_nickname'] = chatroom.nickname
    if chatroom.nickname == "":
        chatroom_dict['chatroom_nickname'] = chatroom.nickname_default
    chatroom_dict['chatroomname'] = chatroomname
    chatroom_dict['chatroom_member_count'] = chatroom.member_count
    chatroom_dict['avatar_url'] = chatroom.avatar_url
    chatroom_dict['chatroom_status'] = 0

    return chatroom_dict


def get_task_detail(batch_send_task_id):
    """
    读取一个任务的所有信息
    """
    # batch_send_task = BaseModel.fetch_one(BatchSendTask, "*", where_clause = BaseModel.where_dict({"client_id": user_info.client_id}))
    batch_send_task = BaseModel.fetch_by_id(BatchSendTask, batch_send_task_id)
    if not batch_send_task:
        logger.error(u"群发不存在, batch_send_task_id: %s." + unicode(batch_send_task_id))
        return err.ERR_WRONG_ITEM, None

    res = dict()
    chatroom_list = batch_send_task.chatroom_list

    chatroom_json_list = list()
    for chatroomname in chatroom_list:
        chatroom = BaseModel.fetch_one(Chatroom, "*",
                                       where_clause=BaseModel.where_dict({"chatroomname": chatroomname}))
        chatroom_dict = dict()
        chatroom_dict['chatroom_id'] = chatroom.get_id()
        chatroom_dict['chatroom_nickname'] = chatroom.nickname
        if chatroom.nickname == "":
            chatroom_dict['chatroom_nickname'] = chatroom.nickname_default
        chatroom_dict['chatroomname'] = chatroomname
        chatroom_dict['chatroom_member_count'] = chatroom.member_count
        chatroom_dict['avatar_url'] = chatroom.avatar_url
        chatroom_dict['chatroom_status'] = 0
        chatroom_json_list.append(chatroom_dict)

    message_list = list()
    content_list = batch_send_task.content_list
    for content in content_list:
        message_json = dict()
        message_json["real_type"] = content.get("type")
        message_json["text"] = content.get("content")
        message_json["seq"] = content.get("seq")
        message_json["source_url"] = content.get("source_url")
        message_json["thumb_url"] = content.get("thumb_url")
        message_json["title"] = content.get("title")
        message_json["desc"] = content.get("desc")
        message_json["size"] = content.get("size")
        message_json["duration"] = content.get("duration")
        message_json["msg_id"] = content.get("msg_id")
        message_json["msg_local_id"] = content.get("msg_local_id")
        message_json["msg_svr_id"] = content.get("msg_svr_id")
        message_json["talker"] = content.get("talker")
        message_json["create_time"] = content.get("create_time")
        message_list.append(message_json)

    res["message_list"] = message_list
    res["chatroom_list"] = chatroom_json_list
    res["task_covering_chatroom_count"] = batch_send_task.chatroom_count
    res["task_covering_people_count"] = batch_send_task.people_count
    res["task_create_time"] = batch_send_task.create_time
    res["task_sended_count"] = batch_send_task.chatroom_count
    res["task_sended_failed_count"] = 0

    res["send_time"] = batch_send_task.send_time

    return SUCCESS, res


def get_task_fail_detail(sending_task_id):
    """
    读取一个任务的任务情况，成功或者失败
    :param sending_task_id:
    :return:
    """


def recreate_a_timed_sending_task(user_info, chatroom_list, message_list, send_time, batch_send_task_id):
    ubr = BaseModel.fetch_one(UserBotR, '*', where_clause=BaseModel.where_dict({"client_id": user_info.client_id}))
    if not ubr:
        logger.error(u"该用户没有绑定机器人")
        return err.ERR_WRONG_ITEM

    if not chatroom_list:
        logger.error(u"没有发送对象, 批量发送任务创建失败")
        return err.ERR_WRONG_ITEM

    member_count = 0
    for chatroomname in chatroom_list:
        chatroom = BaseModel.fetch_one(Chatroom, "*",
                                       where_clause=BaseModel.where_dict({"chatroomname": chatroomname}))
        if not chatroom or chatroom.member_count is None:
            logger.error(u"未获取到 chatroom, chatroomname: %s." % chatroomname)
            continue
        member_count += chatroom.member_count

    batch_send_task = BaseModel.fetch_by_id(BatchSendTask, batch_send_task_id)
    batch_send_task.chatroom_list = chatroom_list
    batch_send_task.chatroom_count = len(chatroom_list)
    batch_send_task.people_count = member_count
    batch_send_task.is_deleted = 0
    batch_send_task.create_time = int(time.time())
    batch_send_task.send_time = send_time
    batch_send_task.client_id = user_info.client_id
    batch_send_task.status = BATCH_SEND_TASK_STATUS_1
    batch_send_task.status_content = ""

    content_list = list()
    for i, message in enumerate(message_list):
        message_dict = dict()
        message_dict["type"] = message.get("real_type")
        message_dict["content"] = message.get("text")
        message_dict["source_url"] = message.get("source_url")
        message_dict["thumb_url"] = message.get("thumb_url")
        message_dict["title"] = message.get("title")
        message_dict["desc"] = message.get("desc")
        message_dict["size"] = message.get("size")
        message_dict["duration"] = message.get("duration")
        message_dict["msg_id"] = message.get("msg_id")
        message_dict["msg_local_id"] = message.get("msg_local_id")
        message_dict["msg_svr_id"] = message.get("msg_svr_id")
        message_dict["talker"] = message.get("talker")
        message_dict["create_time"] = message.get("create_time")
        message_dict["seq"] = i
        content_list.append(message_dict)

        batch_send_task.content_list = content_list
    batch_send_task.save()

    return SUCCESS


def create_a_timed_sending_task(user_info, chatroom_list, message_list, send_time):
    ubr = BaseModel.fetch_one(UserBotR, '*', where_clause=BaseModel.where_dict({"client_id": user_info.client_id}))
    if not ubr:
        logger.error(u"该用户没有绑定机器人")
        return err.ERR_WRONG_ITEM

    if not chatroom_list:
        logger.error(u"没有发送对象, 批量发送任务创建失败")
        return err.ERR_WRONG_ITEM

    member_count = 0
    for chatroomname in chatroom_list:
        chatroom = BaseModel.fetch_one(Chatroom, "*",
                                       where_clause=BaseModel.where_dict({"chatroomname": chatroomname}))
        if not chatroom or chatroom.member_count is None:
            logger.error(u"未获取到 chatroom, chatroomname: %s." % chatroomname)
            continue
        member_count += chatroom.member_count

    batch_send_task = CM(BatchSendTask)
    batch_send_task.client_id = user_info.client_id
    batch_send_task.chatroom_list = chatroom_list
    batch_send_task.chatroom_count = len(chatroom_list)
    batch_send_task.people_count = member_count
    batch_send_task.is_deleted = 0
    batch_send_task.create_time = int(time.time())
    batch_send_task.send_time = send_time
    batch_send_task.status = BATCH_SEND_TASK_STATUS_1
    batch_send_task.status_content = ""

    content_list = list()
    for i, message in enumerate(message_list):
        message_dict = dict()
        message_dict["type"] = message.get("real_type")
        message_dict["content"] = message.get("text")
        message_dict["source_url"] = message.get("source_url")
        message_dict["thumb_url"] = message.get("thumb_url")
        message_dict["title"] = message.get("title")
        message_dict["desc"] = message.get("desc")
        message_dict["size"] = message.get("size")
        message_dict["duration"] = message.get("duration")
        message_dict["msg_id"] = message.get("msg_id")
        message_dict["msg_local_id"] = message.get("msg_local_id")
        message_dict["msg_svr_id"] = message.get("msg_svr_id")
        message_dict["talker"] = message.get("talker")
        message_dict["create_time"] = message.get("create_time")
        message_dict["seq"] = i
        content_list.append(message_dict)

        batch_send_task.content_list = content_list
    batch_send_task.save()

    return SUCCESS 

def create_a_sending_task(user_info, chatroom_list, message_list):
    """
    将前端发送过来的任务放入task表，并将任务放入consumption_task
    :return:
    """ 
    #UserBotR = client_bot_r
    #ubr = BaseModel.fetch_one(UserBotR, '*', where_clause=BaseModel.where_dict({"client_id": user_info.client_id}))
    ubr = BaseModel.fetch_all(UserBotR, '*', where_clause=BaseModel.where_dict({"client_id": user_info.client_id}))
    if not ubr:
        logger.error(u"该用户没有绑定机器人")
        return err.ERR_WRONG_ITEM

    chatroom_count = len(chatroom_list)
    member_count = 0
    for chatroomname in chatroom_list:
        chatroom = BaseModel.fetch_one(Chatroom, "*",where_clause=BaseModel.where_dict({"chatroomname": chatroomname}))
        
        if not chatroom:
            logger.error(u"未获取到 chatroom, chatroomname: %s." % chatroomname)
            continue
        else:
            if not chatroom.member_count :
                chatroom.member_count = 0
        member_count += chatroom.member_count

 
        #if not chatroom or chatroom.member_count is None:
        #    logger.error(u"未获取到 chatroom, chatroomname: %s." % chatroomname)
        #    continue
        #member_count += chatroom.member_count

    if chatroom_count == 0 or member_count == 0:
        logger.error(u"没有发送对象, 批量发送任务创建失败")
        return err.ERR_WRONG_ITEM

    now_time = datetime_to_timestamp_utc_8(datetime.now())
    batch_send_task = CM(BatchSendTask)
    batch_send_task.client_id = user_info.client_id
    batch_send_task.chatroom_list = chatroom_list
    batch_send_task.chatroom_count = chatroom_count
    batch_send_task.people_count = member_count
    batch_send_task.is_deleted = 0
    batch_send_task.create_time = now_time
    batch_send_task.send_time = 0
    batch_send_task.status = BATCH_SEND_TASK_STATUS_1
    batch_send_task.status_content = ""
    content_list = list()
    for i, message in enumerate(message_list):
        message_dict = dict()
        message_dict["type"] = message.get("real_type")
        message_dict["content"] = message.get("text")
        message_dict["source_url"] = message.get("source_url")
        message_dict["thumb_url"] = message.get("thumb_url")
        message_dict["title"] = message.get("title")
        message_dict["desc"] = message.get("desc")
        message_dict["size"] = message.get("size")
        message_dict["duration"] = message.get("duration")
        message_dict["msg_id"] = message.get("msg_id")
        message_dict["msg_local_id"] = message.get("msg_local_id")
        message_dict["msg_svr_id"] = message.get("msg_svr_id")
        message_dict["talker"] = message.get("talker")
        message_dict["create_time"] = message.get("create_time")
        message_dict["seq"] = i
        content_list.append(message_dict)

    batch_send_task.content_list = content_list

    batch_send_task.save()

    # Added by ZYunH, use chatroomname_list to search its bot_username.
    chatroom_status_dict = dict()  # {"chatroomname":['member_wxid','member_wxid']}
    send_msg_dict = dict()  # {"bot_username":['chatroomname1','chatroomname2']}
    #ubr = BaseModel.fetch_all(UserBotR, '*', where_clause=BaseModel.where_dict({"client_id": user_info.client_id}))

    c_q_rs = BaseModel.fetch_all(UserQunR, '*',
                                 where_clause=BaseModel.and_(
                                     ["in", "chatroomname", chatroom_list]
                                 ))
    
    # logger.info(u"scofield all bots is=: %s." % all_bots)
    #ubr = BaseModel.fetch_one(UserBotR, "*", where_clause = BaseModel.where_dict({"client_id": user_info.client_id}))
    _bot_name = ''
    for cqr in c_q_rs:
        _bot_name = ''
        if not cqr.bot_username:
            logger.error(u"scofield _bot_name is none: %s." % cqr)
            continue
        else:
            _bot_name = cqr.bot_username 

        if not _bot_name:
            logger.info(u"scofield not find live bot")
            continue
        
        logger.info(u"scofield _bot_name ==: %s." % _bot_name)
        if _bot_name not in send_msg_dict.keys():
            send_msg_dict[_bot_name] = [cqr.chatroomname, ]
        else:
            send_msg_dict[_bot_name].append(cqr.chatroomname)
        logger.info(u"scofield send_msg_dict==: %s." % send_msg_dict)
    
    #send_msg_dict[bot_username].append(chatroomname)
    '''
    for _chatroomname in chatroom_list:
        this_chatroom = BaseModel.fetch_one('a_chatroom', '*', BaseModel.where_dict({'chatroomname': _chatroomname}))
        if this_chatroom is None:
            continue
        chatroom_status_dict[_chatroomname] = this_chatroom.memberlist.split(';')
    user_bot_list = [i.bot_username for i in ubr]
    for k, v in chatroom_status_dict.items():
        for bot_username in user_bot_list:
            if bot_username in v:
                if bot_username not in send_msg_dict.keys():
                    send_msg_dict[bot_username] = [k, ]
                else:
                    send_msg_dict[bot_username].append(k)
                break
    '''


    # Send msg to android.
    status = 'Failed'
    for k, v in send_msg_dict.items():
        status = new_send_msg(user_info.client_id,content_list, v)
        #status = send_msg_to_android(k, content_list, v)

    batch_send_task.send_time_real = int(time.time())

    if status == SUCCESS:
        logger.info(u"任务发送成功, client_id: %s." % user_info.client_id)
        batch_send_task.status = BATCH_SEND_TASK_STATUS_3
        batch_send_task.save()
        return SUCCESS
    else:
        logger.info(u"任务发送失败, client_id: %s." % user_info.client_id)
        batch_send_task.status = BATCH_SEND_TASK_STATUS_4
        batch_send_task.save()
        return SUCCESS


# def _add_task_to_consumption_task(uqr_info, um_lib, bs_task_info):
#     """
#     将任务放入consumption_task
#     :return:
#     """
#     status = add_task_to_consumption_task(uqr_info, um_lib, bs_task_info.user_id,
#                                           CONSUMPTION_TASK_TYPE["batch_sending_task"], bs_task_info.sending_task_id)
#     return status


def delete_batch_sending_task(batch_send_task_id):
    batch_send_task = BaseModel.fetch_by_id(BatchSendTask, batch_send_task_id)
    if not batch_send_task:
        return err.ERR_WRONG_ITEM

    batch_send_task.is_deleted = 1
    batch_send_task.save()

    return SUCCESS
