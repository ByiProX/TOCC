# -*- coding: utf-8 -*-
import json
import logging

import requests
import time
import uuid
import random

from configs.config import SUCCESS, ERR_UNKNOWN_ERROR, ANDROID_SERVER_URL_SEND_MASS_MESSAGE, \
    ANDROID_SERVER_URL_SEND_MESSAGE, acs_client, ERR_INVALID_PHONE,ANDROID_SERVER_URL_BOT_STATUS,ERR_BOT_ERROR,UserQunR
from aliyunsdkdysmsapi.request.v20170525 import SendSmsRequest
from models_v2.base_model import BaseModel, CM


logger = logging.getLogger('main')

def get_all_bots():
    req = requests.get(ANDROID_SERVER_URL_BOT_STATUS)
    return json.loads(req.content)


def get_master_bot(client_id,chatroomname):
    cqrs = BaseModel.fetch_all(UserQunR, '*', where_clause=BaseModel.where_dict({'client_id':client_id,"chatroomname":chatroomname }))
    all_bots = get_all_bots()
    if cqrs:
        cqrs_json_list = [r.to_json_full() for r in cqrs]
        cqrs_json_list.sort(key=lambda e:e.get("weight"), reverse=True)
        for cqr in cqrs_json_list:
            if all_bots[cqr.get('bot_username')]:
                return cqr.get('bot_username')
        return False
    else: 
        return False


def new_send_msg(client_id,message_list, to_list):
    for qun in to_list:
        logger.info(u"scofield new send params: %s %s %s" % (client_id,message_list, to_list))
        bot_username = get_master_bot(client_id,qun)
        if not bot_username:
            logger.info(u"没有找到机器人: %s." % client_id)
            return ERR_BOT_ERROR
        return send_msg_to_android(bot_username, message_list, to_list)
        

def send_msg_to_android(bot_username, message_list, to_list):
    data = dict()
    data.setdefault("bot_username", bot_username)
    data.setdefault("message_list", message_list)
    data.setdefault("to_list", to_list)
    logger.info(u"安卓发送任务. data: %s." % json.dumps(data))
    url = ANDROID_SERVER_URL_SEND_MASS_MESSAGE
    logger.info(u"安卓发送任务. url: %s." % url)

    req_count, req_counts = 0, 3
    while req_count < req_counts:
        response = requests.post(url=url, json=data)
        if response.status_code == 200:
            response_json = json.loads(response.content)
            err_code = response_json.get("err_code")
            if err_code == 0:
                return SUCCESS
        else:
            req_count += 1
            time.sleep(3)
            logger.info(u"任务发送失败. bot_username: %s." % bot_username)
            logger.info(u"任务发送失败. response.content: %s." % response.content)

    return ERR_UNKNOWN_ERROR


def send_ws_to_android(bot_username, data):
    logger.info(u"send_ws_to_android. data: %s." % json.dumps(data))
    url = ANDROID_SERVER_URL_SEND_MESSAGE
    logger.info(u"send_ws_to_android. url: %s." % url)

    req_count, req_counts = 0, 3
    while req_count < req_counts:
        response = requests.post(url=url, json={"bot_username": bot_username,
                                                "data": data})
        if response.status_code == 200:
            response_json = json.loads(response.content)
            err_code = response_json.get("err_code")
            if err_code == 0:
                return SUCCESS
        else:
            req_count += 1
            time.sleep(3)
            logger.info(u"send_ws_to_android failed. bot_username: %s." % bot_username)
            logger.info(u"send_ws_to_android failed. response.content: %s." % response.content)

    return ERR_UNKNOWN_ERROR


def send_sms(business_id, phone_number, sign_name, template_code, template_param=None):
    smsRequest = SendSmsRequest.SendSmsRequest()
    # 申请的短信模板编码,必填
    smsRequest.set_TemplateCode(template_code)
    # 短信模板变量参数,友情提示:如果JSON中需要带换行符,请参照标准的JSON协议对换行符的要求,比如短信内容中包含\r\n的情况在JSON中需要表示成\\r\\n,否则会导致JSON在服务端解析失败
    if template_param is not None:
        smsRequest.set_TemplateParam(template_param)
    # 设置业务请求流水号，必填。
    smsRequest.set_OutId(business_id)
    # 短信签名
    smsRequest.set_SignName(sign_name)
    # 短信发送的号码，必填。支持以逗号分隔的形式进行批量调用，批量上限为1000个手机号码,批量调用相对于单条调用及时性稍有延迟,验证码类型的短信推荐使用单条调用的方式
    smsRequest.set_PhoneNumbers(phone_number)
    # 发送请求
    smsResponse = acs_client.do_action_with_exception(smsRequest)
    return smsResponse


# def send_invite_sms(phone, url):
    
#     __business_id = uuid.uuid1()

#     print __business_id
#     phone_number = phone

#     code = ''
#     for i in range(6):
#         code_i = random.randint(0, 9)
#         code += str(code_i)
#     print code

#     sms_code = code
#     params = "{\"code\":\"" + str(sms_code) + "\"}"
#     print 'params', params
#     sign_name = '紫豆助手'
#     template_code = 'SMS_135044557'
#     response_str = send_sms(business_id = __business_id, phone_number = phone_number, sign_name = sign_name, template_code = template_code, template_param = params)
#     logger.info("sms_response: " + response_str)
#     response_json = json.loads(response_str)
#     code = response_json.get('Code')
#     return code, sms_code
