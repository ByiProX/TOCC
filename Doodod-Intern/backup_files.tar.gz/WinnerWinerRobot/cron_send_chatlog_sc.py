# -*- coding: utf-8 -*-
import re
import smtplib
import time
import os

import xlwt
import logging

from configs.config import SC_SUB, Message, Member, Chatroom
from models_v2.base_model import BaseModel
from utils.u_transformat import str_to_unicode
from email.mime.text import MIMEText
from email.header import Header
from email.mime.multipart import MIMEMultipart

logger = logging.getLogger('main')

# 输入SMTP服务器地址:
smtp_server = "smtp.exmail.qq.com"
smtp_port = 465

# 输入Email地址和口令:
from_addr = "zidoubot@doodod.com"
password = "Robot123"

to_addr = 'zhuanghoubin@doodod.com'

def get_chatlog_excel():
    sub_list = SC_SUB

    curtime = int(time.time())
    starttime = curtime - 604800

    _message_list = BaseModel.fetch_all(Message, '*', BaseModel.and_(['in', 'client_id', sub_list],
                                                                     ['>', 'create_time', starttime*1000],
                                                                     ['<', 'create_time', curtime*1000]),
                                        order_by=BaseModel.order_by({"create_time": "desc"})
                                        )
    # l = len(_message_list)
    message_list = []
    chatroom_list = []
    for _message in _message_list:
        if re.match('[0-9]+@chatroom', _message.talker):
            message_list.append(_message)
            if _message.talker not in chatroom_list:
                chatroom_list.append(_message.talker)
    if len(message_list) == 0:
        logger.info(u'没有聊天记录数据，未发送邮件')
        return 0
    workbook = xlwt.Workbook(encoding="utf-8")
    sheet_dict = {
        0: '发言人',
        1: '聊天内容',
        2: '发言时间'
    }
    for chatroom in chatroom_list:
        _chatroom = BaseModel.fetch_one(Chatroom, 'nickname', BaseModel.where_dict({'chatroomname': chatroom}))
        chatroom_name = _chatroom.nickname
        if chatroom_name == '':
            chatroom_name = _chatroom.nickname_default
        worksheet = workbook.add_sheet(chatroom_name)
        for key, value in sheet_dict.items():
            worksheet.write(0, key, value)
        i = 1
        for message in message_list:
            if message.talker == chatroom:
                real_talker = message.real_talker
                talker = BaseModel.fetch_one(Member, '*', BaseModel.where_dict({'chatroomname': chatroom,
                                                                                                  'username': real_talker}))
                talkername = ''
                if talker is not None:
                    talkername = talker.displayname
                if talkername == '':
                    talker_info = BaseModel.fetch_one('a_contact', 'nickname', BaseModel.where_dict({'username': real_talker}))
                    if talker_info is not None:
                        talkername = talker_info.nickname
                if talkername == '':
                    continue
                worksheet.write(i, 0, talkername)
                worksheet.write(i, 1, message.content)
                worksheet.write(i, 2, time.strftime('%Y-%m-%d %H:%M:%S',
                                                    time.localtime(message.create_time/1000)))
                i += 1

    file_name = 'SC_'+str(time.strftime('%Y-%m-%d', time.localtime(curtime)))+'_chatlog.xls'
    file_path = os.path.join(os.getcwd(), 'static', file_name)
    workbook.save(file_path)

    return file_name

def send_chatlog():
    file_name = get_chatlog_excel()
    if file_name == 0:
        return 0

    server = smtplib.SMTP_SSL(smtp_server, smtp_port)
    server.login(from_addr, password)

    msg = MIMEMultipart()
    msg['From'] = from_addr
    msg['To'] = to_addr
    subject = ' 聊天记录'
    msg['Subject'] = Header(str_to_unicode(subject), 'utf-8').encode()

    msg.attach(MIMEText('附件中是上周微信群里的聊天记录。请查收。', 'plain', 'utf-8'))

    file_path = os.path.join(os.getcwd(), "static", file_name)

    att = MIMEText(open(file_path, 'rb').read(), 'base64', 'utf-8')
    att['Content-Type'] = 'application/octet-stream'
    att['Content-Disposition'] = 'attachment; filename = %s' %file_name
    msg.attach(att)

    server.sendmail(from_addr, to_addr, msg.as_string())
    server.quit()
    logger.info(u'聊天记录已发送给尚层')

if __name__ == '__main__':
    send_chatlog()



