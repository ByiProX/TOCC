# -*- coding: utf-8 -*-
import json
import logging

import time

from models_v2.base_model import BaseModel, CM

logger = logging.getLogger('main')


if __name__ == '__main__':
    BaseModel.extract_from_json()
    user_info = BaseModel.fetch_one("client_member", "*", where_clause = BaseModel.where_dict({"username": "wxid_hx9fz67n8fgj22"}))
    if user_info:
        print "user_info", json.dumps(user_info.to_json_full())
    user_info = BaseModel.fetch_one("client_member", "*", where_clause = BaseModel.where_dict({"nick_name": "非凡"}))
    if user_info:
        print "user_info", json.dumps(user_info.to_json_full())

    client = BaseModel.fetch_one("client", "*", where_clause = BaseModel.where_dict({"client_id": 714}))
    client.vip = 1
    client.save()
    client = BaseModel.fetch_one("client", "*", where_clause = BaseModel.where_dict({"client_id": 562}))
    client.vip = 1
    client.save()
    client = BaseModel.fetch_one("client", "*", where_clause = BaseModel.where_dict({"client_id": 562}))
    client.vip = 1
    client.save()

    # bot_info_list = BaseModel.fetch_all("bot_info", "*")
    # for bot_info in bot_info_list:
    #     bot_info.vip = 0 if bot_info.username in ("wxid_jxqmadytiexe22", "wxid_3mxn5zyskbpt22", "wxid_lkruzsl7w2r822", "wxid_77txprhfmu5n22") else 1
    #     bot_info.save()
    #
    # bot_info_list = BaseModel.fetch_all("bot_info", "*", where_clause = BaseModel.and_(["!=", "vip", 1]))
    # print len(bot_info_list)

    # ubr_info = BaseModel.fetch_one("client_bot_r", "*", where_clause = BaseModel.where_dict({"client_id": 1}))
    # ubr_info.client_id = 1
    # ubr_info.bot_username = "wxid_ljpr5royfums21"
    # ubr_info.is_work = 1
    # ubr_info.create_time = int(time.time())
    # ubr_info.save()

    # a_chatroom_r_list = BaseModel.fetch_all("a_chatroom_r", "*" , where_clause = BaseModel.where_dict({"bot_username": "wxid_eg8kqg9ajk4d22"}))
    # chatroomname_list = [r.chatroomname for r in a_chatroom_r_list]
    # print 'chatroomname_list', json.dumps(chatroomname_list)
    # user_username_set = {"EvaZhu1990", "wxid_094ows6qxz3712", "wxid_4sg3zyxf8r6912", "wxid_fibbgpc2i6y012", "EvaZhu2016", "L1381009z", "wxid_otjpj5h5qzxe22", "yangshuhang1112", "wxid_z42ns41xxcms12", "Su_031118", "shangcengkefu", "yxn568696", "wxid_vr5olegcnqlp22", "sczspg001", "wxid_pf9j80ehs3mm12", "wxid_fncpiwa7o3gm12", "pinguan-heyinyan"}
    # client_bot_r = BaseModel.fetch_all("client_bot_r", "*", where_clause = BaseModel.where_dict({"bot_username": "wxid_eg8kqg9ajk4d22"}))
    # client_bot_r_id = [r.client_id for r in client_bot_r]
    # print 'client_bot_r_id', json.dumps(client_bot_r_id)
    # for client_id in client_bot_r_id:
    #     user_info = BaseModel.fetch_one("client_member", "*", where_clause = BaseModel.where_dict({"client_id": client_id}))
    #     print 'client nick_name', user_info.nick_name

    # bot_username = "wxid_eg8kqg9ajk4d22"
    # a_chatroom_r_list = BaseModel.fetch_all("a_chatroom_r", "*", where_clause = BaseModel.where_dict({"bot_username": bot_username}))
    # # print "a_chatroom_r_list", a_chatroom_r_list
    # chatroomname_list = [r.chatroomname for r in a_chatroom_r_list]
    # print 'chatroomname_list', json.dumps(chatroomname_list)
    # chatroom_member = dict()
    # for chatroomname in chatroomname_list:
    #     a_chatroom = BaseModel.fetch_one("a_chatroom", "*", where_clause = BaseModel.where_dict({"chatroomname": chatroomname}))
    #     if a_chatroom:
    #         memberlist = a_chatroom.memberlist
    #         chatroom_member.setdefault(a_chatroom.chatroomname, set())
    #         members = memberlist.split(";")
    #         for member in members:
    #             chatroom_member[a_chatroom.chatroomname].add(member)
    # print 'chatroom_member', chatroom_member
    # client_id_list = [602, 603, 605, 606, 607, 609, 694, 748, 749, 750, 751, 752, 753, 754, 757, 759, 761]
    # user_info_list = BaseModel.fetch_all("client_member", "*", where_clause = BaseModel.where_dict(["in", "client_id", client_id_list]))
    # for user_info in user_info_list:
    #     if user_info.username:
    #         print json.dumps(user_info.to_json_full())
    #         for chatroomname, member_set in chatroom_member.iteritems():
    #             if user_info.username in member_set:
    #                 # Mark 绑定
    #                 uqr = CM("client_qun_r")
    #                 uqr.client_id = user_info.client_id
    #                 uqr.chatroomname = chatroomname
    #                 uqr.bot_username = bot_username
    #                 uqr.status = 1
    #                 uqr.group_id = unicode(user_info.client_id) + u"_0"
    #                 uqr.create_time = int(time.time())
    #                 uqr.is_paid = 1
    #                 uqr.save()
    #                 print u"user与群关系已绑定. user_id: %s. chatroomname: %s." % (user_info.client_id, chatroomname)
    #     else:
    #         print 'no username', json.dumps(user_info.to_json_full())
        # ubr = BaseModel.fetch_one("client_bot_r", "*", where_clause = BaseModel.where_dict({"client_id": user_info.client_id}))
        # if ubr:
        #     print user_info.client_id, user_info.nick_name, user_info.username, ubr.bot_username
        # else:
        #     print 'no ubr', user_info.client_id, user_info.nick_name, user_info.username


pass
