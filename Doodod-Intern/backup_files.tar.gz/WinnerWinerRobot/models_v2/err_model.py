# -*- coding: utf-8 -*-
import json


class ErrorModel(object):
    def __init__(self):
        self.generate_attrs()

    def generate_attrs(self):
        with open("error-config/error-config.json", "r") as f:
            errors = json.load(f)['err']
        for k,v in errors.items():
            v['err_name'] = k
            setattr(self, k, v)