import requests

response = requests.get('http://www.imtagger.com/yaca_api/cron/update_chatroom_statistics')
