# -*- coding: utf-8 -*-

from flask import request

from configs.config import main_api_v2, err
from core_v2.user_core import UserLogin
from models_v2.base_model import *
from utils.tag_handle import Tag
from utils.u_response import make_response
from utils.z_utils import para_check

logger = logging.getLogger('main')


@main_api_v2.route('/ad_switch', methods=['POST'])
@para_check('token', 'switch')
def app_ad_switch():
    status, user_info = UserLogin.verify_token(request.json.get('token'))
    if status != SUCCESS:
        return make_response(status)

    # Switch func.
    switch = request.json.get('switch')
    if switch not in (True, False):
        return make_response(err.ERR_INVALID_PARAMS)
    users = BaseModel.fetch_all(UserInfo, '*', where_clause=BaseModel.where_dict({'client_id': user_info.client_id}))
    status_list = list()
    if switch:
        for user in users:
            user.func_switch = Tag(user_info.func_switch).put_name('ad').as_int()
            status_list.append(user.update())
    else:
        for user in users:
            user.func_switch = Tag(user_info.func_switch).delete_name('ad').as_int()
            status_list.append(user.update())

    for status in status_list:
        if not status:
            return make_response(err.ERR_INVALID_PARAMS)
    return make_response(SUCCESS, switch=switch)