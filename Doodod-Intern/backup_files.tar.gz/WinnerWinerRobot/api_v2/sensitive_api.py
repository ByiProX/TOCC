# -*- coding: utf-8 -*-
import re
import time
import traceback

from flask import request

from configs.config import *
from core_v2.user_core import UserLogin
from models_v2.base_model import *
from utils.tag_handle import Tag
from utils.u_response import make_response
from utils.z_utils import para_check, _10_to_true_false, get_real_username


@main_api_v2.route('/switch_sensitive', methods=['POST'])
@para_check('token', 'switch')
def app_switch_sensitive():
    status, user_info = UserLogin.verify_token(request.json.get('token'))
    if status != SUCCESS:
        return make_response(status)
    
    # Switch func.
    switch = request.json.get('switch')
    if switch not in (True, False):
        return make_response(err.ERR_INVALID_PARAMS)
    users = BaseModel.fetch_all(UserInfo, '*', where_clause=BaseModel.where_dict({'client_id': user_info.client_id}))
    status_list = list()
    if switch:
        for user in users:
            user.func_switch = Tag(user_info.func_switch).put_name('sensitive').as_int()
            status_list.append(user.update())
    else:
        for user in users:
            user.func_switch = Tag(user_info.func_switch).delete_name('sensitive').as_int()
            status_list.append(user.update())

    for status in status_list:
        if not status:
            return make_response(err.ERR_INVALID_PARAMS)
    return make_response(SUCCESS, switch=switch)




@main_api_v2.route('/sensitive_rule', methods=['POST'])
@para_check("token", "chatroom_name_list", "sensitive_word_list")
def create_or_modify_sensitive_rule():
    # Check owner or return.
    status, user_info = UserLogin.verify_token(request.json.get('token'))
    try:
        owner = user_info.client_id
    except AttributeError:
        return make_response(err.ERR_USER_TOKEN)

    # Use regular expression check chatroom_name_list.
    _chatroom_name_list = request.json.get('chatroom_name_list')
    for i in _chatroom_name_list:
        if not re.match('[0-9]+@chatroom', i):
            return make_response(err.ERR_INVALID_PARAMS)

    GLOBAL_RULES_UPDATE_FLAG[GLOBAL_SENSITIVE_WORD_RULES_UPDATE_FLAG] = True

    if request.json.get('rule_id') is not None:
        # Modify rule.
        rule_id = request.json.get('rule_id')
        # Get a available previous rule by its id.
        previous_rule = BaseModel.fetch_by_id('sensitive_message_rule', rule_id)
        if previous_rule is None:
            return make_response(err.ERR_NOT_EXIST_SENSITIVE_RULE)
        # Modify this rule.
        value_as_dict = request.json
        previous_rule.chatroom_name_list = value_as_dict["chatroom_name_list"]
        previous_rule.sensitive_word_list = value_as_dict["sensitive_word_list"]
        previous_rule.owner_list = [owner, ]
        if request.json.get('remark'):
            previous_rule.remark = request.json.get('remark')
        if request.json.get('remark') is None and previous_rule.remark is not None:
            previous_rule.remark = None
        previous_rule.cover = request.json.get('cover')
        previous_rule.save()
        # modified_rule = BaseModel.fetch_by_id('sensitive_message_rule', rule_id)
        modified_rule_result = previous_rule.to_json_full()
        # modified_rule = BaseModel.fetch_by_id('sensitive_message_rule', rule_id)
        # if request.json.get('remark') is not None:
        #     modified_rule_result = {
        #         'rule_id': rule_id,
        #         'chatroom_name_list': modified_rule.chatroom_name_list,
        #         'sensitive_word_list': modified_rule.sensitive_word_list,
        #         'owner_list': modified_rule.owner_list,
        #         'is_work': modified_rule.is_work,
        #         'remark': modified_rule.remark
        #     }
        # else:
        #     modified_rule_result = {
        #         'rule_id': rule_id,
        #         'chatroom_name_list': modified_rule.chatroom_name_list,
        #         'sensitive_word_list': modified_rule.sensitive_word_list,
        #         'owner_list': modified_rule.owner_list,
        #         'is_work': modified_rule.is_work,
        #     }
        return make_response(SUCCESS, info = _10_to_true_false(modified_rule_result))
    else:
        # Create rule.
        client_info = BaseModel.fetch_one(Client, 'vip',
                                          where_clause=BaseModel.where_dict({'client_id': user_info.client_id}))
        sensitive_rule_list = BaseModel.count('sensitive_message_rule', where_clause=BaseModel.where_dict(
            {'owner_list': [user_info.client_id]}))
        if client_info.vip:
            if sensitive_rule_list > DEFAULT_VIP_SENSITIVE_LIST_LIMIT:
                return make_response(err.ERR_SENSITIVE_LIMIT)
        else:
            if sensitive_rule_list > DEFAULT_SENSITIVE_LIST_LIMIT:
                return make_response(err.ERR_SENSITIVE_LIMIT)
        new_rule = CM('sensitive_message_rule')
        value_as_dict = request.json
        new_rule.chatroom_name_list = value_as_dict["chatroom_name_list"]
        new_rule.sensitive_word_list = value_as_dict["sensitive_word_list"]
        new_rule.owner_list = [owner, ]
        # 新增可选字段remark
        # 0:监控全部
        # 1:监控业务员
        # 2:监控非业务员
        if request.json.get('remark'):
            new_rule.remark = request.json.get('remark')
        # 新增字段，监控人群设置
        new_rule.cover = request.json.get('cover')
        new_rule.is_work = 1
        new_rule.save()
        created_rule = BaseModel.fetch_by_id('sensitive_message_rule', new_rule.sensitive_message_rule_id)
        created_rule_result = new_rule.to_json_full()
        # if request.json.get('remark') is not None:
        #     created_rule_result = {
        #         'rule_id': new_rule.sensitive_message_rule_id,
        #         'chatroom_name_list': created_rule.chatroom_name_list,
        #         'sensitive_word_list': created_rule.sensitive_word_list,
        #         'owner_list': created_rule.owner_list,
        #         'is_work': created_rule.is_work,
        #         'remark': created_rule.remark
        #     }
        # else:
        #     created_rule_result = {
        #         'rule_id': new_rule.sensitive_message_rule_id,
        #         'chatroom_name_list': created_rule.chatroom_name_list,
        #         'sensitive_word_list': created_rule.sensitive_word_list,
        #         'owner_list': created_rule.owner_list,
        #         'is_work': created_rule.is_work
        #     }
        return make_response(SUCCESS, info = _10_to_true_false(created_rule_result))


@main_api_v2.route('/sensitive_rule_delete', methods=['POST'])
@para_check("token", "rule_id", )
def sensitive_rule_delete():
    rule_id = request.json.get('rule_id')
    this_rule = BaseModel.fetch_by_id('sensitive_message_rule', rule_id)
    if this_rule is None:
        return make_response(err.ERR_NOT_EXIST_SENSITIVE_RULE)
    this_rule.is_work = 0
    this_rule.save()
    this_rule_result = {
        'rule_id': this_rule.sensitive_message_rule_id,
        'chatroom_name_list': this_rule.chatroom_name_list,
        'sensitive_word_list': this_rule.sensitive_word_list,
        'owner_list': this_rule.owner_list,
        'is_work': this_rule.is_work
    }
    GLOBAL_RULES_UPDATE_FLAG[GLOBAL_SENSITIVE_WORD_RULES_UPDATE_FLAG] = True
    return make_response(SUCCESS, info = _10_to_true_false(this_rule_result))


@main_api_v2.route('/sensitive_rule_list', methods=['POST'])
@para_check("token", )
def sensitive_rule_list():
    # Check owner or return.
    status, user_info = UserLogin.verify_token(request.json.get('token'))
    try:
        owner = user_info.client_id
    except AttributeError:
        return make_response(err.ERR_USER_TOKEN)

    all_rule_list = BaseModel.fetch_all('sensitive_message_rule', '*', BaseModel.where_dict({'is_work': 1}))
    this_owner_rule_list = []
    content = []

    for rule in all_rule_list:
        if owner in rule.owner_list:
            this_owner_rule_list.append(rule)

    for rule in this_owner_rule_list:
        rule_id = rule.sensitive_message_rule_id
        # Create chatroom_list
        chatroom_list = []
        for chatroomname in rule.chatroom_name_list:
            this_chatroom = BaseModel.fetch_one('a_chatroom', '*', BaseModel.where_dict({'chatroomname': chatroomname}))
            if this_chatroom is None:
                return make_response(err.ERR_NOT_EXIST_CHATROOM)
            avatar_url = this_chatroom.avatar_url
            nickname = this_chatroom.nickname_real
            nickname_default = this_chatroom.nickname_default
            if nickname == '':
                nickname = nickname_default
            chatroom_list.append(
                {'avatar_url': avatar_url, 'chatroomname': chatroomname, 'chatroom_nickname': nickname})

        sensitive_word_list = rule.sensitive_word_list
        remark = rule.remark
        cover = rule.cover
        content.append({'rule_id': rule_id, 'chatroom_list': chatroom_list, 'sensitive_word_list': sensitive_word_list,
                        'remark': remark, 'cover': cover})

    return make_response(SUCCESS, rule_list = content)


@main_api_v2.route('/_sensitive_message_log', methods=['POST'])
@para_check("token", "date_type", "page", "pagesize")
def _sensitive_message_log():
    # Check owner or return.
    status, user_info = UserLogin.verify_token(request.json.get('token'))
    try:
        owner = user_info.client_id
    except AttributeError:
        return make_response(err.ERR_USER_TOKEN)

    now = int(time.time())
    date_type = int(request.json.get('date_type'))
    page = int(request.json.get('page'))
    pagesize = int(request.json.get('pagesize'))

    """
    date_type
    -> 1 今天
    -> 2 昨天
    -> 3 近7天
    -> 4 近30天
    -> 5 全部
    """
    cur_time = time.time()
    today_start = int(cur_time - cur_time % 86400)
    yesterday_start = int(cur_time - cur_time % 86400 - 86400)
    seven_before = int(cur_time - cur_time % 86400 - 86400 * 6)
    thirty_before = int(cur_time - cur_time % 86400 - 86400 * 29)

    time_dict = {
        1: (today_start, now),
        2: (yesterday_start, today_start),
        3: (seven_before, now),
        4: (thirty_before, now),
        5: (0, now)
    }

    time_limit = time_dict[date_type]

    _all_log_list = []

    all_rule = BaseModel.fetch_all('sensitive_message_rule', '*', BaseModel.where_dict({'is_work': 1}))

    for rule in all_rule:
        owner_list = rule.owner_list
        this_owner = owner_list[0]
        if this_owner == owner:
            owner_all_log_list = BaseModel.fetch_all('sensitive_message_log', '*',
                                                     BaseModel.and_([">", "create_time", time_limit[0]],
                                                                    ["<", "create_time", time_limit[1]],
                                                                    ["=", "owner", owner], ),
                                                     order_by=BaseModel.order_by({"create_time": "desc"}),
                                                     page=page,
                                                     pagesize=pagesize)

            for log in owner_all_log_list:
                if rule.sensitive_message_rule_id == log.rule_id and log.sensitive_word in rule.sensitive_word_list:
                    _all_log_list.append(log)

    message_list = []

    all_log_list = _all_log_list
    total_count = len(_all_log_list)
    for log in all_log_list:
        this_chatroom = BaseModel.fetch_one('a_chatroom', '*', BaseModel.where_dict({'chatroomname': log.chatroomname}))
        this_speaker = BaseModel.fetch_one('a_contact', '*', BaseModel.where_dict({'username': log.speaker_username}))

        chatroom_nickname = this_chatroom.nickname_real if this_chatroom else 'None'
        chatroom_avatar_url = this_chatroom.avatar_url if this_chatroom else 'None'
        chatroom_nickname_default = this_chatroom.nickname_default if this_chatroom else ''
        _chatroom_memberlist = this_chatroom.memberlist if this_chatroom else None
        if _chatroom_memberlist:
            chatroom_membercount = len(_chatroom_memberlist.split(';'))
        else:
            chatroom_membercount = 0
        if chatroom_nickname == '':
            chatroom_nickname = chatroom_nickname_default

        speaker_nickname = this_speaker.nickname if this_speaker else 'None'
        speaker_avatar_url = this_speaker.avatar_url if this_speaker else 'None'

        temp = {
            'sensitive_word': log.sensitive_word,
            'message': {
                'content': log.content,
                'chatroom': {
                    'chatroom_nickname': chatroom_nickname,
                    'avatar_url': chatroom_avatar_url,
                    'chatroomname': log.chatroomname,
                    'member_count': chatroom_membercount,
                },
                'speaker': {
                    'speaker_nickname': speaker_nickname,
                    'avatar_url': speaker_avatar_url,
                    'speaker_id': log.speaker_username,
                },
                'date': int(log.create_time),
            },
        }
        message_list.append(temp)
    return make_response(SUCCESS, last_update_time = int(time.time()), total_count = total_count, message_list = message_list)


@main_api_v2.route('/sensitive_message_log', methods=['POST'])
@para_check("token", "date_type", "page", "pagesize")
def sensitive_message_log():
    # Check owner or return.
    status, user_info = UserLogin.verify_token(request.json.get('token'))
    try:
        owner = user_info.client_id
    except AttributeError:
        return make_response(err.ERR_USER_TOKEN)

    now = int(time.time())
    date_type = int(request.json.get('date_type'))
    page = int(request.json.get('page'))
    pagesize = int(request.json.get('pagesize'))

    """
    date_type
    -> 1 今天
    -> 2 昨天
    -> 3 近7天
    -> 4 近30天
    -> 5 全部
    """
    cur_time = time.time()
    today_start = int(cur_time - cur_time % 86400)
    yesterday_start = int(cur_time - cur_time % 86400 - 86400)
    seven_before = int(cur_time - cur_time % 86400 - 86400 * 6)
    thirty_before = int(cur_time - cur_time % 86400 - 86400 * 29)

    time_dict = {
        1: (today_start, now),
        2: (yesterday_start, today_start),
        3: (seven_before, now),
        4: (thirty_before, now),
        5: (0, now)
    }

    time_limit = time_dict[date_type]

    all_rule = BaseModel.fetch_all('sensitive_message_rule', '*', BaseModel.where_dict({'is_work': 1}))

    owner_all_rule_id_list = []
    for rule in all_rule:
        this_owner = rule.owner_list[0]
        if this_owner == owner:
            owner_all_rule_id_list.append(rule.get_id())

    _all_log_list = BaseModel.fetch_all('sensitive_message_log', '*',
                                        BaseModel.and_([">", "create_time", time_limit[0]],
                                                       ["<", "create_time", time_limit[1]],
                                                       ["=", "owner", owner],
                                                       ["in", "rule_id", owner_all_rule_id_list]),
                                        order_by=BaseModel.order_by({"create_time": "desc"}),
                                        page=page,
                                        pagesize=pagesize)

    message_list = []

    all_log_list = _all_log_list
    # Get total count.
    total_count = BaseModel.count("sensitive_message_log", where_clause = BaseModel.and_([">", "create_time", time_limit[0]],
                                                                                         ["<", "create_time", time_limit[1]],
                                                                                         ["=", "owner", owner],
                                                                                         ["in", "rule_id", owner_all_rule_id_list]))
    for log in all_log_list:
        this_chatroom = BaseModel.fetch_one('a_chatroom', '*', BaseModel.where_dict({'chatroomname': log.chatroomname}))
        this_speaker = BaseModel.fetch_one('a_contact', '*', BaseModel.where_dict({'username': log.speaker_username}))
        this_rule = BaseModel.fetch_by_id('sensitive_message_rule', log.rule_id)

        remark = this_rule.remark
        cover = this_rule.cover
        chatroom_nickname = this_chatroom.nickname_real if this_chatroom else 'None'
        chatroom_avatar_url = this_chatroom.avatar_url if this_chatroom else 'None'
        chatroom_nickname_default = this_chatroom.nickname_default if this_chatroom else ''
        _chatroom_memberlist = this_chatroom.memberlist if this_chatroom else None
        if _chatroom_memberlist:
            chatroom_membercount = len(_chatroom_memberlist.split(';'))
        else:
            chatroom_membercount = 0
        if chatroom_nickname == '':
            chatroom_nickname = chatroom_nickname_default

        speaker_nickname = this_speaker.nickname if this_speaker else 'None'
        speaker_avatar_url = this_speaker.avatar_url if this_speaker else 'None'

        temp = {
            'sensitive_word': log.sensitive_word,
            'remark': remark,
            'cover': cover,
            'message': {
                'content': log.content,
                'chatroom': {
                    'chatroom_nickname': chatroom_nickname,
                    'avatar_url': chatroom_avatar_url,
                    'chatroomname': log.chatroomname,
                    'member_count': chatroom_membercount,
                },
                'speaker': {
                    'speaker_nickname': speaker_nickname,
                    'avatar_url': speaker_avatar_url,
                    'speaker_id': log.speaker_username,
                },
                'date': int(log.create_time),
            },
        }
        message_list.append(temp)

    return make_response(SUCCESS, last_update_time = int(time.time()), total_count = total_count, message_list = message_list)


@main_api_v2.route('/_sensitive_add', methods=['POST'])
@para_check("check", )
def _sensitive_add():
    try:
        def get_token(_username):
            _client = BaseModel.fetch_one('client_member', '*', BaseModel.where_dict({'username': _username}))
            if _client is not None and _client.token is not None:
                return _client.token
            return False

        def get_group_list_by_token(_token):
            res = requests.post('http://api.xuanren360.com/yaca_api_v2/get_group_list', json={'token': _token}).json()

            if res['err_code'] == 0:
                chatroom_list = res['content']['group_list'][0]['chatroom_list']
                return [i['chatroomname'] for i in chatroom_list]
            else:
                return []

        username_list = ["wxid_fibbgpc2i6y012", "wxid_fncpiwa7o3gm12", "wxid_z42ns41xxcms12", "wxid_vr5olegcnqlp22",
                         "wxid_4h9kaok0d1m522", "wxid_4sg3zyxf8r6912", "wxid_094ows6qxz3712", "yangshuhang1112",
                         "shangcengkefu", "yxn568696", "wxid_pf9j80ehs3mm12", "pinguan-heyinyan", "L1381009z",
                         "EvaZhu2016", "sczspg001", "wxid_otjpj5h5qzxe22", "Su_031118", "suarama", "zywaqiu"]
        check = request.json.get('check')

        real_username_list = []
        token_list = []
        set_dict = {}
        # Token : chatroom_list

        for i in username_list:
            real_username_list.append(get_real_username(i))

        for i in real_username_list:
            _token = get_token(i)
            if _token:
                token_list.append(_token)

        for i in token_list:
            its_chatroom_list = get_group_list_by_token(i)
            if its_chatroom_list != []:
                set_dict[i] = its_chatroom_list

        if check:
            make_response(SUCCESS, info = set_dict)
        res = []
        for token, chatroom_list in set_dict.items():
            resp = requests.post('http://api.xuanren360.com/yaca_api_v2/sensitive_rule', json={'token': token,
                                                                                             'chatroom_name_list': chatroom_list,
                                                                                             'sensitive_word_list': [
                                                                                                 "他妈的", "骗子", "滚", "妈逼",
                                                                                                 "TM", "tm", "傻逼", "MD",
                                                                                                 "混蛋", "无语", "不负责任",
                                                                                                 "能蒙就蒙", "能骗就骗", "能拖就拖",
                                                                                                 "醉了", "孙子似的", "无人关心",
                                                                                                 "火死了", "上火", "体验差",
                                                                                                 "让人伤心", "费这么多心",
                                                                                                 "言而无信", "无人回复", "傻子",
                                                                                                 "管理形同虚设", "太坑了", "糟糕",
                                                                                                 "坑人", "失望", "生气",
                                                                                                 "无法接受", "拖延", "敷衍了事",
                                                                                                 "我要投诉", "不到位", "时间太长",
                                                                                                 "一塌糊涂", "不满意", "没人管",
                                                                                                 "进度太慢", "没诚信", "一拖再拖",
                                                                                                 "低级错误", "操心", "索赔",
                                                                                                 "太不靠谱", "恼火", "气愤",
                                                                                                 "敷衍", "太不像话", "忍无可忍",
                                                                                                 "没有信用", "拖拖拉拉", "失去信心",
                                                                                                 "效率太低", "地摊货", "散沙",
                                                                                                 "没人协调", "后悔", "无人监督",
                                                                                                 "什么服务", "糊弄", "管理太烂",
                                                                                                 "对付", "一团乱麻", "不管不问",
                                                                                                 "套路深", "应付", "太差",
                                                                                                 "扯皮", "缺陷很多", "操不完的心",
                                                                                                 "防不胜防", "糟心", "不省心",
                                                                                                 "推卸责任", "什么玩意儿",
                                                                                                 "店大欺客", "当放屁", "经济赔偿",
                                                                                                 "没办法接受", "没人落实解决",
                                                                                                 "没人推进", "忽悠", "花钱买罪受",
                                                                                                 "绝望", "极差", "欺人太甚",
                                                                                                 "坑", "天天追问", "无人回我",
                                                                                                 "散慢", "恶心", "断档",
                                                                                                 "掉链子", "荒唐", "冒火",
                                                                                                 "烦心", "差强人意", "不认真",
                                                                                                 "霸王条款", "费解", "愤怒",
                                                                                                 "稀稀拉拉", "没人干活", "路边摊",
                                                                                                 "虎头蛇尾", "没下文", "抱怨",
                                                                                                 "没有保护", "不要在拖",
                                                                                                 "不像是尚层的作品", "头疼",
                                                                                                 "管理混乱", "麻烦", "损失",
                                                                                                 "引起重视", "遗憾", "不公平",
                                                                                                 "欺诈", "添堵", "什么意思",
                                                                                                 "气人", "煎熬", "崩溃",
                                                                                                 "心灰意冷", "有失尚层水准",
                                                                                                 "天天没动静", "遥遥无期",
                                                                                                 "没法放心", "不客气了", "烦恼",
                                                                                                 "没有办法", "借口", "垃圾",
                                                                                                 "抓点紧", "纸上谈兵", "不闻不问",
                                                                                                 "不把客户当回事了 ", "催",
                                                                                                 "只收钱不管事", "质量太差",
                                                                                                 "乱七八糟", "过分", "不抱希望",
                                                                                                 "失去信任", "快疯了", "折腾",
                                                                                                 "两个态度", "不放心", "真差",
                                                                                                 "蒙混过关", "有没有人管", "没反馈",
                                                                                                 "赔偿", "一错再错", "不用心",
                                                                                                 "心塞", "野蛮施工", "不舒服",
                                                                                                 "说法", "怒火难平", "讨厌",
                                                                                                 "返工", "装修无限期", "补偿",
                                                                                                 "色差严重", "很累", "脏乱",
                                                                                                 "推三阻四", "不守时", "欺骗",
                                                                                                 "乱班子", "严重质疑", "问题太多",
                                                                                                 "粗制滥造", "卫生太差", "陷阱",
                                                                                                 "施工形象不佳", "当客户说话是放屁",
                                                                                                 "都在干嘛", "心里别扭", "无动于衷",
                                                                                                 "相互推脱", "怎么这么", "怎能",
                                                                                                 "是这样", "谁能", "有何用呢",
                                                                                                 "可以接受吗", "不应该", "难道",
                                                                                                 "这是", "这就是", "就这么",
                                                                                                 "有何感想呢", "为什么", "谁来",
                                                                                                 "谁说了算", "怎么", "不知道吗",
                                                                                                 "如何", "有那么", "谁让",
                                                                                                 "公司领导", "找高层", "尚层领导",
                                                                                                 "管理层", "分总", "总经理",
                                                                                                 "找林总", "你们老板", "媒体",
                                                                                                 "法律", "诉讼", "律师函",
                                                                                                 "消协", "起诉", "电视台",
                                                                                                 "曝光", "见报", "记者",
                                                                                                 "官方机构", "宣传", "朋友圈",
                                                                                                 "报道", "网站", "网上", "官司",
                                                                                                 "新闻", "法院"],
                                                                                             }).json()
            res.append(resp)
        return make_response(SUCCESS, result = res)
    except Exception as e:
        logger.error("发生未知错误，捕获所有异常，待查")
        logger.error(traceback.format_exc())
        return make_response(err.ERR_UNKNOWN_ERROR)


@main_api_v2.route('/sensitive_message_log_shangceng', methods=['POST'])
@para_check('token', 'date_type', 'page', 'pagesize')
def sensitive_message_log_shangceng():
    status, user_info = UserLogin.verify_token(request.json.get('token'))

    if status != SUCCESS or not user_info:
        return make_response(status)

    this_user = user_info.client_id
    if this_user not in SC_HEAD:
        return make_response(err.ERR_WRONG_USER_ITEM)

    sub_client_id_list = SC_SUB

    sub_client_id = request.json.get('sub_client_id')

    if not sub_client_id:
        ownerlist = sub_client_id_list
    else:
        ownerlist = [sub_client_id]

    now = int(time.time())
    date_type = int(request.json.get('date_type'))
    page = int(request.json.get('page'))
    pagesize = int(request.json.get('pagesize'))

    """
        date_type
        -> 1 今天
        -> 2 昨天
        -> 3 近7天
        -> 4 近30天
        -> 5 全部
        """
    cur_time = time.time()
    today_start = int(cur_time - cur_time % 86400)
    yesterday_start = int(cur_time - cur_time % 86400 - 86400)
    seven_before = int(cur_time - cur_time % 86400 - 86400 * 6)
    thirty_before = int(cur_time - cur_time % 86400 - 86400 * 29)

    time_dict = {
        1: (today_start, now),
        2: (yesterday_start, today_start),
        3: (seven_before, now),
        4: (thirty_before, now),
        5: (0, now)
    }

    time_limit = time_dict[date_type]

    all_rule = BaseModel.fetch_all('sensitive_message_rule', '*', BaseModel.where_dict({'is_work': 1}))

    owner_all_rule_id_list = []
    message_list = []

    for rule in all_rule:
        this_owner = rule.owner_list[0]
        if this_owner in ownerlist:
            owner_all_rule_id_list.append(rule.get_id())

    all_log_list = BaseModel.fetch_all('sensitive_message_log', '*',
                                        BaseModel.and_(['>', 'create_time', time_limit[0]],
                                                       ['<', 'create_time', time_limit[1]],
                                                       ['in', 'owner', ownerlist],
                                                       ['in', 'rule_id', owner_all_rule_id_list]),
                                        order_by=BaseModel.order_by({"create_time": "desc"}),
                                        page=page,
                                        pagesize=pagesize)

    total_count = BaseModel.count('sensitive_message_log', where_clause = BaseModel.and_(['>', 'create_time', time_limit[0]],
                                                                                         ['<', 'create_time', time_limit[1]],
                                                                                         ['in', 'owner', ownerlist],
                                                                                         ['in', 'rule_id', owner_all_rule_id_list]))
    for log in all_log_list:
        this_chatroom = BaseModel.fetch_one('a_chatroom', '*', BaseModel.where_dict({'chatroomname': log.chatroomname}))
        this_speaker = BaseModel.fetch_one('a_contact', '*', BaseModel.where_dict({'username': log.speaker_username}))
        this_rule = BaseModel.fetch_by_id('sensitive_message_rule', log.rule_id)

        remark = this_rule.remark
        cover = this_rule.cover
        chatroom_nickname = this_chatroom.nickname_real if this_chatroom else 'None'
        chatroom_avatar_url = this_chatroom.avatar_url if this_chatroom else 'None'
        chatroom_nickname_default = this_chatroom.nickname_default if this_chatroom else ''
        _chatroom_memberlist = this_chatroom.memberlist if this_chatroom else None
        if _chatroom_memberlist:
            chatroom_membercount = len(_chatroom_memberlist.split(';'))
        else:
            chatroom_membercount = 0
        if chatroom_nickname == '':
            chatroom_nickname = chatroom_nickname_default

        speaker_nickname = this_speaker.nickname if this_speaker else 'None'
        speaker_avatar_url = this_speaker.avatar_url if this_speaker else 'None'

        temp = {
            'sensitive_word': log.sensitive_word,
            'remark': remark,
            'cover': cover,
            'message': {
                'content': log.content,
                'chatroom': {
                    'chatroom_nickname': chatroom_nickname,
                    'avatar_url': chatroom_avatar_url,
                    'chatroomname': log.chatroomname,
                    'member_count': chatroom_membercount,
                },
                'speaker': {
                    'speaker_nickname': speaker_nickname,
                    'avatar_url': speaker_avatar_url,
                    'speaker_id': log.speaker_username,
                },
                'date': int(log.create_time),
            },
        }
        message_list.append(temp)

    return make_response(SUCCESS, last_update_time=int(time.time()), total_count=total_count, message_list=message_list)


