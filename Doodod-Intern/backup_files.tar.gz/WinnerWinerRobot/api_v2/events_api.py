# -*- coding: utf-8 -*-
import time
import base64
import threading

import oss2
import qrcode
import requests
from flask import request

from configs.config import main_api_v2 as app_test
from core_v2.user_core import UserLogin
from models_v2.base_model import *
from utils.z_utils import para_check, response, true_false_to_10, _10_to_true_false,get_real_username
from configs.config import ENV, ANDROID_SERVER_URL, RecentReply, DEFAULT_WELCOME_TIME_LIMIT
from core_v2.user_core import _get_qr_code_base64_str
from configs.config import SUCCESS, ERR_UNKNOWN_ERROR, ANDROID_SERVER_URL_SEND_MASS_MESSAGE, ERR_INVALID_PARAMS, ERR_EXIST_EVENT, \
                            ERR_SEND_WS_TO_ANDROID, ERR_USER_TOKEN, ERR_NOT_EXIST_EVENT, ERR_WRONG_USER_ITEM, ERR_PIC_BASE64, \
                            ERR_EXIST_FISSION_WORD
from utils.u_response import make_response

logger = logging.getLogger('main')

need_update_fission_word_rule = True
need_update_condition_word_rule = True

# fission_word_rule_as_dict -> {"chatroomname" : message_list}
fission_word_rule_as_dict = {}
condition_word_rule_as_dict = {}


def rewrite_events_chatroom(roomowner, chatroom_nickname, event_id, silent=False, auto_retry=True):
    """
    roomowner -> client_id
    """
    # print('Rewrite running')
    try:
        flag = True
        events_chatroom = BaseModel.fetch_one('events_chatroom', '*', BaseModel.where_dict(
            {'roomowner': roomowner, 'chatroom_nickname': chatroom_nickname, 'chatroomname': 'default'}))
        if events_chatroom is None:
            # print('Rewrite error, because events_chatroom does not exist.')
            return 0

        # Get roomowner's bot_username
        client_bot_r = BaseModel.fetch_one('client_bot_r', '*', BaseModel.where_dict({'client_id': roomowner}))
        this_bot_username = client_bot_r.bot_username

        while flag:
            chatroom = BaseModel.fetch_one('a_chatroom', '*',
                                           BaseModel.where_dict(
                                               {'roomowner': this_bot_username, 'nickname_real': chatroom_nickname}))
            if chatroom is not None:
                chatroomname = chatroom.chatroomname
                events_chatroom = BaseModel.fetch_one('events_chatroom', '*', BaseModel.where_dict(
                    {'roomowner': roomowner, 'chatroom_nickname': chatroom_nickname}))
                if events_chatroom is None:
                    # print('Rewrite running failed because events_chatroom have not field!')
                    return 0
                events_chatroom.chatroomname = chatroomname
                events_chatroom.save()
                # Make events have enough chatroom.
                event = BaseModel.fetch_by_id('events', event_id)
                event.enough_chatroom = 1
                event.save()
                flag = False
            else:
                # print('Rewrite running failed because a_chatroom have not field!')
                return 0
            if not auto_retry:
                flag = False
            time.sleep(2)
    except Exception as e:
        if not silent:
            raise e
    # print('Rewrite ok.')
    return ' '


def create_chatroom_for_scan(event_id, __client_id, username, start_name):
    """create_chatroom_for_scan"""
    # print("Running create_chatroom_for_scan")
    """Get previous index"""
    previous_chatroom_list = BaseModel.fetch_all('events_chatroom', '*', BaseModel.where_dict({'event_id': event_id}))
    previous_index_list = []
    for i in previous_chatroom_list:
        previous_index_list.append(i.index)
    previous_index_list.sort()

    now_index = previous_index_list[-1] + 1

    # Create a chatroom for this event. index = start_index.
    chatroom_nickname = start_name + str(now_index) + u'群'
    client_bot_r = BaseModel.fetch_one('client_bot_r', '*',
                                       BaseModel.where_dict({'client_id': __client_id}))

    if client_bot_r:
        __bot_username = client_bot_r.bot_username
    else:
        logger.warning('Error when create_chatroom_for_scan')
        return 0

    create_chatroom_dict = {
        'bot_username': __bot_username,
        'data': {
            'task': 'create_chatroom',
            "owner": username,
            "chatroom_nickname": chatroom_nickname
        }
    }
    try:
        create_chatroom_resp = requests.post('http://ardsvr.walibee.com/android/send_message',
                                             json=create_chatroom_dict)
        logger.info('create_chatroom_resp(for scan):', create_chatroom_resp)
    except Exception as e:
        logger.warning('Create chatroom request error:{}'.format(e))
    # Add chatroom info in relationship.
    events_chatroom = CM('events_chatroom')
    events_chatroom.index = now_index
    events_chatroom.chatroomname = 'default'
    events_chatroom.event_id = event_id
    events_chatroom.chatroom_nickname = chatroom_nickname
    events_chatroom.roomowner = __client_id
    events_chatroom.save()
    # Update chatroomname.
    rewrite_events_chatroom(username, chatroom_nickname, event_id)
    return ' '


def status_detect(start_time, end_time, is_work, is_finish, chatroom_enough):
    """Check event status
    0 -> not finish
    1 -> running
    2 -> waiting
    3 -> is over
    4 -> chatroom not created
    """
    if not is_finish:
        return 0
    if not is_work:
        return 3
    now = int(time.time())

    if now < start_time:
        return 2
    elif now > end_time:
        return 3

    if not chatroom_enough:
        return 4

    return 1


def add_qrcode_log(owner):
    """Add a log."""
    new_log = CM('events_scan_qrcode_info')
    new_log.owner = owner
    new_log.scan_time = int(time.time())
    new_log.save()


def new_add_qrcode_log(event_id):
    """Add a log."""
    new_log = CM('events_scan_qrcode')
    new_log.event_id = event_id
    new_log.scan_time = int(time.time())
    new_log.save()


def inc_info(owner):
    """(today_inc,total_inc)"""
    logs = BaseModel.fetch_all('events_scan_qrcode_info', '*', BaseModel.where_dict({"owner": owner}))
    flag = int(time.time()) - 86400
    today_inc = 0
    all_inc = 0
    for i in logs:
        all_inc += 1
        if i.scan_time > flag:
            today_inc += 1

    return today_inc, all_inc


def new_inc_info(event_id):
    logs = BaseModel.fetch_all('events_scan_qrcode', '*', BaseModel.where_dict({"event_id": event_id}))
    flag = int(time.time()) - 86400
    today_inc = 0
    all_inc = 0
    for i in logs:
        all_inc += 1
        if i.scan_time > flag:
            today_inc += 1

    return today_inc, all_inc


def open_chatroom_name_protect():
    while True:
        time.sleep(100)
        event_list = BaseModel.fetch_all('events', '*')
        for i in event_list:
            if i.chatroom_name_protect:
                event_chatroom_list = BaseModel.fetch_all('events_chatroom', '*',
                                                          BaseModel.where_dict({'event_id': i.events_id}))
                for j in event_chatroom_list:
                    if j.chatroomname != 'default':
                        now_chatroom_info = BaseModel.fetch_one('a_chatroom', '*',
                                                                BaseModel.where_dict({'chatroomname': j.chatroomname}))
                        if now_chatroom_info.nickname_real != j.chatroom_nickname:
                            this_client_id = j.roomowner
                            _bot_username = BaseModel.fetch_one('client_bot_r', '*',
                                                                BaseModel.where_dict(
                                                                    {'client_id': this_client_id})).bot_username
                            result = {'bot_username': _bot_username,
                                      'data': {
                                          "task": "update_chatroom_nick",
                                          "chatroomname": j.chatroomname,
                                          "chatroomnick": j.chatroom_nickname,
                                      }}
                            requests.post('http://ardsvr.walibee.com/android/send_message', json=result)


def event_chatroom_send_word():
    # print('event_chatroom_send_word Running.')
    """
    chatroom_status_dict:{
            'chatroomname':()
    }
    """
    # Base status.
    chatroom_status_dict = dict()
    chatroom_task_status_dict = dict()
    event_list = BaseModel.fetch_all('events', '*',
                                     BaseModel.where_dict({'is_finish': 1, 'is_work': 1, 'enough_chatroom': 1}))
    for event in event_list:
        event_id = event.events_id
        # Get all chatroom in this event.
        chatroom_list = BaseModel.fetch_all('events_chatroom', '*', BaseModel.where_dict({'event_id': event_id}))
        for chatroom in chatroom_list:
            if chatroom.chatroomname == 'default':
                continue
            # Update status
            this_chatroom = BaseModel.fetch_one('a_chatroom', 'memberlist',
                                                BaseModel.where_dict({'chatroomname': chatroom.chatroomname}))

            if not this_chatroom:
                logger.warning('member_count ERROR!!! Can not find this_chatroom:%s' % chatroom.chatroomname)
                member_count = 0
            else:
                member_count = len(this_chatroom.memberlist.split(';'))

            chatroom_status_dict[chatroom.chatroomname] = member_count
            chatroom_task_status_dict[chatroom.chatroomname] = [0, 0, 0, 0]  # 30 50 80 100 task-status

    def send_message(_bot_username, to, _type, content):
        result = {'bot_username': _bot_username,
                  'data': {
                      "task": "send_message",
                      "to": to,
                      "type": _type,
                      "content": content,
                  }}
        resp = requests.post('http://ardsvr.walibee.com/android/send_message', json=result)
        if dict(resp.json())['err_code'] == -1:
            logger.warning('event_chatroom_send_word ERROR,because bot dead!')

    def get_owner_bot_username(roomowner):
        # Get roomowner's bot_username
        _client_id = roomowner
        client_bot_r = BaseModel.fetch_one('client_bot_r', '*', BaseModel.where_dict({'client_id': _client_id}))
        __bot_username = client_bot_r.bot_username

        return __bot_username

    def change_chatroom_notice(_bot_username, chatroomname, chatroomnotice):
        result = {'bot_username': _bot_username,
                  'data': {
                      "task": "update_chatroom_notice",
                      "chatroomname": chatroomname,
                      "chatroomnotice": chatroomnotice,
                  }}
        resp = requests.post('http://ardsvr.walibee.com/android/send_message', json=result)
        if dict(resp.json())['err_code'] == -1:
            logger.warning('event_chatroom_send_word ERROR,because bot dead!')

    while True:
        time.sleep(3)
        # Get all event.
        event_list = BaseModel.fetch_all('events', '*',
                                         BaseModel.where_dict({'is_finish': 1, 'is_work': 1, 'enough_chatroom': 1}))
        previous_chatroom_status_dict = chatroom_status_dict.copy()
        for event in event_list:
            event_id = event.events_id
            # Get all chatroom in this event.
            chatroom_list = BaseModel.fetch_all('events_chatroom', '*', BaseModel.where_dict({'event_id': event_id}))
            for chatroom in chatroom_list:
                if chatroom.chatroomname == 'default':
                    continue
                # Update status
                this_chatroom = BaseModel.fetch_one('a_chatroom', 'memberlist',
                                                    BaseModel.where_dict({'chatroomname': chatroom.chatroomname}))

                if not this_chatroom:
                    logger.warning('member_count ERROR!!! Can not find this_chatroom:%s' % chatroom.chatroomname)
                    member_count = 0
                else:
                    member_count = len(this_chatroom.memberlist.split(';'))

                chatroom_status_dict[chatroom.chatroomname] = member_count
                need_fission, need_condition_word, need_pull_people = event.need_fission, event.need_condition_word, event.need_pull_people
                # If previous chatroom list also have same chatroomname.
                if previous_chatroom_status_dict.get(chatroom.chatroomname):
                    previous_chatroom_member_count = previous_chatroom_status_dict[chatroom.chatroomname]
                    now_chatroom_member_count = chatroom_status_dict[chatroom.chatroomname]
                    # #print(previous_chatroom_member_count, now_chatroom_member_count)
                    if now_chatroom_member_count > previous_chatroom_member_count and need_fission:
                        # Send welcome message.
                        this_bot_username = get_owner_bot_username(event.owner)
                        send_message(this_bot_username, chatroom.chatroomname, 1, event.fission_word_1)
                        send_message(this_bot_username, chatroom.chatroomname, 1, event.fission_word_2)
                    if now_chatroom_member_count in (30, 50, 80) and need_pull_people:
                        # Change chatroomnotice.
                        for index, value in enumerate([30, 50, 80]):
                            if now_chatroom_member_count == value and not \
                                    chatroom_task_status_dict[chatroom.chatroomname][index]:
                                chatroom_task_status_dict[chatroom.chatroomname][index] = 1
                                # Do
                                this_bot_username = get_owner_bot_username(event.owner)
                                change_chatroom_notice(this_bot_username, chatroom.chatroomname, event.pull_people_word)

                    if now_chatroom_member_count == 100 and need_condition_word:
                        # Full people notice.
                        if not chatroom_task_status_dict[chatroom.chatroomname][3]:
                            chatroom_task_status_dict[chatroom.chatroomname][3] = 1
                            # Do
                            this_bot_username = get_owner_bot_username(event.owner)
                            send_message(this_bot_username, chatroom.chatroomname, 1, event.condition_word)


def put_img_to_oss(file_name, data_as_string):
    img_name = str(file_name) + '.jpg'

    endpoint = 'oss-cn-beijing.aliyuncs.com'
    auth = oss2.Auth('LTAIfwRTXLl6vMbX', 'kvSS9E4Ty7nvHHlGukaknJUtfICuen')
    bucket = oss2.Bucket(auth, endpoint, 'ywbdposter')
    bucket.put_object(img_name, base64.b64decode(data_as_string))

    return 'http://ywbdposter.oss-cn-beijing.aliyuncs.com/' + img_name


def events_chatroomname_check():
    while True:
        chatroom_list = BaseModel.fetch_all('events_chatroom', '*', BaseModel.where_dict({'chatroomname': 'default'}))
        for i in chatroom_list:
            rewrite_events_chatroom(i.roomowner, i.chatroom_nickname, i.event_id, True, False)
        time.sleep(300)


def put_qrcode_img_to_oss(event_id, app_id):
    """py3_bytes == py2_str"""

    def app_header_placeholder(_app_id):
        app_config = {
            'yaca': 'wx.walibee.com',
            'zidou': 'wx.zidouchat.com',
        }
        if ENV == 'DEV':
            return 'wx.ixuanren.com'
        if _app_id in app_config:
            return app_config[_app_id]
        else:
            raise Exception('app_header_placeholder Error!')

    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=1,
    )
    alive_qrcode_url = 'http://{}/chatroom.html?event_id={}'.format(app_header_placeholder(app_id), event_id)
    qr.add_data(alive_qrcode_url)
    qr.make()

    img = qr.make_image()
    img.save('temp.png')

    with open('temp.png', 'rb') as f:
        _data_as_bytes = f.read()

    img_name = str(event_id) + '_' + str(app_id) + '.png'

    endpoint = 'oss-cn-beijing.aliyuncs.com'
    auth = oss2.Auth('LTAIfwRTXLl6vMbX', 'kvSS9E4Ty7nvHHlGukaknJUtfICuen')
    bucket = oss2.Bucket(auth, endpoint, 'ywbdqrcode')
    bucket.put_object(img_name, _data_as_bytes)

    return 'http://ywbdqrcode.oss-cn-beijing.aliyuncs.com/' + img_name


def read_qrcode_img(qrcode_img_url):
    """Lilei require base64-encoding."""
    img_real = requests.get(qrcode_img_url).content
    return 'data:image/png;base64,' + base64.b64encode(img_real)


def event_chatroom_status_detect(is_activated, member_count):
    """
    0 -> Not activated.
    1 -> running.
    2 -> Finish.
    """
    if is_activated == 0:
        return 0

    if 0 <= member_count < 100:
        return 1

    return 2


@app_test.route('/_events_client', methods=['POST'])
@para_check('psw', 'username', 'app', 'available_chatroom')
def create_events_client():
    """Create a new client account, or add a previous client's available_chatroom and modify its remarks.
    app : yaca, zidou

    Return current client info.

    NOT USED NOW.
    """
    if request.json.get('psw') != '2beMeZyoWHLT6m':
        return ''
    username = request.json.get('username')
    app = request.json.get('app')

    client = BaseModel.fetch_one('client_member', '*', BaseModel.where_dict({'username': username, 'app': app}))
    if client is None:
        return 'Can not find this client'
    client_id = client.client_id

    previous_client = BaseModel.fetch_one('events_client', '*',
                                          BaseModel.where_dict({'client_id': client_id, 'is_work': 1}))

    if previous_client is None:
        # Create.
        new_client = CM('events_client')
        new_client.client_id = client_id
        new_client.create_time = int(time.time())
        new_client.update_time = int(time.time())
        new_client.available_chatroom = int(request.json.get('available_chatroom'))
        new_client.remark = request.json.get('remark') if request.json.get('remark') else ''
        new_client.is_work = 1
        success = new_client.save()
        return make_response(SUCCESS, data = new_client.to_json())
    else:
        # Modify.
        previous_client.available_chatroom = int(request.json.get('available_chatroom'))
        previous_client.update_time = int(time.time())
        if request.json.get('remark') is not None:
            previous_client.remark = request.json.get('remark')
        success = previous_client.save()
        return make_response(SUCCESS, data = previous_client.to_json())


@app_test.route('/_events_create', methods=['POST'])
@para_check('username', 'app', 'start_name', 'check', 'request_chatroom')
def create_events():
    """Create events.
    app : yaca, zidou
    """
    event_paras_required = ('client_id', 'start_name', 'event_title', 'create_time', 'poster_url', 'alive_qrcode_url')
    event_paras_int = (
        'chatroom_name_protect', 'chatroom_repeat_protect', 'need_fission',
        'need_pull_people', 'need_condition_word', 'is_work')
    event_paras_string = ('fission_word_1', 'fission_word_2', 'condition_word', 'pull_people_word')
    extra_paras = ('username', 'app', 'check', 'psw', 'request_chatroom')

    all_event_paras = dict()

    # Check paras.
    if request.json.get('psw') != '2beMeZyoWHLT6m':
        return ''
    for i in request.json:
        if i not in event_paras_required and i not in event_paras_int and i not in event_paras_string and i not in extra_paras:
            return make_response(ERR_INVALID_PARAMS, err_para = i)
        elif i in extra_paras:
            pass
        else:
            all_event_paras[i] = request.json.get(i)

    # Get client_id.
    username = get_real_username(request.json.get('username'))
    app = request.json.get('app')
    client = BaseModel.fetch_one('client_member', '*', BaseModel.where_dict({'username': username, 'app': app}))
    if client is None:
        return 'Can not find this client'
    client_id = client.client_id

    # Check same event.
    previous_event = BaseModel.fetch_one('events_', '*', BaseModel.where_dict(
        {'client_id': client_id, 'start_name': request.json.get('start_name')}))
    if previous_event is not None:
        return make_response(ERR_EXIST_EVENT, event = previous_event.to_json())

    # Set values.
    all_event_paras['client_id'] = client_id
    all_event_paras['start_name'] = request.json.get('start_name')
    all_event_paras['event_title'] = all_event_paras['start_name']
    all_event_paras['create_time'] = int(time.time())
    all_event_paras['poster_url'] = ''
    all_event_paras['alive_qrcode_url'] = ''

    all_event_paras['need_condition_word'] = request.json.get('need_condition_word') if request.json.get(
        'need_condition_word') is not None else 1
    all_event_paras['need_fission'] = request.json.get('need_fission') if request.json.get(
        'need_fission') is not None else 1
    all_event_paras['need_pull_people'] = request.json.get('need_pull_people') if request.json.get(
        'need_pull_people') is not None else 1

    for i in event_paras_int:
        all_event_paras.setdefault(i, 1)
    for i in event_paras_string:
        all_event_paras.setdefault(i, '')

    new_event = CM('events_')
    new_event.from_json(all_event_paras)

    # Check chatroom.
    try:
        available_chatroom = len(
            requests.post('%s/android/chatroom_pool' % ANDROID_SERVER_URL,
                          json={'client_id': client_id}).json()['data'])
    except Exception as e:
        return 'Error when request android server for check pool:%s' % e

    if request.json.get('request_chatroom') > available_chatroom:
        return 'Can not get enough chatroom for this client.Available:%s' % available_chatroom

    if request.json.get('check'):
        return make_response(SUCCESS, event = new_event.to_json(), available_chatroom = available_chatroom)

    # Save its alive_qrcode_url.
    success_status = dict()
    success_status['success_init'] = new_event.save()
    new_event.alive_qrcode_url = put_qrcode_img_to_oss(new_event.events__id, request.json.get('app'))
    success_status['success_qrcode_rewrite'] = new_event.save()

    if not success_status['success_init'] or not success_status['success_qrcode_rewrite']:
        return make_response(ERR_SEND_WS_TO_ANDROID, success_status = success_status)

    """Allot chatroom"""
    try:
        allot_chatroom_list = requests.post('%s/android/chatroom_allot' % ANDROID_SERVER_URL,
                                            json={'client_id': client_id,
                                                  'num': int(request.json.get('request_chatroom'))}).json()['data']
    except Exception as e:
        return 'Error when request android server for allot:%s' % e
    index = 1
    for chatroomname in allot_chatroom_list:
        new_event_chatroom = CM('events_chatroom_')
        new_event_chatroom.index = index
        new_event_chatroom.client_id = client_id
        new_event_chatroom.chatroomname = chatroomname
        new_event_chatroom.event_id = new_event.get_id()
        new_event_chatroom.start_name = new_event.start_name + str(index) + u'群'
        new_event_chatroom.update_time = int(time.time())
        new_event_chatroom.qrcode_update_time = int(0)
        new_event_chatroom.is_activated = 0
        if index == 1:
            new_event_chatroom.is_activated = 1
        success_status[chatroomname] = new_event_chatroom.save()
        index += 1
        new_thread_ = threading.Thread(target=new_event_init(chatroomname, new_event_chatroom.start_name, username,
                                                             new_event.chatroom_name_protect))
        new_thread_.setDaemon(True)
        new_thread_.start()
    new_event_info = new_event.to_json()
    new_event_info.update({'event_id': new_event.get_id()})
    # Init welcome word.
    new_thread__ = threading.Thread(target=add_init_fission_word(new_event.get_id(), ), )
    new_thread__.setDaemon(True)
    new_thread__.start()
    return make_response(SUCCESS, success_status = success_status, event = new_event_info)


@app_test.route('/events_list_v2', methods=['POST'])
@para_check('token', )
def _events_list():
    status, user_info = UserLogin.verify_token(request.json.get('token'))
    try:
        client_id = user_info.client_id
    except AttributeError:
        return make_response(ERR_USER_TOKEN)
    events = BaseModel.fetch_all('events_', '*', BaseModel.where_dict({"client_id": client_id}))
    event_list = []
    for event in events:
        temp = {}
        today_inc, all_inc = new_inc_info(event.get_id())
        # Get chatroom info.
        event_chatroom_list = BaseModel.fetch_all('events_chatroom_', '*',
                                                  BaseModel.where_dict({"event_id": event.get_id()}))
        total_inc = 0
        chatroom_total = len(event_chatroom_list)

        # Get all chatroom member_count.
        for event_chatroom in event_chatroom_list:
            if event_chatroom.is_activated:
                this_chatroom = BaseModel.fetch_one('a_chatroom', '*',
                                                    BaseModel.where_dict({'chatroomname': event_chatroom.chatroomname}))

                if this_chatroom:
                    if this_chatroom.memberlist:
                        total_inc += len(this_chatroom.memberlist.split(';'))
                else:
                    logger.warning('Can not find this chatroom:{}'.format(event_chatroom.chatroomname))

        temp.update({
            'event_id': event.get_id(),
            'poster_raw': event.poster_url,
            'event_title': event.event_title,
            'event_status': 1,
            'start_time': event.create_time,
            'end_time': None,
            # Need another table to search.
            'chatroom_total': chatroom_total,
            'today_inc': today_inc,
            'total_inc': total_inc,  # the people of all chatroom.
        })
        event_list.append(temp)
    event_list.reverse()

    return make_response(SUCCESS, event_list = event_list)


@app_test.route('/events_detail_v2', methods=['POST'])
@para_check('token', 'event_id')
def _events_detail():
    event_id = request.json.get('event_id')
    event = BaseModel.fetch_by_id('events_', event_id)
    if event is None:
        return make_response(ERR_NOT_EXIST_EVENT)
    content = {}
    content.update({'poster_raw': event.poster_url,
                    'event_title': event.event_title,
                    'alive_qrcode_url': read_qrcode_img(event.alive_qrcode_url),
                    'need_fission': event.need_fission,
                    'need_condition_word': event.need_condition_word,
                    'need_pull_people': event.need_pull_people,
                    'condition_word': event.condition_word,
                    'fission_word_1': event.fission_word_1,
                    'fission_word_2': event.fission_word_2,
                    'pull_people_word': event.pull_people_word,
                    'start_time': event.create_time,
                    'end_time': None,
                    # Add more
                    'chatroom_name_protect': event.chatroom_name_protect,
                    'chatroom_repeat_protect': event.chatroom_repeat_protect,
                    'start_index': 1,
                    'start_name': event.start_name,
                    })
    # Add chatroom info.
    content_chatrooms = []
    event_chatroom_list = BaseModel.fetch_all('events_chatroom_', '*',
                                              BaseModel.where_dict({'event_id': event.get_id()}))
    for event_chatroom in event_chatroom_list:
        this_chatroom = BaseModel.fetch_one('a_chatroom', '*',
                                            BaseModel.where_dict({'chatroomname': event_chatroom.chatroomname}))
        if this_chatroom is None:
            logger.warning('events_detail can not find %s' % event_chatroom.chatroomname)
            continue
        real_nickname = this_chatroom.nickname
        if real_nickname == '':
            real_nickname = this_chatroom.nickname_default
        this_chatroom_member_count = len(this_chatroom.memberlist.split(';'))
        _result = {'chatroom_avatar': this_chatroom.avatar_url, 'chatroom_name': real_nickname,
                   'chatroom_status': event_chatroom_status_detect(event_chatroom.is_activated,
                                                                   this_chatroom_member_count),
                   'chatroom_member_num': this_chatroom_member_count}
        content_chatrooms.append(_result)

    content['chatrooms'] = content_chatrooms
    content['event_status'] = 1

    content = _10_to_true_false(content, exc_list=['start_index', 'event_status'])

    return make_response(SUCCESS, info = content)


@app_test.route('/events_modify_v2', methods=['POST'])
@para_check('token', 'event_id', )
def _modify_event_word():
    # Check owner or return.
    status, user_info = UserLogin.verify_token(request.json.get('token'))
    try:
        client_id = user_info.client_id
    except AttributeError:
        return make_response(ERR_USER_TOKEN)
    # Check and get event.
    event_id = request.json.get('event_id')
    event = BaseModel.fetch_by_id('events_', event_id)
    if event is None:
        return make_response(ERR_NOT_EXIST_EVENT)

    if event.client_id != client_id:
        return make_response(ERR_WRONG_USER_ITEM)

    _paras_could_modified = (
        'need_fission', 'need_condition_word', 'need_pull_people', 'fission_word_1', 'fission_word_2',
        'condition_word', 'pull_people_word', 'chatroom_name_protect', 'poster_raw')

    para_as_dict = {}
    values_as_dict = dict(request.json)

    for k, v in values_as_dict.items():
        if k in _paras_could_modified:
            para_as_dict[k] = v

    para_as_dict = true_false_to_10(para_as_dict)

    # Save poster_raw
    poster_raw = para_as_dict.get('poster_raw')
    if poster_raw is not None:
        if 'http://ywbdposter.oss-cn-beijing.aliyuncs.com' not in poster_raw:
            try:
                poster_raw = poster_raw.replace('data:image/png;base64,', '')
                img_url = put_img_to_oss(event_id, poster_raw)
            except Exception as e:
                return make_response(ERR_PIC_BASE64)
            para_as_dict['poster_url'] = img_url
    else:
        # poster_raw is None.
        pass

    event.from_json(para_as_dict)
    event.update()

    return make_response(SUCCESS, event = event.to_json())


@app_test.route('/events_qrcode_v2', methods=['POST'])
@para_check('event_id', 'code', 'app_name')
def _get_events_qrcode():
    """Get event base info (for qrcode)."""
    event_id = request.json.get('event_id')
    chatroom_limit_1 = 100
    chatroom_limit_2 = 500
    # Handle.
    event = BaseModel.fetch_by_id('events_', event_id)
    if event is None:
        return make_response(ERR_NOT_EXIST_EVENT)
    client_id = event.client_id
    # Use event_id search chatroom list, then get a prepared chatroom
    # and return its chatroomname.
    # Add a scan qrcode log.
    new_add_qrcode_log(event_id)
    # Check which chatroom is available.
    chatroom_list = BaseModel.fetch_all('events_chatroom_', '*',
                                        BaseModel.where_dict({'event_id': event_id, 'is_activated': 1}))

    qrcodePostFix = "?_=" + str(int(time.time()))

    chatroom_dict = {}
    chatroomname_list = []
    for i in chatroom_list:
        chatroom_info = BaseModel.fetch_one('a_chatroom', '*', BaseModel.where_dict({'chatroomname': i.chatroomname}))
        if chatroom_info:
            nickname = chatroom_info.nickname_real
            if nickname == '':
                nickname = chatroom_info.nickname_default
            chatroom_dict[i.chatroomname] = (
                chatroom_info.memberlist.split(';'), chatroom_info.qrcode, nickname,
                chatroom_info.avatar_url,
                chatroom_info.update_time)
            chatroomname_list.append(i.chatroomname)

    if chatroom_dict:
        for k, v in chatroom_dict.items():
            if len(v[0]) < chatroom_limit_1:
                return make_response(SUCCESS, event_status = 1, chatroom_qr = v[1], chatroom_name = v[2], chatroom_avatar = v[3], qr_end_date = int(v[4]) + 604800)
    """Do not have a chatroom < 100, activate one."""
    chatroom_list = BaseModel.fetch_all('events_chatroom_', '*',
                                        BaseModel.where_dict({'event_id': event_id, 'is_activated': 0}))

    # client_all_bot_list = BaseModel.fetch_all('client_bot_r', '*', BaseModel.where_dict({'client_id': client_id}))
    # bot_username_list = [i.bot_username for i in client_all_bot_list]

    if len(chatroom_list) == 0:
        # Do not have chatroom, return the bot info to add chatroom.(100<people<500)
        if chatroom_dict:
            for k, v in chatroom_dict.items():
                if chatroom_limit_1 <= len(v[0]) < chatroom_limit_2:
                    chatroomname = k
                    psw = u'SL^lxz'
                    event_pull_word = u'&'.join([psw, chatroomname.split(u'@')[0][::-1]])
                    chatroom_pool_info = BaseModel.fetch_one('chatroom_pool', '*',
                                                             BaseModel.where_dict({'chatroomname': chatroomname}))
                    this_bot_username = chatroom_pool_info.bot_username
                    this_bot_info = BaseModel.fetch_one('a_contact', '*',
                                                        BaseModel.where_dict({'username': this_bot_username}))
                    bot_nickname = this_bot_info.nickname
                    return make_response(SUCCESS, event_status = 5, event_pull_word = event_pull_word, bot_qrcode = 'data:image/jpg;base64,' + _get_qr_code_base64_str(
                                            this_bot_username), bot_nickname = bot_nickname)
        return make_response(SUCCESS, event_status = 6, chatroom_qr = '', chatroom_name = '', chatroom_avatar = '', qr_end_date = '', 
                                event_pull_word = '', bot_qrcode = '', bot_nickname = '')
    else:
        # Activate one.
        index_list = []
        for i in chatroom_list:
            index_list.append(i.index)
        index_list.sort()
        now_index = index_list[0]

        # Activate this chatroom.
        for i in chatroom_list:
            if i.index == now_index:
                i.is_activated = 1
                i.save()
                this_chatroom_info = BaseModel.fetch_one('a_chatroom', '*',
                                                         BaseModel.where_dict({'chatroomname': i.chatroomname}))
                return make_response(SUCCESS, event_status = 1, chatroom_qr = this_chatroom_info.qrcode, chatroom_name = this_chatroom_info.nickname_real, 
                                        chatroom_avatar = this_chatroom_info.avatar_url, qr_end_date = this_chatroom_info.update_time)
        return '!!!!!!!!!!!'


@app_test.route('/events_edit_reply', methods=['POST'])
@para_check('token')
def events_edit_reply():
    global need_update_fission_word_rule
    global need_update_condition_word_rule
    need_update_fission_word_rule = True
    need_update_condition_word_rule = True
    rule_id = request.json.get('id')
    condition_num = request.json.get('condition_num')
    event_id = request.json.get('event_id')
    message_list = request.json.get('message_list')

    if rule_id is not None:
        # edit.
        previous_rule = BaseModel.fetch_by_id('events_send_word', rule_id)
        if previous_rule is None:
            return make_response(ERR_INVALID_PARAMS)

        if condition_num is not None:
            previous_rule.condition_num = condition_num
        if message_list not in (None, []):
            previous_rule.message_list = message_list

        flag = previous_rule.save()
        if not flag:
            return make_response(ERR_SEND_WS_TO_ANDROID)
        temp = previous_rule.to_json_full()
        temp['id'] = previous_rule.get_id()
        return make_response(SUCCESS, info  = temp)
    else:
        # create.
        if event_id is None or message_list in (None, []):
            return make_response(ERR_INVALID_PARAMS)

        new_word_rule = CM('events_send_word')
        new_word_rule.is_work = 1
        new_word_rule.is_deleted = 0
        if condition_num is None:
            # Add fission word.
            new_word_rule.condition_num = -1
            new_word_rule.type = 'fission'
            # Duplicate check.
            previous_fission_rule = BaseModel.fetch_one('events_send_word', '*',
                                                        BaseModel.where_dict(
                                                            {'type': 'fission', 'is_deleted': 0, 'event_id': event_id}))
            if previous_fission_rule is not None:
                return make_response(ERR_EXIST_FISSION_WORD)
        else:
            # Add condition word.
            new_word_rule.condition_num = condition_num
            new_word_rule.type = 'condition'
            # Get previous rule work status.
            previous_rule_list = BaseModel.fetch_all('events_send_word', '*', BaseModel.where_dict(
                {'type': 'condition', 'is_deleted': 0, 'event_id': event_id}))
            if len(previous_rule_list) == 0:
                pass  # is_work is True.
            else:
                new_word_rule.is_work = previous_rule_list[0].is_work

        new_word_rule.event_id = event_id
        new_word_rule.message_list = message_list
        flag = new_word_rule.save()
        if not flag:
            return make_response(ERR_SEND_WS_TO_ANDROID)
        temp = new_word_rule.to_json_full()
        temp['id'] = new_word_rule.get_id()
        return make_response(SUCCESS, info  = temp)


@app_test.route('/events_auto_word_list', methods=['POST'])
@para_check('token', 'event_id')
def events_auto_word_list():
    event_id = request.json.get('event_id')

    # event_id check.
    event = BaseModel.fetch_by_id('events_', event_id)
    if event is None:
        return make_response(ERR_INVALID_PARAMS)
    fission = {'is_work': False, 'rules': []}
    condition = {'is_work': False, 'rules': []}

    res = {'err_code': 0,
           'content': {'fission': {'is_work': False, 'rules': []}, 'condition': {'is_work': False, 'rules': []}}}

    event_rule_list = BaseModel.fetch_all('events_send_word', '*',
                                          BaseModel.where_dict({'event_id': event_id, 'is_deleted': 0}))

    for i in event_rule_list:
        temp = i.to_json_full()
        temp.pop('is_deleted')
        if temp.get('is_work') == 1:
            temp['is_work'] = True
        else:
            temp['is_work'] = False

        temp['id'] = temp['events_send_word_id']
        temp.pop('events_send_word_id')
        if temp.get('type') == 'fission':
            fission['is_work'] = temp['is_work']
            fission['rules'].append(temp)
        elif temp.get('type') == 'condition':
            condition['is_work'] = temp['is_work']
            condition['rules'].append(temp)
    # Condition word default is True.
    if len(condition['rules']) == 0:
        condition['is_work'] = True
    return make_response(SUCCESS, fission = fission, condition = condition)


@app_test.route('/events_delete_reply', methods=['POST'])
@para_check('token', 'id')
def events_delete_reply():
    def try_pop(_dict, key):
        try:
            _dict.pop(key)
        except KeyError:
            pass

    global need_update_fission_word_rule
    global need_update_condition_word_rule
    need_update_fission_word_rule = True

    rule_id = request.json.get('id')
    this_rule = BaseModel.fetch_by_id('events_send_word', rule_id)
    if this_rule is None:
        return make_response(ERR_INVALID_PARAMS)

    this_rule.is_deleted = 1
    flag = this_rule.save()
    if not flag:
        return make_response(ERR_SEND_WS_TO_ANDROID, info = this_rule.to_json_full())
    # pop rule_id in condition word dict.
    for k, v in condition_word_rule_as_dict.items():
        if v.get(rule_id) is not None:
            try_pop(v, rule_id)
    return make_response(SUCCESS, info = this_rule.to_json_full())


@app_test.route('/events_switch_reply', methods=['POST'])
@para_check('token', 'event_id', 'type', 'is_work')
def events_switch_reply():
    global need_update_fission_word_rule
    global need_update_condition_word_rule
    need_update_fission_word_rule = True
    need_update_condition_word_rule = True
    event_id = request.json.get('event_id')
    word_type = request.json.get('type')
    is_work = request.json.get('is_work')

    # event_id check.
    event = BaseModel.fetch_by_id('events_', event_id)
    if event is None:
        return make_response(ERR_INVALID_PARAMS)
    # is_work check.
    if is_work not in (True, False):
        return make_response(ERR_INVALID_PARAMS)
    if word_type not in ('fission', 'condition'):
        return make_response(ERR_INVALID_PARAMS)

    event_rule_list = BaseModel.fetch_all('events_send_word', '*',
                                          BaseModel.where_dict(
                                              {'event_id': event_id, 'type': word_type, 'is_deleted': 0}))

    for i in event_rule_list:
        i.is_work = 1 if is_work else 0
        flag = i.save()
        if not flag:
            return make_response(ERR_SEND_WS_TO_ANDROID)
    return make_response(SUCCESS)


@app_test.route('/events_test', methods=['POST'])
def test_api():
    try:
        # event_id = request.json.get('event_id')
        # new_thread__ = threading.Thread(target=add_init_fission_word(event_id, ), )
        # new_thread__.setDaemon(True)
        # new_thread__.start()
        event_list = BaseModel.fetch_all('events_', '*')
        for i in event_list:
            add_init_fission_word(i.get_id())
    except Exception as e:
        return '%s' % e
    return ' '


@app_test.route('/check_db', methods=['POST'])
@para_check('psw', 'table')
def check_db():
    if request.json.get('psw') != 'zvcasdkuagdgv214':
        return ' '
    try:
        page = request.json.get('page') if request.json.get('page') else 1
        pagesize = request.json.get('pagesize') if request.json.get('pagesize') else 100

        table = request.json.get('table')
        where = request.json.get('where') if request.json.get('where') else {}
        data = BaseModel.fetch_all(table, '*', BaseModel.where_dict(where), page=page, pagesize=pagesize)
        result = []
        for i in data:
            _temp = i.to_json_full()
            _temp.update({'_id': i.get_id()})
            result.append(_temp)
    except Exception as e:
        return '%s' % e
    return make_response(SUCCESS, data = result)


@app_test.route('/modify_db', methods=['POST'])
@para_check('psw', 'table', 'where', 'modify')
def modify_db():
    if request.json.get('psw') != 'zvcasdkuagdgv214':
        return ' '
    try:
        table = request.json.get('table')
        where = request.json.get('where') if request.json.get('where') else {}
        modify = request.json.get('modify') if request.json.get('modify') else {}
        data = BaseModel.fetch_one(table, '*', BaseModel.where_dict(where))
        data.from_json(modify)
        data.update()
        data_modified = BaseModel.fetch_one(table, '*', BaseModel.where_dict(where))
    except Exception as e:
        return '%s' % e
    return make_response(SUCCESS, data = data_modified.to_json_full())


def new_open_chatroom_status_protect():
    print('----- new_open_chatroom_status_protect')
    while True:
        try:
            event_list = BaseModel.fetch_all('events_', '*')
            for event in event_list:
                event_chatroom_list = BaseModel.fetch_all('events_chatroom_', '*',
                                                          BaseModel.where_dict({'event_id': event.get_id()}))
                owner_info = BaseModel.fetch_one('client_member', '*',
                                                 BaseModel.where_dict({'client_id': event.client_id}))
                owner_username = owner_info.username
                if not owner_username:
                    continue
                for this_chatroom in event_chatroom_list:
                    flag = False
                    # print('---- handle ', this_chatroom.chatroomname)
                    now_chatroom_info = BaseModel.fetch_one('a_chatroom', '*',
                                                            BaseModel.where_dict(
                                                                {'chatroomname': this_chatroom.chatroomname}))

                    this_chatroom_info = BaseModel.fetch_one('chatroom_pool', '*',
                                                             BaseModel.where_dict(
                                                                 {'chatroomname': this_chatroom.chatroomname}))
                    if this_chatroom_info is None:
                        continue
                    _bot_username = this_chatroom_info.bot_username

                    # Name protect.
                    real_name = this_chatroom.start_name
                    if event.chatroom_name_protect and now_chatroom_info.nickname_real != real_name:
                        print('----- name protect')
                        flag = True
                        result = {'bot_username': _bot_username,
                                  'data': {
                                      "task": "update_chatroom_nick",
                                      "chatroomname": this_chatroom.chatroomname,
                                      "chatroomnick": real_name,
                                  }}
                        requests.post('%s/android/send_message' % ANDROID_SERVER_URL, json=result)
                    # Update qrcode.
                    now_qrcode = now_chatroom_info.to_json().get('qrcode')
                    # print(now_qrcode)
                    qrcode_update_time = this_chatroom.to_json().get(
                        'qrcode_update_time') if this_chatroom.to_json().get('qrcode_update_time') else 0
                    if now_qrcode is None or int(time.time()) > qrcode_update_time + 86400:
                        flag = True
                        result = {'bot_username': _bot_username,
                                  'data': {
                                      "task": "update_chatroom_qrcode",
                                      "chatroomname": this_chatroom.chatroomname,
                                  }}
                        requests.post('%s/android/send_message' % ANDROID_SERVER_URL, json=result)
                        this_chatroom.qrcode_update_time = int(time.time())
                        this_chatroom.save()
                    # Pull owner to this chatroom.
                    member_list = now_chatroom_info.memberlist.split(';')
                    if owner_username not in member_list:
                        # print('----- pull owner')
                        if owner_username == 'wxid_v8f5swjgksqf21':
                            continue
                        flag = True
                        result = {'bot_username': _bot_username,
                                  'data': {
                                      "task": "add_contact_to_chatroom",
                                      "chatroomname": this_chatroom.chatroomname,
                                      "contacts": owner_username
                                  }}
                        requests.post('%s/android/send_message' % ANDROID_SERVER_URL, json=result)
                    if flag:
                        # Update chatroom info.
                        result = {'bot_username': _bot_username,
                                  'data': {
                                      "task": "update_chatroom",
                                      "chatroomname": this_chatroom.chatroomname,
                                  }}
                        requests.post('%s/android/send_message' % ANDROID_SERVER_URL, json=result)
        except Exception as e:
            print('new_open_chatroom_name_protect', e)
        time.sleep(30)


def new_event_chatroom_send_word():
    # print('event_chatroom_send_word Running.')
    """
    chatroom_status_dict:{
            'chatroomname':()
    }
    """
    # Base status.
    chatroom_status_dict = dict()
    chatroom_task_status_dict = dict()
    event_list = BaseModel.fetch_all('events_', '*', BaseModel.where_dict({'is_work': 1}))
    for event in event_list:
        event_id = event.get_id()
        # Get all chatroom in this event.
        chatroom_list = BaseModel.fetch_all('events_chatroom_', '*', BaseModel.where_dict({'event_id': event_id}))
        for chatroom in chatroom_list:
            # Update status
            this_chatroom = BaseModel.fetch_one('a_chatroom', 'memberlist',
                                                BaseModel.where_dict({'chatroomname': chatroom.chatroomname}))

            if not this_chatroom:
                logger.warning('member_count ERROR!!! Can not find this_chatroom:%s' % chatroom.chatroomname)
                member_count = 0
            else:
                member_count = len(this_chatroom.memberlist.split(';'))

            chatroom_status_dict[chatroom.chatroomname] = member_count
            chatroom_task_status_dict[chatroom.chatroomname] = [0, 0, 0, 0]  # 30 50 80 100 task-status

    def send_message(_bot_username, to, _type, content):
        result = {'bot_username': _bot_username,
                  'data': {
                      "task": "send_message",
                      "to": to,
                      "type": _type,
                      "content": content,
                  }}
        resp = requests.post('%s/android/send_message' % ANDROID_SERVER_URL, json=result)
        if dict(resp.json())['err_code'] == -1:
            logger.warning('event_chatroom_send_word ERROR,because bot dead!')

    def send_img(_bot_username, to, source_url):
        result = {'bot_username': _bot_username,
                  'data': {
                      "task": "send_message",
                      "to": to,
                      "type": 2,
                      "source_url": source_url,
                      "title": source_url.split('/')[-1]
                  }}
        resp = requests.post('%s/android/send_message' % ANDROID_SERVER_URL, json=result)
        if dict(resp.json())['err_code'] == -1:
            logger.warning('event_chatroom_send_word ERROR,because bot dead!')

    def get_owner_bot_username(__chatroomname):
        # Get roomowner's bot_username
        this_chatroom_bot = BaseModel.fetch_one('chatroom_pool', '*',
                                                BaseModel.where_dict({'chatroomname': __chatroomname}))
        __bot_username = this_chatroom_bot.bot_username

        return __bot_username

    def change_chatroom_notice(_bot_username, chatroomname, chatroomnotice):
        result = {'bot_username': _bot_username,
                  'data': {
                      "task": "update_chatroom_notice",
                      "chatroomname": chatroomname,
                      "chatroomnotice": chatroomnotice,
                  }}
        resp = requests.post('%s/android/send_message' % ANDROID_SERVER_URL, json=result)
        if dict(resp.json())['err_code'] == -1:
            logger.warning('event_chatroom_send_word ERROR,because bot dead!')

    while True:
        try:
            # print('-----running')
            # Get all event.
            event_list = BaseModel.fetch_all('events_', '*',
                                             BaseModel.where_dict({'is_work': 1}))
            previous_chatroom_status_dict = chatroom_status_dict.copy()
            for event in event_list:
                event_id = event.get_id()
                # Get all chatroom in this event.
                chatroom_list = BaseModel.fetch_all('events_chatroom_', '*',
                                                    BaseModel.where_dict({'event_id': event_id}))
                for chatroom in chatroom_list:
                    # Update status
                    this_chatroom = BaseModel.fetch_one('a_chatroom', 'memberlist',
                                                        BaseModel.where_dict({'chatroomname': chatroom.chatroomname}))

                    if not this_chatroom:
                        logger.warning('member_count ERROR!!! Can not find this_chatroom:%s' % chatroom.chatroomname)
                        member_count = 0
                    else:
                        member_count = len(this_chatroom.memberlist.split(';'))

                    chatroom_status_dict[chatroom.chatroomname] = member_count
                    need_fission, need_condition_word, need_pull_people = event.need_fission, event.need_condition_word, event.need_pull_people
                    # If previous chatroom list also have same chatroomname.
                    if previous_chatroom_status_dict.get(chatroom.chatroomname):
                        previous_chatroom_member_count = previous_chatroom_status_dict[chatroom.chatroomname]
                        now_chatroom_member_count = chatroom_status_dict[chatroom.chatroomname]
                        # #print(previous_chatroom_member_count, now_chatroom_member_count)
                        if now_chatroom_member_count > previous_chatroom_member_count and need_fission:
                            # Send welcome message.
                            this_bot_username = get_owner_bot_username(chatroom.chatroomname)
                            # print('----send:', this_bot_username, chatroom.chatroomname, 1, event.fission_word_1)
                            send_message(this_bot_username, chatroom.chatroomname, 1, event.fission_word_1)
                            send_message(this_bot_username, chatroom.chatroomname, 1, event.fission_word_2)
                            if event.poster_url != "":
                                send_img(this_bot_username, chatroom.chatroomname, event.poster_url)
                        if now_chatroom_member_count in (30, 50, 80) and need_pull_people:
                            # Change chatroomnotice.
                            for index, value in enumerate([30, 50, 80]):  # TRY
                                # print('----send:358-0')
                                if now_chatroom_member_count == value and not \
                                        chatroom_task_status_dict[chatroom.chatroomname][index]:
                                    chatroom_task_status_dict[chatroom.chatroomname][index] = 1
                                    # Do
                                    this_bot_username = get_owner_bot_username(chatroom.chatroomname)
                                    # print('----send:358-1')
                                    change_chatroom_notice(this_bot_username, chatroom.chatroomname,
                                                           event.pull_people_word)

                        if now_chatroom_member_count == 100 and need_condition_word:  # TRY
                            # Full people notice.
                            # print('----send:100-0')
                            if not chatroom_task_status_dict[chatroom.chatroomname][3]:
                                chatroom_task_status_dict[chatroom.chatroomname][3] = 1
                                # Do
                                this_bot_username = get_owner_bot_username(chatroom.chatroomname)
                                # print('----send:100-1')
                                send_message(this_bot_username, chatroom.chatroomname, 1, event.condition_word)
        except Exception as e:
            print('new_event_chatroom_send_word', e)
        time.sleep(15)


def new_event_init(chatroomname, start_name, owner_username, chatroom_name_protect):
    """
    1.Modify its chatroomname.
    2.Pull owner to this chatroom.
    3.Update chatroom qrcode.
    4.Update chatroom info.
    """
    now_chatroom_info = BaseModel.fetch_one('a_chatroom', '*',
                                            BaseModel.where_dict({'chatroomname': chatroomname}))
    this_chatroom_info = BaseModel.fetch_one('chatroom_pool', '*',
                                             BaseModel.where_dict(
                                                 {'chatroomname': chatroomname}))
    _bot_username = this_chatroom_info.bot_username
    if now_chatroom_info.nickname_real != start_name and chatroom_name_protect:
        result = {'bot_username': _bot_username,
                  'data': {
                      "task": "update_chatroom_nick",
                      "chatroomname": chatroomname,
                      "chatroomnick": start_name,
                  }}
        requests.post('%s/android/send_message' % ANDROID_SERVER_URL, json=result)
    member_list = now_chatroom_info.memberlist.split(';')
    if owner_username not in member_list:
        result = {'bot_username': _bot_username,
                  'data': {
                      "task": "add_contact_to_chatroom",
                      "chatroomname": chatroomname,
                      "contacts": owner_username
                  }}
        requests.post('%s/android/send_message' % ANDROID_SERVER_URL, json=result)
    # Update chatroom qrcode.
    result = {'bot_username': _bot_username,
              'data': {
                  "task": "update_chatroom_qrcode",
                  "chatroomname": chatroomname,
              }}
    requests.post('%s/android/send_message' % ANDROID_SERVER_URL, json=result)

    # Update chatroom info.
    result = {'bot_username': _bot_username,
              'data': {
                  "task": "update_chatroom",
                  "chatroomname": chatroomname,
              }}
    requests.post('%s/android/send_message' % ANDROID_SERVER_URL, json=result)


def new_event_chatroom_send_word_v2():
    """
    chatroom_status_dict:{
            'chatroomname':()
    }
    """
    # Base status.
    global need_update_fission_word_rule
    global need_update_condition_word_rule
    global fission_word_rule_as_dict
    global condition_word_rule_as_dict

    chatroom_status_dict = dict()

    event_list = BaseModel.fetch_all('events_', '*', BaseModel.where_dict({'is_work': 1}))

    for event in event_list:
        event_id = event.get_id()
        # Get all chatroom in this event.
        chatroom_list = BaseModel.fetch_all('events_chatroom_', '*', BaseModel.where_dict({'event_id': event_id}))
        for chatroom in chatroom_list:
            # Update status
            this_chatroom = BaseModel.fetch_one('a_chatroom', 'memberlist',
                                                BaseModel.where_dict({'chatroomname': chatroom.chatroomname}))

            if not this_chatroom:
                logger.warning('member_count ERROR!!! Can not find this_chatroom:%s' % chatroom.chatroomname)
                member_count = 0
            else:
                member_count = len(this_chatroom.memberlist.split(';'))

            chatroom_status_dict[chatroom.chatroomname] = member_count

    def get_owner_bot_username(_client_id, _member_list):
        bot_username_list = []
        cbr = BaseModel.fetch_all('client_bot_r', '*', BaseModel.where_dict({'client_id': _client_id}))
        for i in cbr:
            temp = i.to_json_full()
            if temp.get('bot_username'):
                bot_username_list.append(temp.get('bot_username'))
        x = set(_member_list)
        y = set(bot_username_list)

        res = tuple(x & y)
        if len(res) >= 1:
            return res[0]
        else:
            return False

    def update_fission_word_rule():
        print('update_fission_word_rule')
        global fission_word_rule_as_dict
        fission_word_rule_as_dict = {}
        all_fission_word_list = BaseModel.fetch_all('events_send_word', '*',
                                                    BaseModel.where_dict(
                                                        {'type': 'fission', 'is_deleted': 0, 'is_work': 1}))
        for i in all_fission_word_list:
            temp = i.to_json_full()
            event_id = temp.get('event_id')
            message_list = temp.get('message_list')
            event_chatroom_list = BaseModel.fetch_all('events_chatroom_', '*',
                                                      BaseModel.where_dict({'event_id': event_id}))
            for j in event_chatroom_list:
                fission_word_rule_as_dict[j.chatroomname] = message_list
        # print(fission_word_rule_as_dict)

    def update_condition_word_rule():
        print('update_condition_word_rule running')
        global condition_word_rule_as_dict
        all_condition_word_list = BaseModel.fetch_all('events_send_word', '*',
                                                      BaseModel.where_dict({'type': 'condition', 'is_deleted': 0}))
        for i in all_condition_word_list:
            _event_id = i.event_id
            event_chatroom_list = BaseModel.fetch_all('events_chatroom_', '*',
                                                      BaseModel.where_dict({'event_id': _event_id}))
            if len(event_chatroom_list) == 0:
                continue
            rule_id = i.get_id()
            _is_work = i.is_work
            condition_num = i.condition_num
            message_list = i.message_list

            for j in event_chatroom_list:
                if condition_word_rule_as_dict.get(j.chatroomname) is None:
                    # Create chatroomname as key.
                    condition_word_rule_as_dict[j.chatroomname] = {}
                    condition_word_rule_as_dict[j.chatroomname][rule_id] = [0, _is_work, condition_num, message_list]
                else:
                    # Append or sync rule.
                    if condition_word_rule_as_dict[j.chatroomname].get(rule_id) is None:
                        # Add extra rule.
                        condition_word_rule_as_dict[j.chatroomname][rule_id] = [0, _is_work, condition_num,
                                                                                message_list]
                    else:
                        # Sync rule.
                        t1, t2, t3 = condition_word_rule_as_dict[j.chatroomname][rule_id][1:]

                        if (t1, t2, t3) != (_is_work, condition_num, message_list):
                            condition_word_rule_as_dict[j.chatroomname][rule_id][0] = 0

                        condition_word_rule_as_dict[j.chatroomname][rule_id][1:] = _is_work, condition_num, message_list

        # print(condition_word_rule_as_dict)

    def send_message_list(_bot_username, chatroomname_list, message_list):
        print("send_message_list running")
        real_message_list = []
        data = {'bot_username': _bot_username, 'to_list': chatroomname_list}
        for index, message in enumerate(message_list):
            message_dict = dict()
            message_dict["type"] = message.get("real_type")
            message_dict["content"] = message.get("text")
            message_dict["source_url"] = message.get("source_url")
            message_dict["thumb_url"] = message.get("thumb_url")
            message_dict["title"] = message.get("title")
            message_dict["desc"] = message.get("desc")
            message_dict["size"] = message.get("size")
            message_dict["duration"] = message.get("duration")
            message_dict["msg_id"] = message.get("msg_id")
            message_dict["msg_local_id"] = message.get("msg_local_id")
            message_dict["msg_svr_id"] = message.get("msg_svr_id")
            message_dict["talker"] = message.get("talker")
            message_dict["create_time"] = message.get("create_time")
            message_dict["seq"] = index
            real_message_list.append(message_dict)
        data['message_list'] = real_message_list
        # print(data)
        resp = requests.post(url=ANDROID_SERVER_URL_SEND_MASS_MESSAGE, json=data)
        # print(resp.text)

    while True:
        try:
            # print('-----running')
            if need_update_fission_word_rule:
                update_fission_word_rule()
                need_update_fission_word_rule = False
            if need_update_condition_word_rule:
                update_condition_word_rule()
                need_update_condition_word_rule = False
            # Get all event.
            event_list = BaseModel.fetch_all('events_', '*',
                                             BaseModel.where_dict({'is_work': 1}))
            previous_chatroom_status_dict = chatroom_status_dict.copy()
            for event in event_list:
                event_id = event.get_id()
                _client_id = event.client_id
                # Get all chatroom in this event.
                chatroom_list = BaseModel.fetch_all('events_chatroom_', '*',
                                                    BaseModel.where_dict({'event_id': event_id}))
                for chatroom in chatroom_list:
                    # Update status
                    this_chatroom = BaseModel.fetch_one('a_chatroom', 'memberlist',
                                                        BaseModel.where_dict({'chatroomname': chatroom.chatroomname}))

                    if not this_chatroom:
                        logger.warning('member_count ERROR!!! Can not find this_chatroom:%s' % chatroom.chatroomname)
                        member_count = 0
                        member_list = []
                    else:
                        member_list = this_chatroom.memberlist.split(';')
                        member_count = len(member_list)

                    chatroom_status_dict[chatroom.chatroomname] = member_count
                    # If previous chatroom list also have same chatroomname.
                    if previous_chatroom_status_dict.get(chatroom.chatroomname):
                        previous_chatroom_member_count = previous_chatroom_status_dict[chatroom.chatroomname]
                        now_chatroom_member_count = chatroom_status_dict[chatroom.chatroomname]
                        # print(previous_chatroom_member_count, now_chatroom_member_count)
                        if now_chatroom_member_count > previous_chatroom_member_count:
                            print('Send welcome message.')
                            # Send welcome message.
                            if member_list == []:
                                continue
                            this_bot_username = get_owner_bot_username(_client_id, member_list)
                            if not this_bot_username:
                                continue
                            if chatroom.chatroomname in fission_word_rule_as_dict.keys():
                                now_time = int(time.time())
                                welcome_flag = False
                                recent_reply_info = BaseModel.fetch_one(RecentReply, '*', where_clause=BaseModel.where_dict({'talker': chatroom.chatroomname, 
                                                                        'real_talker': this_bot_username, 'welcome': 'true'}))
                                if recent_reply_info:
                                    if recent_reply_info.create_time + DEFAULT_WELCOME_TIME_LIMIT < now_time:
                                        recent_reply_info.create_time = now_time
                                        welcome_flag = True
                                    else:
                                        recent_reply_info.update_time = now_time
                                        recent_reply_info.update()
                                else:
                                    recent_reply_info = CM(RecentReply)
                                    recent_reply_info.create_time = now_time
                                    recent_reply_info.update_time = now_time
                                    recent_reply_info.talker = chatroom.chatroomname
                                    recent_reply_info.real_talker = this_bot_username
                                    recent_reply_info.welcome = 'true'
                                    recent_reply_info.save()
                                if welcome_flag:
                                    send_message_list(this_bot_username, [chatroom.chatroomname],
                                                  fission_word_rule_as_dict[chatroom.chatroomname])
                        if chatroom.chatroomname in condition_word_rule_as_dict.keys():
                            rule_as_dict = condition_word_rule_as_dict[chatroom.chatroomname]
                            for k, v in rule_as_dict.items():
                                _is_send, _is_work, _condition_num, _message_list = v
                                if not _is_send and _is_work and _condition_num == now_chatroom_member_count:
                                    this_bot_username = get_owner_bot_username(_client_id, member_list)
                                    if not this_bot_username:
                                        continue
                                    send_message_list(this_bot_username, [chatroom.chatroomname], _message_list)
                                    v[0] = 1
        except Exception as e:
            print('new_event_chatroom_send_word exception:', e)
        time.sleep(15)


def add_init_fission_word(_event_id):
    print('add_init_fission_word running')
    previous_rule = BaseModel.fetch_one('events_send_word', '*',
                                        BaseModel.where_dict(
                                            {'event_id': _event_id, 'type': 'fission', 'is_deleted': 0}))
    if previous_rule is not None:
        return 0
    new_rule = CM('events_send_word')
    new_rule.is_deleted = 0
    new_rule.is_work = 0
    new_rule.condition_num = -1
    new_rule.event_id = _event_id
    new_rule.type = 'fission'
    new_rule.message_list = [
        {"create_time": None,
         "desc": None,
         "duration": None,
         "msg_id": None,
         "msg_svr_id": None,
         "msg_local_id": None,
         "real_type": 1,
         "seq": 0,
         "size": None,
         "source_url": None,
         "talker": None,
         "text": "欢迎你加入我们的群聊~",
         "thumb_url": None,
         "title": None}]
    flag = new_rule.save()
    print('add_init_fission_word save:', flag)


def check_bot_status_for_alert():
    bot_status_dict = {}
    pass


new_event_chatroom_send_word_thread = threading.Thread(target=new_event_chatroom_send_word)
new_event_chatroom_send_word_thread.setDaemon(True)

new_event_chatroom_send_word_thread_v2 = threading.Thread(target=new_event_chatroom_send_word_v2)
new_event_chatroom_send_word_thread_v2.setDaemon(True)

new_open_chatroom_status_protect_thread = threading.Thread(target=new_open_chatroom_status_protect)
new_open_chatroom_status_protect_thread.setDaemon(True)
