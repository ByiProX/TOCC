# -*- coding: utf-8 -*-
__author__ = "Quentin"

import logging
from flask import request
from models_v2.base_model import BaseModel, CM
from configs.config import SUCCESS, ERR_WRONG_ITEM, main_api_v2
from core_v2.user_core import UserLogin
from utils.u_model_json_str import verify_json
from utils.u_response import make_response
import time
import copy

logger = logging.getLogger('main')


@main_api_v2.route('/modify_qun_keyword_rule', methods=['POST'])
def api_modify_qun_keyword_rule():
    verify_json()
    status, user_info = UserLogin.verify_token(request.json.get('token'))
    if status != SUCCESS:
        return make_response(status)

    client_id = user_info.client_id

    keyword = request.json.get('keyword')
    # switch = False
    # if switch:
    #     keyword_split_list = keyword.strip().split("@")
    #     if len(keyword_split_list) != 2 or keyword_split_list[0].isdigit() is False:
    #         logger.info("关键词格式错误")
    #         return make_response(ERR_WRONG_ITEM)

    chatroomname_list = request.json.get('chatroomname_list')
    if not isinstance(chatroomname_list, list):
        return make_response(ERR_WRONG_ITEM)

    chatroom_info_list = list()
    for chatroom in chatroomname_list:
        a_chatroom = BaseModel.fetch_one("a_chatroom", "*",
                                         where_clause=BaseModel.and_(
                                             ["=", "chatroomname", chatroom]),
                                         order_by=BaseModel.order_by({"create_time": "desc"})
                                         )

        chatroom_basic_info = dict()
        chatroom_basic_info["chatroom_name"] = a_chatroom.chatroomname
        chatroom_basic_info["nickname"] = a_chatroom.nickname_real if a_chatroom.nickname_real else a_chatroom.nickname_default
        chatroom_basic_info["avatar_url"] = a_chatroom.avatar_url
        chatroom_basic_info["chatroom_member_count"] = a_chatroom.member_count

        print ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
        print chatroom_basic_info
        chatroom_info_list.append(chatroom_basic_info)

    _id = request.json.get('id', 0)
    if not _id:
        client_qun_keyword = BaseModel.fetch_one("client_qun_keyword", "*",
                                                 where_clause=BaseModel.and_(
                                                     ["=", "client_id", client_id]
                                                 ))
        if not client_qun_keyword.qun_keyword_list:
            client_qun_keyword.qun_keyword_list = list()

        if not client_qun_keyword:
            client_qun_keyword = CM("client_qun_keyword")
            client_qun_keyword.client_id = client_id
            client_qun_keyword.qun_keyword_list = list()

        rule_dict = dict()
        # 如果有id,代表进行修改，否则新建
        rule_dict["id"] = int(time.time())
        rule_dict["keyword"] = keyword
        rule_dict["chatroom_list"] = chatroom_info_list

        print ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
        print rule_dict

        client_qun_keyword.qun_keyword_list.append(rule_dict)
        client_qun_keyword.save()

    else:
        client_qun_keyword = BaseModel.fetch_one("client_qun_keyword", "*",
                                                 where_clause=BaseModel.and_(
                                                     ["=", "client_id", client_id]
                                                 ))
        if not client_qun_keyword:
            return make_response(ERR_WRONG_ITEM)

        qun_keyword_list = client_qun_keyword.qun_keyword_list
        if not qun_keyword_list:
            return make_response(ERR_WRONG_ITEM)

        for qun_keyword in qun_keyword_list:
            if qun_keyword.get("id") == _id:
                qun_keyword["keyword"] = keyword
                qun_keyword["chatroom_list"] = chatroom_info_list
                break

        client_qun_keyword.save()

    return make_response(SUCCESS)


@main_api_v2.route('/get_qun_keyword_rule', methods=['POST'])
def api_get_qun_keyword_rule():
    verify_json()
    status, user_info = UserLogin.verify_token(request.json.get('token'))
    if status != SUCCESS:
        return make_response(status)

    client_id = user_info.client_id

    client_qun_keyword = BaseModel.fetch_one("client_qun_keyword", "*",
                                             where_clause=BaseModel.and_(
                                                 ["=", "client_id", client_id]
                                             ))

    if not client_qun_keyword:
        client_qun_keyword = CM("client_qun_keyword")
        client_qun_keyword.client_id = client_id
        client_qun_keyword.qun_keyword_list = list()
        client_qun_keyword.save()

    return make_response(SUCCESS, qun_keyword_list=client_qun_keyword.qun_keyword_list)
    # return make_response(SUCCESS, client_qun_keyword.qun_keyword_list)


@main_api_v2.route('/del_qun_keyword_rule', methods=['POST'])
def api_del_qun_keyword_rule():
    verify_json()
    status, user_info = UserLogin.verify_token(request.json.get('token'))
    if status != SUCCESS:
        return make_response(status)

    client_id = user_info.client_id

    _id = request.json.get('id', 0)
    if not _id:
        return make_response(ERR_WRONG_ITEM)

    client_qun_keyword = BaseModel.fetch_one("client_qun_keyword", "*",
                                             where_clause=BaseModel.and_(
                                                 ["=", "client_id", client_id]
                                             ))
    if not client_qun_keyword:
        return make_response(ERR_WRONG_ITEM)

    qun_keyword_list = client_qun_keyword.qun_keyword_list

    new_qun_keyword_list = copy.deepcopy(qun_keyword_list)
    for qun_keyword in qun_keyword_list:
        if qun_keyword.get("id") == _id:
            del new_qun_keyword_list[new_qun_keyword_list.index(qun_keyword)]

    client_qun_keyword.qun_keyword_list = new_qun_keyword_list

    client_qun_keyword.save()

    return make_response(SUCCESS)












