# -*- coding: utf-8 -*-

from configs.config import main_api_v2
from utils.tag_handle import Tag
from utils.z_utils import *


@main_api_v2.route('/_func_init', methods=["GET"])
def test():
    all_client_list = BaseModel.fetch_all('client_member', '*', BaseModel.where_dict({'func_switch': None}))
    res = {'data': []}
    for client in all_client_list:
        client.func_switch = Tag().load_config(client.app).as_int()
        client.save()
        res['data'].append(client.to_json_full())

    return response(res)
