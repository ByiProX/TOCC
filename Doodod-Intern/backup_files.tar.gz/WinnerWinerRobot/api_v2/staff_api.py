# -*- coding: utf-8 -*-
import time

from configs.config import *
from core_v2.user_core import UserLogin
from utils.tag_handle import Tag
from utils.u_model_json_str import verify_json
from utils.u_response import make_response
from utils.z_utils import *

logger = logging.getLogger('main')


@main_api_v2.route('/set_staff_rule', methods=["POST"])
@para_check('token')
def set_staff_rule():
    """By ZYunH."""
    token = request.json.get('token')
    nickname = request.json.get('nickname')
    modules = request.json.get('modules')

    # Optional parameter.
    rule_id = request.json.get('id')

    # Parameters check.
    # 1.token
    client_member_info = BaseModel.fetch_one('client_member', '*', BaseModel.where_dict({'token': token}))
    if client_member_info is None:
        return make_response(err.ERR_INVALID_PARAMS)
    manager_open_id = client_member_info.open_id
    if manager_open_id is None:
        return make_response(err.ERR_DB_MISS)

    if rule_id is not None:
        # Modify rule.
        previous_rule = BaseModel.fetch_by_id('staff_rule', rule_id)
        if previous_rule is None:
            return make_response(err.ERR_INVALID_PARAMS)
        if nickname is not None:
            previous_rule.nickname = nickname
        if isinstance(modules, list) and modules != []:
            previous_rule.modules = modules
        flag = previous_rule.save()
        if flag is False:
            return make_response(err.ERR_SEND_WS_TO_ANDROID)
        # Get id.
        temp = previous_rule.to_json_full()
        temp['id'] = previous_rule.get_id()
        return make_response(SUCCESS, info = temp)
    else:
        # Create rule.
        if not isinstance(modules, list) or not isinstance(nickname, unicode) or modules == []:
            return make_response(err.ERR_INVALID_PARAMS)
        new_rule = CM('staff_rule')
        new_rule.manager_open_id = manager_open_id
        new_rule.nickname = nickname
        new_rule.modules = modules
        new_rule.is_deleted = 0
        flag = new_rule.save()
        if flag is False:
            return make_response(err.ERR_SEND_WS_TO_ANDROID)
        # Get id.
        temp = new_rule.to_json_full()
        temp['id'] = new_rule.get_id()
        return make_response(SUCCESS, info = temp)


@main_api_v2.route('/get_staff_rule_list', methods=["POST"])
@para_check('token', 'page', 'pagesize')
def get_staff_rule_list():
    """By ZYunH."""
    token = request.json.get('token')
    page = request.json.get('page')
    pagesize = request.json.get('pagesize')

    # Parameters check.
    # 1.token
    client_member_info = BaseModel.fetch_one('client_member', '*', BaseModel.where_dict({'token': token}))
    if client_member_info is None:
        return make_response(err.ERR_INVALID_PARAMS)
    manager_open_id = client_member_info.open_id
    if manager_open_id is None:
        return make_response(err.ERR_DB_MISS)
    # 2. page & pagesize.
    if not isinstance(page, int) or not isinstance(pagesize, int):
        return make_response(err.ERR_INVALID_PARAMS)

    # Work.
    staff_rule_list_all = BaseModel.fetch_all('staff_rule', '*',
                                              BaseModel.where_dict(
                                                  {'manager_open_id': manager_open_id, 'is_deleted': 0}),
                                              page=1,
                                              pagesize=100)
    total_count = len(staff_rule_list_all)

    staff_rule_list = BaseModel.fetch_all('staff_rule', '*',
                                          BaseModel.where_dict(
                                              {'manager_open_id': manager_open_id, 'is_deleted': 0}), page=page,
                                          pagesize=pagesize)
    res_staff_rule_list = []

    for i in staff_rule_list:
        temp = i.to_json_full()
        temp['id'] = i.get_id()
        temp.pop('is_deleted')
        res_staff_rule_list.append(temp)

    return make_response(SUCCESS, total_count = total_count, staff_rule_list = res_staff_rule_list)


@main_api_v2.route('/delete_staff_rule', methods=["POST"])
@para_check('token', 'id')
def delete_staff_rule():
    """By ZYunH."""
    token = request.json.get('token')
    rule_id = request.json.get('id')

    # Optional parameters.
    page = request.json.get('page')
    pagesize = request.json.get('pagesize')

    # Parameters check.
    # 1.token
    client_member_info = BaseModel.fetch_one('client_member', '*', BaseModel.where_dict({'token': token}))
    if client_member_info is None:
        return make_response(err.ERR_INVALID_PARAMS)
    manager_open_id = client_member_info.open_id
    if manager_open_id is None:
        return make_response(err.ERR_DB_MISS)

    # Work.
    this_rule = BaseModel.fetch_by_id('staff_rule', rule_id)
    if this_rule is None:
        return make_response(err.ERR_INVALID_PARAMS)
    staff_in_this_rule = BaseModel.fetch_all(Staff, '*', BaseModel.where_dict({'role': rule_id, 'is_deleted': 0}))
    if len(staff_in_this_rule) > 0:
        return make_response(err.ERR_EXIST_STAFF)

    this_rule.is_deleted = 1
    flag = this_rule.save()
    if flag is False:
        return make_response(err.ERR_SEND_WS_TO_ANDROID)
    # Use page&pagesize to get item.
    if isinstance(page, int) and isinstance(pagesize, int):
        rule_list = BaseModel.fetch_all('staff_rule', '*',
                                        BaseModel.where_dict(
                                            {'manager_open_id': manager_open_id, 'is_deleted': 0}), page=page,
                                        pagesize=pagesize)
        if len(rule_list) == pagesize:
            temp = rule_list[-1].to_json()
            temp['id'] = rule_list[-1].get_id()
            temp.pop('is_deleted')
            return make_response(SUCCESS, info = temp)
        return make_response(SUCCESS)
    # Get id, return modified field.
    temp = this_rule.to_json_full()
    temp['id'] = this_rule.get_id()
    return make_response(SUCCESS, info = temp)


@main_api_v2.route('/get_staff_rule', methods=["POST"])
@para_check('token', 'id')
def get_staff_rule():
    """By ZYunH."""
    this_rule = BaseModel.fetch_by_id('staff_rule', request.json.get('id'))
    if this_rule is None:
        return make_response(err.ERR_INVALID_PARAMS)
    temp = this_rule.to_json_full()
    temp['id'] = this_rule.get_id()
    return make_response(SUCCESS, info = temp)


@main_api_v2.route('/get_available_modules', methods=["POST"])
@para_check('token', 'app')
def get_all_staff_rule():
    """By ZYunH."""
    # Check client or return.
    status, user_info = UserLogin.verify_token(request.json.get('token'))

    if user_info is None:
        return make_response(err.ERR_USER_TOKEN)

    if BaseModel.fetch_one('employee_client', '*', BaseModel.or_(['=', 'username', user_info.username],
                                                                 ['=', 'client_id', user_info.client_id], ), ) \
            is not None:
        add_employee_flag = True
    else:
        add_employee_flag = False

    app = request.json.get('app')
    if app not in ('yaca', 'zidou', 'test'):
        return make_response(err.ERR_INVALID_PARAMS)
    modules = Tag().load_display_config(app).get_open_name_list()
    if add_employee_flag:
        modules.append('employee')

    client = BaseModel.fetch_one('client', '*', BaseModel.where_dict({'client_id': user_info.client_id}))
    if client is None:
        return make_response(err.ERR_INVALID_MEMBER)

    return make_response(SUCCESS, modules = modules)


@main_api_v2.route('/create_staff', methods=['POST'])
def create_staff():
    verify_json()
    status, user_info = UserLogin.verify_token(request.json.get('token'))
    if status != SUCCESS:
        return make_response(status)

    staff_list = BaseModel.fetch_all(Staff, '*', where_clause=BaseModel.where_dict({'manager_open_id': user_info.open_id, 'is_deleted': 0}))
    if len(staff_list) >= DEFAULT_MAX_STAFF_COUNT:
        return make_response(err.ERR_STAFF_LIMIT)

    nickname = request.json.get('staff_nickname')
    phone = request.json.get('phone')
    role = request.json.get('role_id')
    if not nickname or not phone or not role:
        return make_response(err.ERR_INVALID_PARAMS)

    if user_info.phone == phone:
        return make_response(err.ERR_INVITE_SELF)

    # 标识待定
    id = request.json.get('staff_id')
    # short_url = None
    long_url = None
    if not id:
        # 创建
        for exist_staff in staff_list:
            if exist_staff.phone == phone:
                return make_response(err.ERR_INVITE_EXIST_STAFF)

        staff = CM(Staff)
        staff.nickname = nickname
        staff.phone = phone
        staff.role = role
        staff.manager_open_id = user_info.open_id
        staff.is_deleted = 0
        staff.is_confirmed = 0
        staff.is_work = 1
        staff.invite_time = int(time.time())
        staff.save()
        # 发送短信
        # send_invite_sms(phone, url)

        app_name = user_info.app
        # short_url, long_url = get_short_url(staff.get_id(), app_name)

        url_prefix = ''
        if app_name == 'yaca':
            url_prefix = "http://wx.walibee.com/"
        elif app_name == 'zidou':
            url_prefix = "http://wx.zidouchat.com/"
        elif app_name == 'test':
            url_prefix = "http://wx.ixuanren.com/"
        long_url = url_prefix + "verifyStaff.html?staff_id=" + staff.get_id()

    else:
        # 更改
        staff = BaseModel.fetch_by_id(Staff, id)
        if not staff:
            return make_response(err.ERR_INVALID_MEMBER)

        if user_info.open_id != staff.manager_open_id:
            return make_response(err.ERR_WRONG_USER_ITEM)
        staff.nickname = nickname
        staff.role = role
        is_work = request.json.get('is_work')
        if is_work:
            staff.is_work = is_work
        staff.update()
    staff_info = staff.to_json_full()
    staff_info['staff_id'] = staff.get_id()
    del staff_info['role']
    staff_info['staff_nickname'] = staff_info['nickname']
    staff_user_info = BaseModel.fetch_one('client_member', '*', where_clause=BaseModel.where_dict(
            {"open_id": staff.open_id}))
    nickname = None
    avatar_url = None
    if staff_user_info:
        nickname = staff_user_info.nick_name
        avatar_url = staff_user_info.avatar_url
    staff_info['nickname'] = nickname
    staff_info['avatar_url'] = avatar_url

    role = BaseModel.fetch_by_id('staff_rule', staff.role)
    if role.is_deleted == 0:
        staff_info['role_id'] = staff.role
        staff_info['role_nickname'] = role.nickname
        staff_info['role_modules'] = role.modules
    elif role.is_deleted == 1:
        staff_info['role_id'] = None
        staff_info['role_nickname'] = None
        staff_info['role_modules'] = None
    if long_url:
        return make_response(SUCCESS, staff=staff_info, url=long_url)
    return make_response(SUCCESS, staff=staff_info)


@main_api_v2.route('/get_staff_list', methods=['POST'])
def get_staff_list():
    verify_json()
    status, user_info = UserLogin.verify_token(request.json.get('token'))
    if status != SUCCESS:
        return make_response(status)
    page = request.json.get('page')
    pagesize = request.json.get('pagesize')
    if not page or not pagesize:
        return make_response(err.ERR_INVALID_PARAMS)
    logger.info(user_info.open_id)
    staff_list_model = BaseModel.fetch_all(Staff, '*', where_clause=BaseModel.where_dict(
        {"manager_open_id": user_info.open_id, "is_deleted": 0}), page=page, pagesize=pagesize)
    if staff_list_model == []:
        logger.info("staff_list_model = 0")
    staff_list = list()
    for staff_model in staff_list_model:
        staff = staff_model.to_json_full()
        staff['staff_id'] = staff_model.get_id()
        del staff['role']
        staff['staff_nickname'] = staff['nickname']
        del staff['nickname']
        staff_user_info = BaseModel.fetch_one('client_member', '*', where_clause=BaseModel.where_dict(
            {"open_id": staff_model.open_id}))
        nickname = None
        avatar_url = None
        if staff_user_info:
            nickname = staff_user_info.nick_name
            avatar_url = staff_user_info.avatar_url
        staff['nickname'] = nickname
        staff['avatar_url'] = avatar_url
        role = BaseModel.fetch_by_id('staff_rule', staff_model.role)
        if role.is_deleted == 0:
            staff['role_id'] = staff_model.role
            staff['role_nickname'] = role.nickname
            staff['role_modules'] = role.modules
        elif role.is_deleted == 1:
            staff['role_id'] = None
            staff['role_nickname'] = None
            staff['role_modules'] = None
        staff_list.append(staff)
    return make_response(SUCCESS, staff_list=staff_list)


@main_api_v2.route('/delete_staff', methods=['POST'])
def delete_staff():
    verify_json()
    status, user_info = UserLogin.verify_token(request.json.get('token'))
    if status != SUCCESS:
        return make_response(status)
    page = request.json.get('page')
    pagesize = request.json.get('pagesize')
    id = request.json.get('staff_id')
    if not page or not pagesize or not id:
        return make_response(err.ERR_INVALID_PARAMS)
    staff = BaseModel.fetch_by_id(Staff, id)
    if not staff:
        return make_response(err.ERR_INVALID_MEMBER)
    if user_info.open_id != staff.manager_open_id:
        return make_response(err.ERR_WRONG_USER_ITEM)
    staff_open_id = staff.open_id
    staff_client_info = BaseModel.fetch_one(Client, 'client_id', where_clause=BaseModel.where_dict({'client_name': staff_open_id}))
    if not staff_client_info:
        logger.warning(u'client中未找到该用户信息open_id=%s'%staff_open_id)
    staff_user_info = BaseModel.fetch_one(UserInfo, '*', where_clause=BaseModel.where_dict({'open_id': staff_open_id}))
    if not staff_user_info:
        logger.warning(u'client_member中未找到该用户信息open_id=%s'%staff_open_id)
    else:
        staff_user_info.client_id = staff_client_info.client_id
        logger.info(u'原client_id=%d'%staff_user_info.client_id)
        staff_user_info.update()
    staff.is_deleted = 1
    staff.update()

    staff_list_model = BaseModel.fetch_all(Staff, '*',
                                           where_clause=BaseModel.where_dict({"manager_open_id": user_info.open_id, "is_deleted": 0}), page=page,
                                           pagesize=pagesize)
    next_staff = None
    if len(staff_list_model) == pagesize:
        next_staff = staff_list_model[-1].to_json_full()
        next_staff['staff_id'] = staff_list_model[-1].get_id()
    return make_response(SUCCESS, next_staff=next_staff)


@main_api_v2.route("/invite_staff", methods=['POST'])
def invite_staff():
    verify_json()
    staff_id = request.json.get('staff_id')
    staff = BaseModel.fetch_by_id(Staff, staff_id)
    if not staff or staff.is_deleted == 1:
        return make_response(err.ERR_INVALID_MEMBER)
    if staff.is_confirmed == 1:
        return make_response(err.ERR_CONFIRM_TWICE)

    manager = BaseModel.fetch_one(UserInfo, '*', where_clause=BaseModel.where_dict({"open_id": staff.manager_open_id}))
    if not manager:
        return make_response(err.ERR_UNKNOWN_ERROR)
    # manager_info = manager.to_json_full()
    # staff_info = staff.to_json_full()
    manager_name = manager.nick_name
    role = BaseModel.fetch_by_id('staff_rule', staff.role)
    if role.is_deleted == 0:
        role_nickname = role.nickname
    elif role.is_deleted == 1:
        role_nickname = None
    staff_phone = staff.phone[:3] + "****" + staff.phone[7:]
    return make_response(SUCCESS, manager_name=manager_name, role_nickname=role_nickname, staff_phone=staff_phone)

# 测试用 将删除员工的还原
# @main_api_v2.route('/recover_staff', methods=['POST'])
# def recover_staff():
#     verify_json()
#     status, user_info = UserLogin.verify_token(request.json.get('token'))
#     if status != SUCCESS:
#         return make_response(status)
#     id = request.json.get('id')
#     staff = BaseModel.fetch_by_id(Staff, id)
#     if not staff:
#         return make_response(err.ERR_INVALID_MEMBER)
#     staff.is_deleted = 0
#     staff.update()
#     return make_response(SUCCESS)
