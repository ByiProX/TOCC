# -*- coding: utf-8 -*-
import base64
import json
import random

import cStringIO
import uuid

import qrcode
import time

from models_v2.base_model import BaseModel,CM
from core_v2.send_msg import send_ws_to_android
from aliyunsdkdysmsapi.request.v20170525 import SendSmsRequest

from flask import request

from configs.config import main_api_v2, ERR_PARAM_SET, ERR_INVALID_PARAMS, SUCCESS, INFO_NO_USED_BOT, \
    ERR_SET_LENGTH_WRONG, SIGN_DICT, ERR_ALREADY_LOGIN, APP_INFO_DICT, ERR_INVALID_PHONE, acs_client, \
    ERR_INVALID_SMS_CODE, ERR_SMS_CODE_EXPIRED, ERR_UNKNOWN_ERROR, UserInfo, Client, ERR_INVALID_MEMBER, \
    ERR_WRONG_ITEM, ERR_INVITE_VIP, Staff
from core_v2.user_core import UserLogin, cal_user_basic_page_info, add_a_pre_relate_user_bot_info, get_bot_qr_code, \
    set_bot_name
from core_v2.wechat_core import wechat_conn_dict
from core_v2.send_msg import send_sms
from utils.u_model_json_str import verify_json
from utils.u_response import make_response
from utils.u_transformat import str_to_unicode, unicode_to_str
from utils.tag_handle.api import Tag

import logging
import hashlib

logger = logging.getLogger('main')


@main_api_v2.route('/verify_code', methods=['POST'])
def login_verify_code():
    verify_json()
    """
    用于验证
    code: 微信传入的code
    {"code":"111"}
    """
    if not request.data:
        return make_response(ERR_PARAM_SET)
    data_json = json.loads(request.data)
    code = data_json.get('code')
    app_name = data_json.get('app_name')
    if not code or not app_name:
        return make_response(ERR_INVALID_PARAMS)

    user_login = UserLogin(code, app_name)
    status, user_info = user_login.get_user_token()
    # TODO 这里有bug by frank5433
    if status == SUCCESS:
        return make_response(status, user_info=user_info.to_json_full())
    else:
        return make_response(status)


@main_api_v2.route("/get_user_info", methods=['POST'])
def app_get_user_info():
    verify_json()
    status, user_info = UserLogin.verify_token(request.json.get('token'))
    if status != SUCCESS:
        return make_response(status)

    return make_response(SUCCESS, user_info=user_info.to_json_full())


@main_api_v2.route('/get_user_basic_info', methods=['POST'])
def app_get_user_basic_info():
    """
    读取用户管理界面的所有的信息
    {"token":"test_token_123"}
    """
    verify_json()

    token = request.json.get('token')
    if not token:
        return make_response(ERR_INVALID_PARAMS)
    status, user_info = UserLogin.verify_token(token)
    
    # tag = Tag()
    # tag.load_config()
    # default_modules = dict()
    # default_modules['yaca'] = ['coin', 'auto_reply', 'batch_sending', 'wallet', 'events', 'statis', 'sensitive', 'group_zone', 'assistant', 'share_task']
    # default_modules['zidou'] = ['auto_reply', 'batch_sending', 'events', 'statis', 'sensitive', 'group_zone', 'assistant', 'share_task']
    # default_modules['test'] = ['coin', 'auto_reply', 'batch_sending', 'wallet', 'events', 'statis', 'sensitive', 'group_zone', 'employee', 'assistant', 'share_task']
    if status != SUCCESS:
        phone_info = BaseModel.fetch_one('phone_info', '*', where_clause=BaseModel.where_dict({"tmp_token": request.json.get('token')}))
        if not phone_info:
            return make_response(ERR_INVALID_PARAMS)
        staff_info = BaseModel.fetch_by_id(Staff, phone_info.staff_id)
        if not staff_info:
            return make_response(ERR_INVALID_MEMBER)
        manager_info = BaseModel.fetch_one(UserInfo, '*', where_clause=BaseModel.where_dict({"open_id": staff_info.manager_open_id}))
        role_info = BaseModel.fetch_by_id('staff_rule', staff_info.role)
        modules = None
        if staff_info.is_deleted == 1:
            tag = Tag()
            tag.load_config(manager_info.app)
            modules = tag.get_open_name_list()
        if role_info:
            modules = role_info.modules
        bot_info = dict()
        user_func = dict()
        total_info = dict()
        hidden_func = list()
        client_info = dict()
        client_info["app"] = manager_info.app
        client_info["open_id"] = None
        client_info["avatar_url"] = None
        client_info["client_id"] = None
        client_info["nick_name"] = None
        client_info["nickname"] = None 
        client_info["phone"] = phone_info.phone
        client_info["phone_verified"] = phone_info.phone_verified
        client_info["token"] = phone_info.tmp_token
        client_info["username"] = None
        client_info["modules"] = modules
        return make_response(SUCCESS, bot_info=bot_info, user_func=user_func, total_info=total_info,
                                client_info = client_info, hidden_func=hidden_func)

    status, res = cal_user_basic_page_info(user_info)

    client_info = user_info.to_json_full()
    client_info['nickname'] = client_info["nick_name"]
    staff_info = BaseModel.fetch_one(Staff, '*', where_clause=BaseModel.where_dict({"open_id": user_info.open_id, "is_deleted": 0, "is_confirmed": 1}))
    tag = Tag()
    tag.load_config(user_info.app)
    if not staff_info:
        modules = tag.get_open_name_list()
    else:
        role_info = BaseModel.fetch_by_id('staff_rule', staff_info.role)
        modules = role_info.modules
    client_info['modules'] = modules
    client_model = BaseModel.fetch_one(Client, 'vip', where_clause=BaseModel.where_dict({'client_name': user_info.open_id}))
    if client_model and client_model.vip == 1:
        client_info['modules'].append(Staff)
    # Add hidden func info for test by ZYunH 2018-5-18(trade off).
    hidden_func = []
    if BaseModel.fetch_one('employee_client', '*', BaseModel.or_(['=', 'username', user_info.username],
                                                                        ['=', 'client_id', user_info.client_id],),) \
            is not None:
        hidden_func.append('employee')

    if status == SUCCESS:
        return make_response(status, bot_info=res['bot_info'], user_func=res['user_func'],
                             total_info=res['total_info'], client_info=client_info, hidden_func=hidden_func)
    # 目前INFO均返回为SUCCESS
    elif status == INFO_NO_USED_BOT:
        return make_response(SUCCESS, bot_info=res['bot_info'], user_func=res['user_func'],
                             total_info=res['total_info'], client_info=client_info, hidden_func=hidden_func)
    else:
        return make_response(status)


@main_api_v2.route('/initial_robot_nickname', methods=['POST'])
def app_initial_robot_nickname():
    """
    用于设置robot名字,并返回二维码
    {"token":"test_token_123","bot_nickname":"测试呀测试"}
    """
    verify_json()
    status, user_info = UserLogin.verify_token(request.json.get('token'))
    if status != SUCCESS:
        return make_response(status)

    bot_nickname = request.json.get('bot_nickname')
    if not bot_nickname:
        return make_response(ERR_INVALID_PARAMS)
    if len(bot_nickname) < 1 or len(bot_nickname) > 16:
        return make_response(ERR_SET_LENGTH_WRONG)

    status, ubr_info = add_a_pre_relate_user_bot_info(user_info, bot_nickname)

    if status != SUCCESS:
        return make_response(status)

    status, res = get_bot_qr_code(user_info)
    if status == SUCCESS:
        return make_response(status, qr_code=res)
    else:
        return make_response(status)


@main_api_v2.route("/get_bot_qr_code", methods=["POST"])
def app_get_bot_qr_code():
    """
    提供前端一个二维码
    :return:
    """
    verify_json()
    status, user_info = UserLogin.verify_token(request.json.get('token'))
    if status != SUCCESS:
        return make_response(status)

    status, res = get_bot_qr_code(user_info)

    if status == SUCCESS:
        return make_response(status, qr_code=res)
    else:
        return make_response(status)


@main_api_v2.route("/binded_wechat_bot", methods=["POST"])
def app_binded_wechat_bot():
    """
    当捆绑bot成功时，我应该得到的消息
    :return:
    """
    pass


# 进群只能通过Message，


@main_api_v2.route("/get_pc_login_qr", methods=['POST'])
def get_pc_login_qr():
    verify_json()
    app_name = request.json.get('app_name')
    if not app_name:
        return make_response(ERR_INVALID_PARAMS)
    sign = ""
    while sign is "" or sign in SIGN_DICT:
        for i in range(6):
            sign += chr(random.randint(65, 90))

    SIGN_DICT.setdefault(sign, None)
    app_info = APP_INFO_DICT[app_name]
    url_ori = app_info.get("URL_ORI").format(sign)
    qr = qrcode.QRCode(
        version=3,
        error_correction=qrcode.constants.ERROR_CORRECT_H,
        box_size=8,
        border=3,
    )
    qr.add_data(url_ori)
    qr.make()
    img = qr.make_image()
    buffer = cStringIO.StringIO()
    img.save(buffer, format="JPEG")
    b64qr = base64.b64encode(buffer.getvalue())

    return make_response(SUCCESS, qr=b64qr, sign=sign)



@main_api_v2.route("/pc_login", methods=['POST'])
def pc_login():
    verify_json()
    sign = request.json.get("sign")
    code = request.json.get("code")
    app_name = request.json.get('app_name')
    if not app_name or not sign or not code:
        return make_response(ERR_INVALID_PARAMS)

    if sign is None or sign not in SIGN_DICT or code is None:
        return make_response(ERR_INVALID_PARAMS)

    user_login = UserLogin(code, app_name)
    status, user_info = user_login.get_user_token()
    if status == SUCCESS:
        SIGN_DICT[sign] = user_info.token
    else:
        return make_response(status)
    
    phone_info = BaseModel.fetch_one('phone_info', '*', where_clause=BaseModel.where_dict({'tmp_token':sign}))
    if phone_info:
        staff_id = phone_info.staff_id
        staff = BaseModel.fetch_by_id(Staff, staff_id)
        if staff:
            staff.open_id = user_info.open_id
            staff.update()
            user_info.phone_verified = 1
            user_info.phone = phone_info.phone
            user_info.update()

    return make_response(status)


@main_api_v2.route("/verify_pc_login_qr", methods=['POST'])
def verify_pc_login_qr():
    verify_json()
    sign = request.json.get("sign")

    if sign is None or sign not in SIGN_DICT:
        return make_response(ERR_INVALID_PARAMS)

    if SIGN_DICT[sign] is False:
        return make_response(ERR_ALREADY_LOGIN)

    if SIGN_DICT[sign]:
        token = SIGN_DICT[sign]
        SIGN_DICT[sign] = False
        return make_response(SUCCESS, token=token, is_login=True)

    return make_response(SUCCESS, is_login=False)


# add by Quentin below
@main_api_v2.route("/get_signature", methods=['POST'])
def get_signature():
    verify_json()
    url = request.json.get("url")

    status, user_info = UserLogin.verify_token(request.json.get('token'))
    if status != SUCCESS:
        return make_response(status)

    if url is None:
        return make_response(ERR_INVALID_PARAMS)
    try:
        we_conn = wechat_conn_dict.get(user_info.app)
        if we_conn is None:
            logger.info(
                u"没有找到对应的 app: %s. wechat_conn_dict.keys: %s." % (user_info.app, json.dumps(wechat_conn_dict.keys())))
        timestamp, noncestr, signature = we_conn.get_signature_from_access_token(url)
        return make_response(SUCCESS, timestamp=timestamp, noncestr=noncestr, signature=signature)
    except Exception as e:
        logger.error('ERROR  %s' % e)
        return make_response(ERR_INVALID_PARAMS)


@main_api_v2.route("/make_pic_2_qr", methods=['POST'])
def make_pic_2_qr():
    verify_json()
    pic_url = request.json.get('url')

    qr = qrcode.QRCode(
        version=3,
        error_correction=qrcode.constants.ERROR_CORRECT_H,
        box_size=8,
        border=3,
    )
    qr.add_data(pic_url)
    qr.make()
    img = qr.make_image()
    buffer = cStringIO.StringIO()
    img.save(buffer, format="PNG")
    b64qr = base64.b64encode(buffer.getvalue())

    return make_response(SUCCESS, qr=b64qr)


@main_api_v2.route('/set_robot_nickname', methods=['POST'])
def app_set_robot_nickname():
    """
    用于设置rebot名字
    """
    verify_json()
    status, user_info = UserLogin.verify_token(request.json.get('token'))
    if status != SUCCESS:
        return make_response(status)

    bot_id = request.json.get('bot_id')
    print ":::::::::"
    print bot_id

    if not bot_id:
        return make_response(ERR_INVALID_PARAMS)

    bot_nickname = request.json.get('bot_nickname')
    if not bot_nickname:
        return make_response(ERR_INVALID_PARAMS)
    if len(bot_nickname) < 1 or len(bot_nickname) > 16:
        return make_response(ERR_SET_LENGTH_WRONG)

    status = set_bot_name(bot_id, bot_nickname, user_info)

    ## Add by Quentin below
    bot_username = BaseModel.fetch_by_id("bot_info", bot_id)
    client_id = user_info.client_id
    client_quns = BaseModel.fetch_all("client_qun_r", "*",
                                      where_clause=BaseModel.and_(
                                          ["=", "client_id", client_id],
                                      ))

    try:
        for client_qun in client_quns:
            data = {
                "task": "update_self_displayname",
                "chatroomname": client_qun.chatroomname,
                "selfdisplayname": bot_nickname
            }
            send_ws_to_android(bot_username.username, data)
    except:
        logger.warning('rename bot_nickname error!')

    return make_response(status)


# @main_api_v2.route("/who_not_create_chatroom", methods=['POST'])
# def who_not_create_chatroom():
#     verify_json()
#     status, user_info = UserLogin.verify_token(request.json.get('token'))
#
#     clients = BaseModel.fetch_all("client_member", "*")
#     results = []
#     for client in clients:
#         quns = BaseModel.fetch_all("client_qun_r", "*",
#                                    where_clause=BaseModel.where_dict(
#                                        {"chatroomname": client.chatroomname})
#                                    )
#         if not len(quns):
#             results.append(client.code)
#
#     return make_response(SUCCESS, results=results)


if __name__ == "__main__":
    BaseModel.extract_from_json()

    client_bot = BaseModel.fetch_one("client_bot_r", "*",
                                     where_clause=BaseModel.and_(
                                         ["=", "client_id", 11],
                                         ["=", "bot_username", "wxid_lkruzsl7w2r822"],
                                     ))

    print client_bot.bot_username

    s = BaseModel.fetch_all("client_qun_r", "*",
                            where_clause=BaseModel.and_(
                                ["=", "client_id", 11],
                            ))
    print s.__len__()

    # client_quns = BaseModel.fetch_all("client_qun_r", "*",
    #                                   where_clause=BaseModel.and_(
    #                                       ["=", "client_id", 11],
    #                                   ))
    #
    # print [client_qun.chatroomname for client_qun in client_quns]
    # print client_quns[0].chatroomname

    a = BaseModel.fetch_by_id("bot_info", "5adaacc6f5d7e26589658e0a")
    print a.username


@main_api_v2.route("/verify_sms", methods = ['POST'])
def verify_sms():
    verify_json()
    status, user_info = UserLogin.verify_token(request.json.get('token'))
    if status != SUCCESS:
        return make_response(status)

    phone = request.json.get('phone')
    code = request.json.get('sms_code')
    if not phone or not code:
        return make_response(ERR_INVALID_PARAMS)

    if phone and user_info.phone != phone:
        return make_response(ERR_INVALID_PHONE)
    if code and user_info.sms_code != code:
        return make_response(ERR_INVALID_SMS_CODE)
    now_time = int(time.time())
    if now_time > user_info.sms_code_expired_time:
        return make_response(ERR_SMS_CODE_EXPIRED)

    user_info.phone_verified = 1
    user_info.update()

    staff_info = BaseModel.fetch_one('phone_info','*', where_clause=BaseModel.where_dict({"phone": phone}))
    if staff_info:
        if staff_info.is_deleted == 0:
            staff_info.open_id = user_info.open_id
        staff_info.update()

    return make_response(SUCCESS)


@main_api_v2.route('/send_sms', methods = ['POST'])
def api_send_sms():
    verify_json()
    status, user_info = UserLogin.verify_token(request.json.get('token'))
    if status != SUCCESS:
        return make_response(status)

    phone = request.json.get('phone')
    if not phone:
        return make_response(ERR_INVALID_PARAMS)
    __business_id = uuid.uuid1()

    print __business_id
    phone_number = phone

    code = ''
    for i in range(6):
        code_i = random.randint(0, 9)
        code += str(code_i)
    print code

    sms_code = code
    params = "{\"code\":\"" + str(sms_code) + "\"}"
    print 'params', params
    sign_name = '紫豆助手'
    template_code = 'SMS_135044557'
    response_str = send_sms(business_id = __business_id, phone_number = phone_number, sign_name = sign_name, template_code = template_code, template_param = params)
    logger.info("sms_response: " + response_str)
    response_json = json.loads(response_str)
    code = response_json.get('Code')
    if code == 'isv.MOBILE_NUMBER_ILLEGAL' or code == 'isv.MOBILE_COUNT_OVER_LIMIT':
        return make_response(ERR_INVALID_PHONE)
    if code == 'isv.AMOUNT_NOT_ENOUGH':
        return make_response(ERR_UNKNOWN_ERROR)

    user_info.phone = phone
    user_info.phone_verified = 0
    user_info.sms_code = sms_code
    user_info.sms_code_expired_time = int(time.time()) + 10 * 60
    user_info.update()

    return make_response(SUCCESS)


@main_api_v2.route("/invite_confirm", methods = ['POST'])
def invite_confirm():
    verify_json()
    sms_code = request.json.get('sms_code')
    staff_id = request.json.get('staff_id')
    code = request.json.get('code')
    
    if not sms_code or not staff_id or not code:
        return make_response(ERR_INVALID_PARAMS)

    staff = BaseModel.fetch_by_id(Staff, staff_id)
    if not staff:
        return make_response(ERR_INVALID_MEMBER)
    if staff.is_confirmed == 1:
        return make_response(ERR_UNKNOWN_ERROR)
    if staff.is_deleted == 1:
        return make_response(ERR_INVALID_MEMBER)

    phone = staff.phone
    phone_info = BaseModel.fetch_one('phone_info','*', where_clause=BaseModel.where_dict({"phone": phone}))
    if not phone_info:
        return make_response(ERR_INVALID_SMS_CODE)
    if phone_info.sms_code != sms_code:
        return make_response(ERR_INVALID_SMS_CODE)
    now_time = int(time.time())
    if now_time > phone_info.sms_code_expired_time:
        return make_response(ERR_SMS_CODE_EXPIRED)
    manager_info = BaseModel.fetch_one(UserInfo, 'app', 'client_id', where_clause=BaseModel.where_dict({"open_id": staff.manager_open_id}))
    if not manager_info:
        logger.error(u'UserInfo表中未查到open_id=%s'%str_to_unicode(staff.manager_open_id))

    user_login = UserLogin(code, manager_info.app)
    status, user_info = user_login.get_user_token()
    if status == SUCCESS:
        client_info =  BaseModel.fetch_one(Client, 'vip', where_clause=BaseModel.where_dict({"client_name": user_info.open_id}))
        if client_info:
            if client_info.vip == 1:
                staff_list = BaseModel.fetch_all(Staff, '*', where_clause=BaseModel.where_dict({"manager_open_id": user_info.open_id, "is_confirmed": 1, "is_deleted": 0}))
                if len(staff_list) > 0:
                    return make_response(ERR_INVITE_VIP)
            else:
                client_info.vip = 0
                client_info.update()
        else:
            return make_response(ERR_UNKNOWN_ERROR)
        phone_info.phone_verified = 1
        phone_info.staff_id = staff_id
        phone_info.sms_code_expired_time = 0
        phone_info.update()

        user_info.client_id = manager_info.client_id
        user_info.phone = phone
        user_info.phone_verified = 1
        user_info.update()
        staff.open_id = user_info.open_id
        staff.is_confirmed = 1
        staff.confirm_time = int(time.time())
        staff.update()

        exist_staffs = BaseModel.fetch_all(Staff,'*', where_clause=BaseModel.where_dict({"phone": phone, "is_deleted": 0, "is_confirmed": 1}))
        for exist_staff in exist_staffs:
            if exist_staff.phone == phone and exist_staff.staff_id != staff_id:
                exist_staff.is_deleted = 1
                exist_staff.update()

        #还有其他信息需要绑定？
        token = user_info.token
        return make_response(SUCCESS, token = token)      
    else:
        return make_response(status)



    # phone_info.phone_verified = 1
    # phone_info.staff_id = staff_id
    # phone_info.sms_code_expired_time = 0
    # phone_info.update()
    
    # staff.is_confirmed = 1
    # staff.confirm_time = int(time.time())
    # staff.update()

    # exist_staffs = BaseModel.fetch_all(Staff,'*', where_clause=BaseModel.where_dict({"phone": phone}))
    # for exist_staff in exist_staffs:
    #     if exist_staff.phone == phone and exist_staff.staff_id != staff_id and exist_staff.is_deleted == 0:
    #         exist_staff.is_delete = 1
    #         exist_staff.update()

    # #检测是否已经注册
    # user_info = BaseModel.fetch_one(UserInfo, '*', where_clause=BaseModel.where_dict({"phone": phone}))
    # if not user_info:
    #     sha256 = hashlib.sha256()
    #     sha256.update(phone.encode('utf-8'))
    #     tmp_token = sha256.hexdigest()
    #     phone_info.tmp_token = tmp_token
    #     phone_info.update()
    #     return make_response(SUCCESS, token = tmp_token)
    # else:
    #     client_info =  BaseModel.fetch_one('client', 'vip', where_clause=BaseModel.where_dict({"client_name": user_info.open_id}))
    #     if client_info and client_info.vip == 1:
    #         staff_list = BaseModel.fetch_all(Staff, '*', where_clause=BaseModel.where_dict({"manager_open_id": user_info.open_id}))
    #         if len(staff_list) > 0:
    #             return make_response(ERR_INVITE_VIP)
    #         else:
    #             client_info.vip = 0
    #             client_info.update()
    #     manager_info = BaseModel.fetch_one(UserInfo, 'client_id', where_clause=BaseModel.where_dict({"open_id": staff.manager_open_id}))
    #     user_info.client_id = manager_info.client_id
    #     user_info.phone = phone
    #     user_info.phone_verified = 1
    #     user_info.update()
    #     staff.open_id = user_info.open_id
    #     staff.update()
    #     #还有其他信息需要绑定？
    #     token = user_info.token
    #     return make_response(SUCCESS, token = token)



@main_api_v2.route("/get_wechat_login_qr", methods=['POST'])
def get_wechat_login_qr():
    verify_json()
    token = request.json.get('token')
    if not token:
        return make_response(ERR_INVALID_PARAMS)
    sign = token
    staff_id_model = BaseModel.fetch_one('phone_info','staff_id', where_clause=BaseModel.where_dict({"tmp_token": token}))
    if not staff_id_model:
        logger.error(u"phone_info中没有该tmp_token, token=%s"%str_to_unicode(token))
        return make_response(ERR_WRONG_ITEM)
    staff_id = staff_id_model.staff_id
    staff_model = BaseModel.fetch_by_id(Staff,staff_id)
    app_name_model = BaseModel.fetch_one(UserInfo,'app', where_clause=BaseModel.where_dict({"open_id": staff_model.manager_open_id}))
    if not app_name_model:
        return make_response(ERR_UNKNOWN_ERROR)
    app_name = app_name_model.app

    SIGN_DICT.setdefault(sign, None)
    app_info = APP_INFO_DICT[app_name]
    url_ori = app_info.get("URL_ORI").format(sign)
    qr = qrcode.QRCode(
        version=3,
        error_correction=qrcode.constants.ERROR_CORRECT_H,
        box_size=8,
        border=3,
    )
    qr.add_data(url_ori)
    qr.make()
    img = qr.make_image()
    buffer = cStringIO.StringIO()
    img.save(buffer, format="JPEG")
    b64qr = base64.b64encode(buffer.getvalue())

    return make_response(SUCCESS, qr=b64qr, sign=sign)    

    

# @main_api_v2.route("/wechat_login", methods=['POST'])
# def wechat_login():
#     verify_json()
#     sign = request.json.get("sign")
#     code = request.json.get("code")
#     app_name = request.json.get('app_name')
#     if not app_name or not sign or not code:
#         return make_response(ERR_INVALID_PARAMS)

#     if sign is None or sign not in SIGN_DICT or code is None:
#         return make_response(ERR_INVALID_PARAMS)

#     user_login = UserLogin(code, app_name)
#     status, user_info = user_login.get_user_token()

#     if status == SUCCESS:
#         SIGN_DICT[sign] = user_info.token
#     else:
#         return make_response(status)
#     phone_info = BaseModel.fetch_one('phone_info', '*', where_clause=BaseModel.where_dict({'tmp_token':sign}))
#     staff_id = phone_info.staff_id
#     staff = BaseModel.fetch_by_id(Staff, staff_id)
#     staff.open_id = user_info.open_id
#     staff.update()

#     user_info.phone_verified = 1
#     user_info.phone = phone_info.phone
#     user_info.update()

#     return make_response(status)



# @main_api_v2.route("/verify_wechat_login_qr", methods=['POST'])
# def verify_wechat_login_qr():
#     verify_json()
#     sign = request.json.get("sign")

#     if sign is None or sign not in SIGN_DICT:
#         return make_response(ERR_INVALID_PARAMS)

#     if SIGN_DICT[sign] is False:
#         return make_response(ERR_ALREADY_LOGIN)
        
#     if SIGN_DICT[sign]:
#         token = SIGN_DICT[sign]
#         SIGN_DICT[sign] = False
#         status, user_info = UserLogin.verify_token(token)
#         if status != SUCCESS:
#             return make_response(status)

#         status, res = cal_user_basic_page_info(user_info)

#         client_info = user_info.to_json_full()
#         client_info['nickname'] = client_info["nick_name"]

#         # Add hidden func info for test by ZYunH 2018-5-18(trade off).
#         hidden_func = []
#         if BaseModel.fetch_one('employee_client', '*', BaseModel.or_(['=', 'username', user_info.username],
#                                                                             ['=', 'client_id', user_info.client_id],),) \
#                 is not None:
#             hidden_func.append('employee')

#         if status == SUCCESS:
#             return make_response(status, is_login=True, bot_info=res['bot_info'], user_func=res['user_func'],
#                                 total_info=res['total_info'], client_info=client_info, hidden_func=hidden_func)
#         # 目前INFO均返回为SUCCESS
#         elif status == INFO_NO_USED_BOT:
#             return make_response(SUCCESS, is_login=True, bot_info=res['bot_info'], user_func=res['user_func'],
#                                 total_info=res['total_info'], client_info=client_info, hidden_func=hidden_func)
#         else:
#             return make_response(status, is_login=True)        

#     return make_response(SUCCESS, is_login=False)

@main_api_v2.route("/phone_send_sms", methods=['POST'])
def phone_send_sms():
    verify_json()
    phone = request.json.get('phone')
    staff_id = request.json.get('staff_id')
    if not phone and not staff_id:
        return make_response(ERR_INVALID_PARAMS)
    if phone and staff_id:
        return make_response(ERR_INVALID_PARAMS)

    if staff_id:
        staff = BaseModel.fetch_by_id(Staff, staff_id)
        if not staff:
            return make_response(ERR_INVALID_MEMBER)
        phone = staff.phone

    __business_id = uuid.uuid1()

    print __business_id
    phone_number = phone

    code = ''
    for i in range(6):
        code_i = random.randint(0, 9)
        code += str(code_i)
    print code
    
    sms_code = code
    params = "{\"code\":\"" + str(sms_code) + "\"}"
    print 'params', params
    sign_name = '紫豆助手'
    template_code = 'SMS_135044557'
    response_str = send_sms(business_id = __business_id, phone_number = phone_number, sign_name = sign_name, template_code = template_code, template_param = params)
    logger.info("sms_response: " + response_str)
    response_json = json.loads(response_str)
    code = response_json.get('Code')
    if code == 'isv.MOBILE_NUMBER_ILLEGAL' or code == 'isv.MOBILE_COUNT_OVER_LIMIT':
        return make_response(ERR_INVALID_PHONE)
    if code == 'isv.AMOUNT_NOT_ENOUGH':
        return make_response(ERR_UNKNOWN_ERROR)

    phone_info = BaseModel.fetch_one('phone_info', '*', where_clause=BaseModel.where_dict({"phone": phone}))
    if phone_info:
        phone_info.sms_code = sms_code
        phone_info.sms_code_expired_time = int(time.time()) + 10 * 60
        phone_info.update()
    else:
        phone_info = CM('phone_info')
        phone_info.phone = phone
        phone_info.phone_verified = 0
        phone_info.sms_code = sms_code
        phone_info.sms_code_expired_time = int(time.time()) + 10 * 60
        phone_info.save()
    return make_response(SUCCESS)


@main_api_v2.route("/phone_login", methods = ['POST'])
def phone_login():
    verify_json()
    phone = request.json.get('phone')
    sms_code = request.json.get('sms_code')
    app_name = request.json.get('app_name')

    if not phone or not sms_code or not app_name:
        return make_response(ERR_INVALID_PARAMS)

    phone_info = BaseModel.fetch_one('phone_info','*', where_clause=BaseModel.where_dict({"phone": phone}))
    if not phone_info or phone_info.sms_code != sms_code:
        return make_response(ERR_INVALID_SMS_CODE)
    now_time = int(time.time())
    if now_time > phone_info.sms_code_expired_time:
        return make_response(ERR_SMS_CODE_EXPIRED)

    user_info = BaseModel.fetch_one(UserInfo,'*', where_clause=BaseModel.where_dict({"phone": phone}))
    if not user_info:
        if not phone_info.tmp_token:
            return make_response(ERR_INVALID_MEMBER)
        return make_response(SUCCESS, token = phone_info.tmp_token)
    if user_info.app != app_name:
        return make_response(ERR_INVALID_PHONE)

    phone_info.sms_code_expired_time = 0
    phone_info.update()
    
    return make_response(SUCCESS, token = user_info.token)
