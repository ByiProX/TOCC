# -*- coding: utf-8 -*-
import time
import traceback

from configs.config import *
from core_v2.user_core import UserLogin
from utils.z_utils import *


@main_api_v2.route('/_employee_add_client', methods=["POST"])
@para_check('psw', 'username', 'client_id')
def _employee_add_client():
    if request.json.get('psw') != 'zvcasdkuagdgv214':
        return ' '
    try:
        new_client = CM('employee_client')
        new_client.username = request.json.get('username')
        new_client.client_id = request.json.get('client_id')
        new_client.remark = request.json.get('remark') if request.json.get('remark') is not None else 'sc'

        success = new_client.save()
        if success:
            return make_response(SUCCESS, id = new_client.get_id())
        else:
            return make_response(err.ERR_SEND_WS_TO_ANDROID, id = new_client.get_id())
        # return response(new_client.to_json_full().update({'success': success, 'id': new_client.get_id()}))
    except Exception as e:
        logger.error("发生未知错误，捕获所有异常，待查")
        logger.error(traceback.format_exc())
        return make_response(err.ERR_UNKNOWN_ERROR)


@main_api_v2.route('/_add_or_modify_tag', methods=["POST"])
@para_check('psw', 'index')
def add_or_modify_tag():
    if request.json.get('psw') != 'zvcasdkuagdgv214':
        return ' '
    value_as_dict = request.json
    value_as_dict.pop('psw')
    previous_tag = BaseModel.fetch_one('employee_tag', '*',
                                       BaseModel.where_dict({'index': int(request.json.get('index'))}))
    if previous_tag is None:
        new_tag = CM('employee_tag')
        new_tag.from_json(value_as_dict)
        flag = new_tag.save()
        if flag:
            return make_response(SUCCESS, tag = new_tag.to_json_full())
        else:
            return make_response(err.ERR_SEND_WS_TO_ANDROID, tag = new_tag.to_json_full())
    else:
        previous_tag.from_json(value_as_dict)
        flag = previous_tag.save()
        if flag:
            return make_response(SUCCESS, tag = previous_tag.to_json_full())
        else:
            return make_response(err.ERR_SEND_WS_TO_ANDROID, tag = previous_tag.to_json_full())


@main_api_v2.route('/employee_search', methods=["POST"])
@para_check('token', 'keyword', )
def employee_search():
    try:
        # Check client or return.
        status, user_info = UserLogin.verify_token(request.json.get('token'))
        try:
            client_id = user_info.client_id
        except AttributeError:
            return make_response(err.ERR_USER_TOKEN)

        keyword = unicode(request.json.get('keyword'))
        if keyword == "":
            return make_response(err.ERR_INVALID_PARAMS)
        user_list = BaseModel.fetch_all('a_contact', '*', BaseModel.or_(['=', 'alias', keyword],
                                                                        ['=', 'username', keyword],
                                                                        ['=', 'quan_pin', keyword],
                                                                        ['=', 'nickname', keyword], ),
                                        pagesize=100,
                                        page=1)
        employee_list = []
        for i in user_list:
            _result = i.to_json_full()
            __username = _result.get('username')
            # pop chatroomname.
            if __username is not None and re.search(r'[0-9]+@chatroom', __username) is not None:
                continue
            employee_list.append({'username': __username, 'nickname': _result.get('nickname'),
                           'avatar_url': _result.get('avatar_url')})
    except Exception as e:
        return make_response(err.ERR_UNKNOWN_ERROR, err_info = '%s' % e)
    return make_response(SUCCESS, employee_list = employee_list)


@main_api_v2.route('/employee_tags', methods=["POST"])
def employee_tags():
    res_tag_list = []
    tag_list = BaseModel.fetch_all('employee_tag', '*', BaseModel.where_dict({'remark': 'sc'}))
    for i in tag_list:
        _tag = i.to_json_full()
        _tag.update({'_id': i.get_id()})
        res_tag_list.append({'id': _tag['index'], 'name': _tag['nickname'], '_id': _tag['_id']})
    return make_response(SUCCESS, tag_list = res_tag_list)


@main_api_v2.route('/employee_tag_edit', methods=["POST"])
@para_check('token', 'username', 'tag_list')
def employee_tag_edit():
    # Check client or return.
    status, user_info = UserLogin.verify_token(request.json.get('token'))
    try:
        client_id = user_info.client_id
    except AttributeError:
        return make_response(err.ERR_USER_TOKEN)

    username = request.json.get('username')
    tag_list = request.json.get('tag_list')

    # Do not use <> in this line.
    this_user = BaseModel.fetch_one('employee_people', '*', BaseModel.and_(["=", "username", username],
                                                                           ["=", "by_client_id", client_id]))

    if this_user is None:
        new_user = CM('employee_people')
        new_user.username = username
        new_user.tag_list = tag_list
        new_user.by_client_id = client_id
        new_user.remark = 'sc'
        flag = new_user.save()
    else:
        print('---tag_list', tag_list)
        if tag_list == []:
            # delete this field.
            this_user.tag_list = [0, ]
            this_user.by_client_id = client_id
        else:
            # Modify field.
            this_user.tag_list = tag_list
            this_user.by_client_id = client_id

        flag = this_user.save()
    # Update rule.
    GLOBAL_RULES_UPDATE_FLAG[GLOBAL_EMPLOYEE_PEOPLE_FLAG] = True
    if flag:
        return make_response(SUCCESS)
    else:
        return make_response(err.ERR_SEND_WS_TO_ANDROID)


@main_api_v2.route('/employee_detail', methods=["POST"])
@para_check('username', 'token')
def employee_detail():
    # Check client or return.
    status, user_info = UserLogin.verify_token(request.json.get('token'))
    try:
        client_id = user_info.client_id
    except AttributeError:
        return make_response(err.ERR_USER_TOKEN)

    username = request.json.get('username')

    this_user = BaseModel.fetch_one('employee_people', '*',
                                    BaseModel.where_dict({'username': username, 'by_client_id': client_id}))

    # FIX.
    if this_user is None or this_user.tag_list == [0, ]:
        return make_response(err.ERR_INVALID_MEMBER)

    _tag_list = this_user.tag_list
    tag_list = []
    for i in _tag_list:
        this_tag_info = BaseModel.fetch_one('employee_tag', '*', BaseModel.where_dict({'index': i}))
        tag_list.append({'id': i, 'name': this_tag_info.nickname})

    user_info = BaseModel.fetch_one('a_contact', '*', BaseModel.where_dict({'username': username}))
    avatar_url = user_info.avatar_url
    nickname = user_info.nickname

    log_list = BaseModel.fetch_all('employee_be_at_log', '*',
                                   BaseModel.where_dict({'username': username, 'by_client_id': client_id}))
    be_at_count = 0
    overtime_count = 0
    avg_time = 0
    now = int(time.time())
    for i in log_list:
        be_at_count += 1
        if not i.is_reply and (int(i.create_time) + 86400) < now:
            overtime_count += 1
        if i.is_reply:
            avg_time += i.reply_time - i.create_time

    avg_time = avg_time / (be_at_count - overtime_count) if (be_at_count - overtime_count) else 0

    res_user_info = {
        'avatar_url': avatar_url,
        'nickname': nickname,
        'username': username
    }


    return make_response(SUCCESS, user_info = res_user_info, tag_list = tag_list, be_at_count = be_at_count, 
                overtime_count = overtime_count, avg_time = avg_time)


@main_api_v2.route('/employee_record', methods=["POST"])
@para_check('token', 'username', 'page', 'pagesize')
def employee_record():
    try:
        # Check client or return.
        status, user_info = UserLogin.verify_token(request.json.get('token'))
        try:
            client_id = user_info.client_id
        except AttributeError:
            return make_response(err.ERR_USER_TOKEN)

        username = request.json.get('username')
        page = int(request.json.get('page'))
        pagesize = int(request.json.get('pagesize'))

        all_log_list = BaseModel.fetch_all('employee_be_at_log', '*',
                                           BaseModel.where_dict({'username': username, 'by_client_id': client_id}),
                                           order_by=BaseModel.order_by({"create_time": "desc"}), page=page,
                                           pagesize=pagesize)

        _all_log_list = BaseModel.fetch_all('employee_be_at_log', '*',
                                            BaseModel.where_dict({'username': username, 'by_client_id': client_id}),
                                            order_by=BaseModel.order_by({"create_time": "desc"}), page=1, pagesize=100)

        log_list = []
        for log in all_log_list:
            chatroomname = log.chatroomname
            this_chatroom = BaseModel.fetch_one('a_chatroom', '*', BaseModel.where_dict({'chatroomname': chatroomname}))
            at_msg = BaseModel.fetch_by_id('a_message', log.a_message_id)
            speaker_username = at_msg.real_talker
            speaker_info = BaseModel.fetch_one('a_contact', '*', BaseModel.where_dict({'username': speaker_username}))
            speaker_avatar_url = speaker_info.avatar_url if speaker_info is not None and speaker_info.avatar_url is not None else ''
            speaker_nickname = speaker_info.nickname if speaker_info is not None and speaker_info.nickname is not None else ''
            _temp = {
                'chatroom_info': {
                    'chatroom_name': chatroomname,
                    'nickname': this_chatroom.nickname if this_chatroom.nickname != '' else this_chatroom.nickname_default,
                    'avatar_url': this_chatroom.avatar_url,
                },
                'speaker_at_msg': {
                    'user_info': {'avatar_url': speaker_avatar_url, 'nickname': speaker_nickname},
                    'content': log.content,
                    'create_time': log.create_time,
                },
                'reply_msg': {},
                'reply_duration': (log.reply_time - log.create_time) if log.is_reply and (
                        log.reply_time - log.create_time) < 86400 else -1
            }
            log_list.append(_temp)
    except Exception as e:
        logger.error("发生未知错误，捕获所有异常，待查")
        logger.error(traceback.format_exc())
        return make_response(err.ERR_UNKNOWN_ERROR)
    return make_response(SUCCESS, total_count = len(_all_log_list), log_list = log_list)


@main_api_v2.route('/employee_ranking', methods=['POST'])
@para_check('token')
def employee_ranking():
    try:
        # Check client or return.
        status, user_info = UserLogin.verify_token(request.json.get('token'))
        try:
            client_id = user_info.client_id
        except AttributeError:
            return make_response(err.ERR_USER_TOKEN)

        people = BaseModel.fetch_all('employee_people', '*', BaseModel.where_dict({'by_client_id': client_id}))
        total_count = 0
        user_info_list = []
        for this_user in people:
            # FIX.
            if this_user.tag_list == [0, ]:
                continue
            username = this_user.username
            _tag_list = this_user.tag_list
            tag_list = []
            for i in _tag_list:
                this_tag_info = BaseModel.fetch_one('employee_tag', '*', BaseModel.where_dict({'index': i}))
                tag_list.append({'id': i, 'name': this_tag_info.nickname})

            user_info = BaseModel.fetch_one('a_contact', '*', BaseModel.where_dict({'username': username}))
            avatar_url = user_info.avatar_url
            nickname = user_info.nickname

            log_list = BaseModel.fetch_all('employee_be_at_log', '*',
                                           BaseModel.where_dict({'username': username, 'by_client_id': client_id}))
            be_at_count = 0
            reply_count = 0
            overtime_count = 0
            avg_time = 0
            now = int(time.time())
            for i in log_list:
                be_at_count += 1
                if not i.is_reply and (int(i.create_time) + 86400) < now:
                    overtime_count += 1
                if i.is_reply:
                    reply_count += 1
                    avg_time += i.reply_time - i.create_time

            avg_time = (avg_time / reply_count) if reply_count else 0

            _temp = {
                "user_info": {
                    "username": username,
                    "avatar_url": avatar_url,
                    "nickname": nickname
                },
                "be_at_count": be_at_count,
                "overtime_count": overtime_count,
                "avg_time": avg_time,
                "tag_list": tag_list
            }
            total_count += 1
            user_info_list.append(_temp)
    except Exception as e:
        logger.error("发生未知错误，捕获所有异常，待查")
        logger.error(traceback.format_exc())
        return make_response(err.ERR_UNKNOWN_ERROR)
    return make_response(SUCCESS, total_count = total_count, user_info_list = user_info_list)


@main_api_v2.route('/employee_wrong_log', methods=['POST'])
@para_check('token', 'username', 'page', 'pagesize')
def employee_wrong_log():
    try:
        # Check client or return.
        status, user_info = UserLogin.verify_token(request.json.get('token'))
        try:
            client_id = user_info.client_id
        except AttributeError:
            return make_response(err.ERR_USER_TOKEN)

        username = request.json.get('username')
        page = int(request.json.get('page'))
        pagesize = int(request.json.get('pagesize'))

        if username == '':
            all_log_list = BaseModel.fetch_all('employee_re_log', '*',
                                               BaseModel.where_dict({'by_client_id': client_id}),
                                               order_by=BaseModel.order_by({"create_time": "desc"}), page=page,
                                               pagesize=pagesize)

            _all_log_list = BaseModel.fetch_all('employee_re_log', '*',
                                                BaseModel.where_dict({'by_client_id': client_id}),
                                                order_by=BaseModel.order_by({"create_time": "desc"}), page=1,
                                                pagesize=100)
        else:
            all_log_list = BaseModel.fetch_all('employee_re_log', '*',
                                               BaseModel.where_dict({'username': username, 'by_client_id': client_id}),
                                               order_by=BaseModel.order_by({"create_time": "desc"}), page=page,
                                               pagesize=pagesize)

            _all_log_list = BaseModel.fetch_all('employee_re_log', '*',
                                                BaseModel.where_dict({'username': username, 'by_client_id': client_id}),
                                                order_by=BaseModel.order_by({"create_time": "desc"}), page=1,
                                                pagesize=100)
        log_list = []
        for log in all_log_list:
            chatroomname = log.chatroomname
            this_chatroom = BaseModel.fetch_one('a_chatroom', '*', BaseModel.where_dict({'chatroomname': chatroomname}))
            this_person = BaseModel.fetch_one('a_contact', '*', BaseModel.where_dict({'username': log.username}))
            avatar_url = this_person.avatar_url if this_person is not None else ''
            nickname = this_person.nickname if this_person is not None else ''
            if this_chatroom is None or this_person is None:
                continue
            _temp = {
                'user_info': {
                    'username': log.username,
                    'avatar_url': avatar_url,
                    'nickname': nickname
                },
                'chatroom_info': {
                    'chatroomname': chatroomname,
                    'nickname': this_chatroom.nickname if this_chatroom.nickname != '' else this_chatroom.nickname_default,
                    'avatar_url': this_chatroom.avatar_url,
                },
                'msg_content': log.content,
                'create_time': log.create_time,
            }
            log_list.append(_temp)
    except Exception as e:
        logger.error("发生未知错误，捕获所有异常，待查")
        logger.error(traceback.format_exc())
        return make_response(err.ERR_UNKNOWN_ERROR)
    return make_response(SUCCESS, total_count = len(_all_log_list), log_list = log_list)


@main_api_v2.route('/get_sub_list', methods=['POST'])
def get_sub_list():
    status, user_info = UserLogin.verify_token(request.json.get('token'))

    if status != SUCCESS or not user_info:
        return make_response(status)

    this_user = user_info.client_id
    if this_user not in SC_HEAD:
        return make_response(err.ERR_WRONG_USER_ITEM)

    sub_list = SC_SUB
    sub_info_list = []
    for sub in sub_list:
        sub_info = BaseModel.fetch_one('client_member', '*', BaseModel.where_dict({'client_id': sub}))
        sub_nickname = sub_info.nick_name if sub_info is not None else ''
        sub_avatar = sub_info.avatar_url if sub_info is not None else ''

        _temp = {
            'client_id': sub,
            'sub_nickname': sub_nickname,
            'sub_avatar': sub_avatar
        }
        sub_info_list.append(_temp)

    return make_response(SUCCESS, sub_info_list=sub_info_list)


@main_api_v2.route('/employee_ranking_shangceng', methods=['POST'])
@para_check('token')
def employee_ranking_shangceng():
    status, user_info = UserLogin.verify_token(request.json.get('token'))

    if status != SUCCESS or not user_info:
        return make_response(status)

    this_user = user_info.client_id
    if this_user not in SC_HEAD:
        return make_response(err.ERR_WRONG_USER_ITEM)

    sub_client_id_list = SC_SUB
    sub_client_id = request.json.get('sub_client_id')

    if not sub_client_id:
        shangceng_sub_list = sub_client_id_list
    else:
        shangceng_sub_list = [sub_client_id]

    employee_list = []

    for shangceng_sub in shangceng_sub_list:
        _employee = BaseModel.fetch_all('employee_people', '*', BaseModel.where_dict({'by_client_id': shangceng_sub}))
        # employee_list.append(_employee)
        while _employee:
            employee_list.append(_employee.pop(0))

    total_count = 0
    user_info_list = []

    for employee in employee_list:
        if employee.tag_list == [0, ]:
            continue
        username = employee.username
        _tag_list = employee.tag_list
        tag_list = []
        for i in _tag_list:
            this_tag_info = BaseModel.fetch_one('employee_tag', '*', BaseModel.where_dict({'index': i}))
            tag_list.append({'id': i, 'name': this_tag_info.nickname})

        user_info = BaseModel.fetch_one('a_contact', '*', BaseModel.where_dict({'username': username}))
        avatar_url = user_info.avatar_url
        nickname = user_info.nickname

        log_list = []
        for shangceng_sub in shangceng_sub_list:
            _log_list = BaseModel.fetch_all('employee_be_at_log', '*',
                                           BaseModel.where_dict({'username': username, 'by_client_id': shangceng_sub}))
            while _log_list:
                log_list.append(_log_list.pop(0))

        be_at_count = 0
        reply_count = 0
        overtime_count = 0
        avg_time = 0
        now = int(time.time())
        for i in log_list:
            be_at_count += 1
            if not i.is_reply and (int(i.create_time) + 86400) < now:
                overtime_count += 1
            if i.is_reply:
                reply_count += 1
                avg_time += i.reply_time - i.create_time

        avg_time = (avg_time / reply_count) if reply_count else 0

        _temp = {
            "user_info": {
                "username": username,
                "avatar_url": avatar_url,
                "nickname": nickname
            },
            "be_at_count": be_at_count,
            "overtime_count": overtime_count,
            "avg_time": avg_time,
            "tag_list": tag_list
        }
        total_count += 1
        user_info_list.append(_temp)

    return make_response(SUCCESS, total_count=total_count, user_info_list=user_info_list)


@main_api_v2.route('/employee_wrong_log_shangceng', methods=['POST'])
@para_check('token', 'username', 'page', 'pagesize')
def employee_wrong_log_shangceng():
    status, user_info = UserLogin.verify_token(request.json.get('token'))

    if status != SUCCESS or not user_info:
        return make_response(status)

    this_user = user_info.client_id
    if this_user not in SC_HEAD:
        return make_response(err.ERR_WRONG_USER_ITEM)

    shangceng_sub_list = SC_SUB

    username = request.json.get('username')
    page = int(request.json.get('page'))
    pagesize = int(request.json.get('pagesize'))

    if username == '':
        all_log_list = BaseModel.fetch_all('employee_re_log', '*',
                                           BaseModel.and_(['in', 'by_client_id', shangceng_sub_list]),
                                           order_by=BaseModel.order_by({"create_time": "desc"}), page=page,
                                           pagesize=pagesize)
        total_count = BaseModel.count('employee_re_log',
                                      where_clause=BaseModel.and_(['in', 'by_client_id', shangceng_sub_list]))
    else:
        all_log_list = BaseModel.fetch_all('employee_re_log', '*',
                                           BaseModel.and_(['in', 'by_client_id', shangceng_sub_list],
                                                          ['=', 'username', username]),
                                           order_by=BaseModel.order_by({"create_time": "desc"}), page=page,
                                           pagesize=pagesize)
        total_count = BaseModel.count('employee_re_log',
                                      where_clause=BaseModel.and_(['in', 'by_client_id', shangceng_sub_list],
                                                                  ['=', 'username', username]))
    log_list = []
    for log in all_log_list:
        chatroomname = log.chatroomname
        this_chatroom = BaseModel.fetch_one('a_chatroom', '*', BaseModel.where_dict({'chatroomname': chatroomname}))
        this_person = BaseModel.fetch_one('a_contact', '*', BaseModel.where_dict({'username': log.username}))
        avatar_url = this_person.avatar_url if this_person is not None else ''
        nickname = this_person.nickname if this_person is not None else ''
        if this_chatroom is None or this_person is None:
            continue
        _temp = {
            'user_info': {
                'username': log.username,
                'avatar_url': avatar_url,
                'nickname': nickname
            },
            'chatroom_info': {
                'chatroomname': chatroomname,
                'nickname': this_chatroom.nickname if this_chatroom.nickname != '' else this_chatroom.nickname_default,
                'avatar_url': this_chatroom.avatar_url,
            },
            'msg_content': log.content,
            'create_time': log.create_time,
        }
        log_list.append(_temp)

    return make_response(SUCCESS, total_count=total_count, log_list=log_list)
