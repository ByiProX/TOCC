# -*- coding: utf-8 -*-

import config

config_str = ""
