# -*- coding: utf-8 -*-

from PIL import Image, ImageChops
import math
import operator


def compare(pic1,pic2):
    '''
    :param pic1: 图片1路径
    :param pic2: 图片2路径
    :return: 返回对比的结果
    '''
    image1 = Image.open(pic1)
    image2 = Image.open(pic2)

    histogram1 = image1.histogram()
    histogram2 = image2.histogram()

    differ = math.sqrt(reduce(operator.add, list(map(lambda a, b: (a-b)**2, histogram1, histogram2)))/len(histogram1))

    print differ
    return differ


# compare('khmp132.jpg', 'wx132.jpg')


img1 = Image.open('mp132.jpg')

img2 = Image.open('wx132.jpg')

img3 = ImageChops.invert(img2)

# Image.blend(img1, img3, 0.5).show()

# with open("mp132.jog`")