# -*- coding: utf-8 -*-
import hashlib  
import random  
from models_v2.base_model import CM, BaseModel
import time

def get_md5(s):  
    s += str(random.randint(0, 2**31))
    s = s.encode('utf8') if isinstance(s, unicode) else s  
    m = hashlib.md5()  
    m.update(s)  
    return m.hexdigest()  
  
code_map = (  
           'a' , 'b' , 'c' , 'd' , 'e' , 'f' , 'g' , 'h' ,  
           'i' , 'j' , 'k' , 'l' , 'm' , 'n' , 'o' , 'p' ,  
           'q' , 'r' , 's' , 't' , 'u' , 'v' , 'w' , 'x' ,  
           'y' , 'z' , '0' , '1' , '2' , '3' , '4' , '5' ,  
           '6' , '7' , '8' , '9' , 'A' , 'B' , 'C' , 'D' ,  
           'E' , 'F' , 'G' , 'H' , 'I' , 'J' , 'K' , 'L' ,  
           'M' , 'N' , 'O' , 'P' , 'Q' , 'R' , 'S' , 'T' ,  
           'U' , 'V' , 'W' , 'X' , 'Y' , 'Z'  
            )  
  
  
def get_hash_key(s):  
    hkeys = []  
    hex = get_md5(s)  
    for i in xrange(0, 4):  
        n = int(hex[i*8:(i+1)*8], 16)  
        v = []  
        e = 0  
        for j in xrange(0, 5):  
            x = 0x0000003D & n  
            e |= ((0x00000002 & n ) >> 1) << j  
            v.insert(0, code_map[x])  
            n = n >> 6  
        e |= n << 5  
        v.insert(0, code_map[e & 0x0000003D])  
        hkeys.append(''.join(v))  
    
    return hkeys[random.randint(0,3)]


def get_short_url(staff_id, app_name):
    short = get_hash_key(staff_id)
    url_prefix = ''
    if app_name == 'yaca':
        url_prefix = "http://wx.walibee.com/"
    elif app_name == 'zidou':
        url_prefix = "http://wx.zidouchat.com/"
    elif app_name == 'test':
        url_prefix = "http://wx.ixuanren.com/"
    else:
        return None, None
    long_url = url_prefix + "verifyStaff.html?staff_id=" + staff_id
    short_url = app_name + '_' + short
    
    short_url_info = BaseModel.fetch_one('short_url', '*', where_clause=BaseModel.where_dict({'short_url': short_url}))
    create_time = int(time.time())
    # 过期时间暂定一年
    expired_time = create_time + 60 * 60 * 24 * 365
    if short_url_info:
        short_url_info.long_url = long_url
        short_url_info.create_time = create_time
        short_url_info.expired_time = expired_time
        short_url_info.update()
    else:
        short_url_info = CM('short_url')
        short_url_info.short_url = short_url
        short_url_info.long_url = long_url
        short_url_info.create_time = create_time
        short_url_info.expired_time = expired_time
        short_url_info.save()
    
    return short_url, long_url